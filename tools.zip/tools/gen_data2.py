import json
true=True; false=False
OUT='/home/claude/proj/XianxiaARPG/data/'
def w(n,o): json.dump(o,open(OUT+n,'w'),indent=1,ensure_ascii=False)
def c(r,g,b): return [r,g,b]

# ---------------------------------------------------------------- realms
R=[("qi_condensation","Qi Condensation","player_base",120,100,100,12,5.4,6,36,1.26,0,c(.5,.7,1)),
   ("foundation","Foundation Establishment","player_advanced",240,170,110,24,5.7,9,140,1.30,120,c(.3,.6,1)),
   ("golden_core","Golden Core","player_core",420,260,120,42,6.0,12,450,1.33,450,c(1,.85,.35)),
   ("nascent_soul","Nascent Soul","player_ultimate",700,400,130,70,6.3,16,1500,1.36,1500,c(.8,.75,1)),
   ("dao_ascendant","Dao Ascendant","player_god",1150,650,150,115,6.6,22,4500,1.40,5000,c(.6,.5,1))]
w('realms.json',[dict(id=a,name=b,sprite=s,hp=hp,qi=qi,stamina=st,atk=atk,speed=sp,qi_regen=rg,stage_xp=sx,stage_growth=sg,break_cost=bc,aura=au) for a,b,s,hp,qi,st,atk,sp,rg,sx,sg,bc,au in R])

# ---------------------------------------------------------------- skills (6 slots)
w('skills.json',{"order":["fireball","waterball","lightning","bell","swords","palm"],"skills":{
 "fireball":{"name":"Crimson Fireball","icon":"skill_fireball","sprite":"fx_fireball","realm":0,"qi":14,"cd":1.1,"kind":"projectile","dmg":2.4,"speed":13.0,"explode":2.1,"burn":3.0,"color":c(1,.55,.15),"sfx":"fire","desc":"Hurls a blazing orb that explodes and sets foes aflame."},
 "waterball":{"name":"Azure Torrent Orb","icon":"skill_waterball","sprite":"fx_waterball","realm":0,"qi":18,"cd":1.6,"kind":"projectile","dmg":1.8,"speed":9.5,"pierce":true,"slow":0.45,"color":c(.35,.75,1),"sfx":"water","desc":"A slow piercing orb of water that chills everything it passes."},
 "lightning":{"name":"Heavenly Thunder Orb","icon":"skill_lightning","sprite":"fx_lightning","realm":1,"qi":24,"cd":2.4,"kind":"projectile","dmg":1.7,"speed":15.0,"chain":4,"chain_range":6.5,"chain_falloff":0.78,"stun":0.35,"color":c(1,.95,.55),"sfx":"thunder","desc":"A thunder orb that detonates into chain lightning, leaping between up to 4 foes."},
 "bell":{"name":"Golden Bell Shield","icon":"skill_bell","realm":1,"qi":30,"cd":12.0,"kind":"shield","absorb":0.8,"duration":7.0,"dmg":3.0,"radius":3.4,"stun":1.0,"color":c(1,.85,.3),"sfx":"bell","desc":"A golden bell absorbs damage, then shatters in a stunning shockwave."},
 "swords":{"name":"Ten Thousand Swords","icon":"skill_swords","sprite":"fx_flying_sword","realm":2,"qi":34,"cd":5.5,"kind":"swords","dmg":1.7,"count":7,"speed":16.0,"color":c(.7,.9,1),"sfx":"swords","desc":"Conjures a storm of flying swords that hunt down nearby enemies."},
 "palm":{"name":"Heavenly Buddha Palm","icon":"skill_palm","realm":3,"qi":40,"cd":6.0,"kind":"palm","dmg":5.0,"radius":3.0,"stun":1.5,"range":6.0,"color":c(1,.85,.3),"sfx":"palm","desc":"A colossal golden palm crashes down, crushing and stunning foes."}}})

# ---------------------------------------------------------------- items
I={}
def item(id,name,typ,desc,price=0,sell=0,rarity=0,**k):
    d=dict(name=name,icon=id,type=typ,desc=desc,price=price,sell=sell,rarity=rarity); d.update(k); I[id]=d
item('apple','Spirit Apple','consumable','A crisp apple. Restores 15 HP.',12,5,hp=15)
item('pear','Honey Pear','consumable','A juicy pear. Restores 10 HP and 10 Qi.',14,6,hp=10,qi=10)
item('bread','Steamed Bread','consumable','Hearty bread. Restores 40 HP.',28,12,hp=40)
item('noodle_soup','Tofu Mushroom Noodle Soup','consumable','Hot soup. Heals over time and grants Well Fed (+15% attack for 3 min).',85,35,rarity=1,hot={"amount":120,"dur":12.0},buff={"id":"well_fed","name":"Well Fed","atk":1.15,"dur":180.0})
item('healing_pill','Healing Pill','consumable','Restores 90 HP.',120,45,hp=90)
item('qi_pill','Qi Pill','consumable','Restores 100 Qi.',150,55,qi=100)
item('cultivation_pill','Cultivation Pill','consumable','Grants 220 cultivation experience.',520,200,rarity=2,xp=220)
item('breakthrough_pill','Breakthrough Pill','consumable','Rare pill. Grants 1500 cultivation experience.',0,1500,rarity=3,xp=1500)
item('wooden_plank','Wooden Plank','material','Sturdy planks cut from timber.',20,8)
for m,(pc,sc,rr) in dict(copper=(0,12,0),iron=(0,20,0),silver=(0,45,1),gold=(0,120,2)).items():
    item(m+'_ore',m.capitalize()+' Ore','material','Raw ore. Smelt it at a smelter.',0,sc,rr)
for m,sc,rr in [('copper',40,0),('iron',70,0),('silver',160,1),('gold',450,2)]:
    item(m+'_bar',m.capitalize()+' Bar','material','A smelted bar. Used for forging, or sell for coin.',0,sc,rr)
item('axe','Woodcutter Axe','tool','Needed to chop trees and logs.',180,70,tool="axe")
item('pickaxe','Miner Pickaxe','tool','Needed to mine rocks and ore.',220,85,tool="pickaxe")
item('empty_bucket','Wooden Bucket','tool','Fill it at a well.',60,25,tool="bucket")
item('filled_bucket','Bucket of Water','tool','A bucket of fresh water. Needed for cooking soup.',0,40)
item('gourd','Spirit Gourd','trinket','Trinket: +4 Qi regeneration per second and +20% max Qi.',1800,600,rarity=2,qi_regen=4.0,max_qi_mult=1.2)
for id,n,s in [('hammer','Smith Hammer',90),('hoe','Farm Hoe',60),('scissor','Pruning Scissors',70),('scoop','Wooden Scoop',45)]:
    item(id,n,'junk','Tools of the trade. Sell for coin.',0,s)
WEAP=[('sword','Iron Sword',600,250),('short_katana','Short Katana',900,380),('long_katana','Long Katana',2600,1000),('dagger','Twin-Edge Dagger',350,150),('iron_spear','Iron Spear',1200,480),('wooden_spear','Wooden Spear',180,70),('bow','Hunter Bow',700,280)]
rar=dict(sword=0,short_katana=1,long_katana=2,dagger=0,iron_spear=1,wooden_spear=0,bow=1)
dsc=dict(sword='Balanced blade with a wide arc.',short_katana='Fast, agile blade with high crit chance.',long_katana='Heavy, long-reach blade with devastating finishers.',dagger='Blindingly fast strikes, high crit, short reach.',iron_spear='Long thrusts that pierce every foe in a line.',wooden_spear='A simple spear. Long reach, narrow thrust.',bow='Ranged. Hold attack to loose arrows; every 3rd shot fires three.')
for id,n,p,s in WEAP: item(id,n,'weapon',dsc[id],p,s,rarity=rar[id],weapon=id)
w('items.json',I)

# ---------------------------------------------------------------- weapons
w('weapons.json',{
 "sword":{"style":"slash","sprite":"w_sword","dmg":1.0,"reach":2.5,"arc":1.9,"dur":[0.26,0.26,0.42],"crit":0.15,"knock":260,"hand":0.25},
 "short_katana":{"style":"slash","sprite":"w_short_katana","dmg":0.86,"reach":2.2,"arc":1.8,"dur":[0.2,0.2,0.34],"crit":0.22,"knock":220,"hand":0.22},
 "long_katana":{"style":"slash","sprite":"w_long_katana","dmg":1.32,"reach":3.0,"arc":2.2,"dur":[0.3,0.3,0.5],"crit":0.15,"knock":320,"hand":0.28},
 "dagger":{"style":"slash","sprite":"w_dagger","dmg":0.62,"reach":1.7,"arc":1.9,"dur":[0.14,0.14,0.26],"crit":0.32,"knock":140,"hand":0.2},
 "wooden_spear":{"style":"thrust","sprite":"w_wooden_spear","dmg":0.95,"reach":3.3,"arc":0.6,"dur":[0.3,0.3,0.46],"crit":0.12,"knock":280,"hand":0.3},
 "iron_spear":{"style":"thrust","sprite":"w_iron_spear","dmg":1.22,"reach":3.6,"arc":0.6,"dur":[0.3,0.3,0.46],"crit":0.14,"knock":320,"hand":0.3},
 "bow":{"style":"shoot","sprite":"w_bow","dmg":0.85,"reach":15.0,"arc":0.2,"dur":[0.34,0.34,0.5],"crit":0.2,"knock":120,"hand":0.55,"arrow":"w_arrow"}})

# ---------------------------------------------------------------- stations + recipes
w('stations.json',{
 "smelter":{"name":"Furnace Smelter","sprite":"st_smelter","icon":"st_smelter","verb":"SMELT","footprint":[1.5,0.9],"blurb":"Smelt raw ore into bars."},
 "anvil":{"name":"Blacksmith Anvil","sprite":"st_anvil","icon":"st_anvil","verb":"FORGE","footprint":[1.0,0.7],"blurb":"Forge weapons from metal bars."},
 "table":{"name":"Crafting Table","sprite":"st_table","icon":"st_table","verb":"CRAFT","footprint":[1.7,0.9],"blurb":"Craft bows, spears, tools and buckets."},
 "cooking":{"name":"Cooking Fireplace","sprite":"st_cooking","icon":"st_cooking","verb":"COOK","footprint":[1.7,0.9],"blurb":"Cook food that heals and empowers."},
 "alchemy":{"name":"Alchemy Furnace","sprite":"st_alchemy","icon":"st_alchemy","verb":"BREW","footprint":[1.1,0.9],"blurb":"Refine fruit and spirit stones into pills."}})
def rc(id,st,name,inp,out,**k):
    d=dict(id=id,station=st,name=name,inputs=inp,outputs=out); d.update(k); return d
RC=[rc('r_copper_bar','smelter','Copper Bar',{'copper_ore':2},{'copper_bar':1}),rc('r_iron_bar','smelter','Iron Bar',{'iron_ore':2},{'iron_bar':1}),
    rc('r_silver_bar','smelter','Silver Bar',{'silver_ore':2},{'silver_bar':1}),rc('r_gold_bar','smelter','Gold Bar',{'gold_ore':2},{'gold_bar':1}),
    rc('r_dagger','anvil','Twin-Edge Dagger',{'iron_bar':2},{'dagger':1}),rc('r_short_katana','anvil','Short Katana',{'iron_bar':3,'wooden_plank':1},{'short_katana':1}),
    rc('r_sword','anvil','Iron Sword',{'iron_bar':3,'silver_bar':1,'wooden_plank':1},{'sword':1}),rc('r_iron_spear','anvil','Iron Spear',{'iron_bar':3,'wooden_plank':2},{'iron_spear':1}),
    rc('r_long_katana','anvil','Long Katana',{'iron_bar':4,'silver_bar':2,'wooden_plank':1},{'long_katana':1},coins=300),
    rc('r_wooden_spear','table','Wooden Spear',{'wooden_plank':3},{'wooden_spear':1}),rc('r_bow','table','Hunter Bow',{'wooden_plank':4,'copper_bar':1},{'bow':1}),
    rc('r_bucket','table','Wooden Bucket',{'wooden_plank':2,'iron_bar':1},{'empty_bucket':1}),rc('r_axe','table','Woodcutter Axe',{'wooden_plank':1,'iron_bar':1},{'axe':1}),
    rc('r_pickaxe','table','Miner Pickaxe',{'wooden_plank':1,'iron_bar':2},{'pickaxe':1}),
    rc('r_bread','cooking','Steamed Bread',{'apple':1,'pear':1},{'bread':2}),
    rc('r_soup','cooking','Noodle Soup',{'filled_bucket':1,'bread':2},{'noodle_soup':2},returns={'empty_bucket':1}),
    rc('r_healing','alchemy','Healing Pill',{'apple':2,'pear':1},{'healing_pill':2},stones=1),rc('r_qi','alchemy','Qi Pill',{'pear':2,'apple':1},{'qi_pill':2},stones=2),
    rc('r_cultivation','alchemy','Cultivation Pill',{'pear':3,'apple':3},{'cultivation_pill':1},stones=15)]
w('recipes.json',RC)

# ---------------------------------------------------------------- props / resources
def y(item,mn,mx,ch=1.0): return dict(item=item,min=mn,max=mx,chance=ch)
P={
 "tree_small":dict(sprite="tree_small",kind="tree",tool="axe",hits=3,respawn=240,collider=dict(r=0.28),sway=true,yields=[y('wooden_plank',1,2)],xp=1,verb="CHOP"),
 "tree_medium":dict(sprite="tree_medium",kind="tree",tool="axe",hits=4,respawn=260,collider=dict(r=0.35),sway=true,yields=[y('wooden_plank',2,3)],xp=2,verb="CHOP"),
 "tree_big":dict(sprite="tree_big",kind="tree",tool="axe",hits=6,respawn=300,collider=dict(r=0.5),sway=true,yields=[y('wooden_plank',3,5),y('apple',1,2,0.35)],xp=4,verb="CHOP"),
 "tree_sakura":dict(sprite="tree_sakura",kind="tree",tool="axe",hits=4,respawn=280,collider=dict(r=0.35),sway=true,yields=[y('wooden_plank',2,3),y('pear',1,1,0.3)],xp=3,verb="CHOP"),
 "tree_dead":dict(sprite="tree_dead",kind="tree",tool="axe",hits=3,respawn=300,collider=dict(r=0.35),sway=false,yields=[y('wooden_plank',1,3)],xp=1,verb="CHOP"),
 "log":dict(sprite="log",kind="log",tool="axe",hits=2,respawn=200,collider=dict(w=1.0,d=0.4),sway=false,yields=[y('wooden_plank',1,2)],xp=1,verb="CHOP"),
 "rock_small":dict(sprite="rock_small",kind="rock",tool="pickaxe",hits=3,respawn=260,collider=dict(w=0.6,d=0.4),sway=false,yields=[y('copper_ore',1,2,0.8),y('iron_ore',1,1,0.35)],xp=2,verb="MINE"),
 "rock_medium":dict(sprite="rock_medium",kind="rock",tool="pickaxe",hits=5,respawn=300,collider=dict(w=1.3,d=0.8),sway=false,yields=[y('iron_ore',1,3),y('copper_ore',1,2,0.5),y('silver_ore',1,1,0.3)],xp=4,verb="MINE"),
 "rock_big":dict(sprite="rock_big",kind="rock",tool="pickaxe",hits=8,respawn=360,collider=dict(w=2.2,d=1.3),sway=false,yields=[y('silver_ore',1,3),y('iron_ore',1,3),y('gold_ore',1,2,0.4)],xp=8,verb="MINE"),
 "bush_small":dict(sprite="bush_small",kind="bush",tool="",hits=1,respawn=150,collider=None,sway=true,yields=[y('apple',1,1,0.6),y('pear',1,1,0.5)],xp=1,verb="PICK"),
 "bush_medium":dict(sprite="bush_medium",kind="bush",tool="",hits=2,respawn=180,collider=None,sway=true,yields=[y('apple',1,2,0.8),y('pear',1,2,0.7)],xp=1,verb="PICK"),
 "spirit_small":dict(sprite="spirit_small",kind="spirit",tool="",hits=0,respawn=0,collider=dict(r=0.4),sway=false,yields=[],mult=1.0,capacity=60.0,verb="MEDITATE",glow=[0.5,0.8,1.0]),
 "spirit_medium":dict(sprite="spirit_medium",kind="spirit",tool="",hits=0,respawn=0,collider=dict(r=0.5),sway=false,yields=[],mult=2.0,capacity=60.0,verb="MEDITATE",glow=[0.5,0.8,1.0]),
 "spirit_big":dict(sprite="spirit_big",kind="spirit",tool="",hits=0,respawn=0,collider=dict(r=0.8),sway=false,yields=[],mult=4.0,capacity=60.0,verb="MEDITATE",glow=[0.6,0.85,1.0])}
w('props.json',P)

# ---------------------------------------------------------------- enemies
def atk(kind,**k): d={"kind":kind}; d.update(k); return d
def L(item,ch,mn=1,mx=1): return dict(item=item,chance=ch,min=mn,max=mx)
E={}
E['wolf']=dict(name="Grey Wolf",sprite="wolf",tag="wolf",hp=58,dmg=8,speed=4.8,aggro=11,radius=0.45,xp=9,coins=[4,14],stones=[0,1],loot=[L('apple',0.08)],ai="circle",
  attacks=[atk("lunge",range=4.2,windup=0.35,dist=4.2,speed=12,hit=1.1,recover=0.7,weight=1)],bio="Pack hunters that circle before lunging.")
E['boar']=dict(name="Wild Boar",sprite="boar",tag="boar",hp=115,dmg=14,speed=3.2,aggro=9,radius=0.55,xp=16,coins=[8,24],stones=[0,2],loot=[L('pear',0.1),L('bread',0.06)],ai="chase",
  attacks=[atk("charge",range=7.0,windup=0.7,dist=8,speed=10,hit=1.2,recover=1.0,weight=1)],bio="Telegraphs a brutal charge. Dodge sideways.")
E['bear']=dict(name="Brown Bear",sprite="bear",tag="bear",hp=280,dmg=24,speed=2.7,aggro=9,radius=0.8,xp=40,coins=[30,80],stones=[1,3],loot=[L('bread',0.15),L('iron_ore',0.25,1,2)],ai="chase",
  attacks=[atk("swipe",range=2.3,windup=0.55,reach=2.7,arc=140,recover=0.9,weight=2),atk("shockwave",range=3.5,windup=0.8,radius=3.2,recover=1.0,weight=1,dmgmul=0.8)],bio="Slow but crushing. Watch for the ground slam.")
E['bandit_male']=dict(name="Hooded Bandit",sprite="bandit_male",tag="bandit",hp=95,dmg=11,speed=3.6,aggro=10,radius=0.4,xp=18,coins=[15,50],stones=[0,2],loot=[L('dagger',0.03),L('wooden_spear',0.05),L('iron_ore',0.2,1,2),L('hammer',0.05)],ai="chase",
  attacks=[atk("swipe",range=1.9,windup=0.4,reach=2.2,arc=110,recover=0.6,weight=1)],bio="Brigands who ambush travellers on the roads.")
E['bandit_female']=dict(name="Bandit Blade",sprite="bandit_female",tag="bandit",hp=80,dmg=10,speed=4.2,aggro=10,radius=0.4,xp=18,coins=[15,50],stones=[0,2],loot=[L('short_katana',0.03),L('copper_ore',0.25,1,2),L('scissor',0.05)],ai="circle",
  attacks=[atk("swipe",range=1.9,windup=0.3,reach=2.2,arc=100,recover=0.5,weight=2),atk("lunge",range=3.8,windup=0.3,dist=3.4,speed=11,hit=1.0,recover=0.6,weight=1)],bio="Quick and elusive. Circles before striking.")
E['assassin_male']=dict(name="Shadow Assassin",sprite="assassin_male",tag="bandit",hp=75,dmg=16,speed=4.8,aggro=12,radius=0.4,xp=26,coins=[25,80],stones=[1,2],loot=[L('silver_ore',0.2),L('dagger',0.05)],ai="chase",
  attacks=[atk("blink",range=6.0,windup=0.4,reach=2.0,arc=120,recover=0.7,weight=1)],bio="Vanishes and reappears behind you.")
E['assassin_female']=dict(name="Night Blade",sprite="assassin_female",tag="bandit",hp=70,dmg=15,speed=5.0,aggro=12,radius=0.4,xp=26,coins=[25,80],stones=[1,2],loot=[L('silver_ore',0.2),L('short_katana',0.04)],ai="chase",
  attacks=[atk("blink",range=6.0,windup=0.35,reach=2.0,arc=120,recover=0.6,weight=2),atk("lunge",range=3.8,windup=0.25,dist=3.6,speed=13,hit=1.0,recover=0.5,weight=1)],bio="Deadly shadow dancer.")
E['bandit_boss']=dict(name="Iron Fang Warlord",sprite="bandit_boss",tag="bandit_boss",boss=true,hp=1100,dmg=30,speed=3.4,aggro=14,radius=0.7,xp=320,coins=[400,800],stones=[8,14],ai="chase",
  pack=[L('long_katana',0.5),L('cultivation_pill',1.0),L('healing_pill',1.0,2,3),L('silver_bar',0.8,1,3),L('gold_ore',0.7,1,2)],
  attacks=[atk("swipe",range=2.6,windup=0.5,reach=3.2,arc=150,recover=0.8,weight=3),atk("shockwave",range=4.5,windup=0.9,radius=4.0,recover=1.1,weight=2,dmgmul=0.9),atk("charge",range=8.0,windup=0.7,dist=7,speed=11,hit=1.4,recover=1.0,weight=1),atk("summon",range=12.0,windup=0.9,spawn="bandit_male",count=2,recover=0.8,weight=1,phase=2)],bio="Leader of the Iron Fang bandits.")
E['wolf_boss']=dict(name="Frost Fang Alpha",sprite="wolf_boss",tag="wolf_boss",boss=true,hp=800,dmg=22,speed=5.4,aggro=15,radius=0.7,xp=240,coins=[250,500],stones=[6,10],ai="circle",
  pack=[L('qi_pill',1.0,2,3),L('cultivation_pill',0.8),L('gourd',0.35),L('silver_ore',0.8,2,3)],
  attacks=[atk("lunge",range=5.0,windup=0.35,dist=5.0,speed=14,hit=1.4,recover=0.6,weight=3),atk("swipe",range=2.4,windup=0.35,reach=2.8,arc=140,recover=0.6,weight=2),atk("summon",range=14.0,windup=1.0,spawn="wolf",count=3,recover=0.8,weight=1,phase=2),atk("shockwave",range=4.0,windup=0.8,radius=3.6,recover=0.9,weight=1,phase=2,dmgmul=0.9)],bio="A spirit wolf wreathed in frost-fire.")
E['boar_boss']=dict(name="Thunder-Hide Tusker",sprite="boar_boss",tag="boar_boss",boss=true,hp=1000,dmg=28,speed=3.6,aggro=15,radius=0.8,xp=280,coins=[300,600],stones=[7,12],ai="chase",
  pack=[L('iron_spear',0.6),L('healing_pill',1.0,3,4),L('cultivation_pill',0.9),L('iron_bar',0.9,2,4),L('gold_ore',0.6,1,2)],
  attacks=[atk("charge",range=9.0,windup=0.6,dist=10,speed=13,hit=1.5,recover=0.9,weight=3),atk("shockwave",range=4.0,windup=0.8,radius=3.8,recover=1.0,weight=2,dmgmul=0.9),atk("swipe",range=2.5,windup=0.45,reach=3.0,arc=130,recover=0.7,weight=2),atk("summon",range=12.0,windup=1.0,spawn="boar",count=2,recover=0.8,weight=1,phase=2)],bio="A boar crackling with golden lightning.")
E['bear_boss']=dict(name="Golden-Mane Bear King",sprite="bear_boss",tag="bear_boss",boss=true,hp=1700,dmg=42,speed=3.0,aggro=15,radius=1.0,xp=520,coins=[800,1500],stones=[14,22],ai="chase",
  pack=[L('breakthrough_pill',1.0),L('cultivation_pill',1.0,1,2),L('gourd',0.5),L('gold_bar',0.9,1,3),L('long_katana',0.3)],
  attacks=[atk("swipe",range=3.2,windup=0.55,reach=3.8,arc=150,recover=0.9,weight=3),atk("shockwave",range=5.0,windup=1.0,radius=4.8,recover=1.2,weight=2,dmgmul=0.9),atk("charge",range=9.0,windup=0.8,dist=8,speed=11,hit=1.7,recover=1.1,weight=1,phase=2),atk("summon",range=14.0,windup=1.0,spawn="bear",count=1,recover=1.0,weight=1,phase=2)],bio="Ruler of the south-eastern mountains.")
w('enemies.json',E)

# ---------------------------------------------------------------- npcs
N={}
def npc(id,name,sprite,role,lines,**k):
    d=dict(name=name,sprite=sprite,role=role,lines=lines,wander=k.pop('wander',3.0),speed=1.2); d.update(k); N[id]=d
SHOP_FOOD=["apple","pear","bread","healing_pill","qi_pill"]
npc('elder_lin','Elder Lin','villager_elder_male','quest',["Young cultivator... wolves howl at our gates and the firewood runs low.","Qingyun Village is small, but it is home. Walk the Path with care."],quests=["q_wood","q_wolves"],wander=1.0)
npc('granny_mei','Granny Mei','villager_elder_female','quest',["Pears, apples, honey... an old woman's medicine. Bring me fruit and I will brew you something.","Never forget your roots, child, however high you climb."],quests=["q_fruit","q_bear_boss"],wander=1.5)
npc('farmer_han','Farmer Han','villager_male','talk',["The boars trample my fields. Hard to harvest anything with tusks around!","Chop trees, mine rocks, pick fruit from the bushes... the land provides for those who work it."])
npc('seamstress_yu','Yu','villager_female','talk',["My cousin studies at Haven Town. They say sitting under a spirit tree sharpens the mind.","Careful at night. The wolves grow bold."])
npc('boy_xiao','Little Xiao','villager_child_male','talk',["When I grow up I will fly on a sword like the legends!","Brother, can you really shoot fire from your hands?"],wander=5.0)
npc('girl_hua','Little Hua','villager_child_female','talk',["Shhh... the golden bear sleeps in the south-east. Grandma says never to wake it.","Do you have candy? No? Spirit stones then!"],wander=5.0)
npc('trader_ping','Trader Ping','trader_male','shop',["Tools, fruit and bread! Everything a traveller needs.","An axe for the trees, a pickaxe for the rocks. Honest work, honest prices."],shop=["axe","pickaxe","empty_bucket","apple","pear","bread"])
npc('smith_dao','Smith Dao','villager_male','quest',["Welcome to the Artisan Yard. Smelter for ore, anvil for steel, table for timber, fire for supper.","Bring me ore and I will show you what a blade is."],quests=["q_ore","q_forge"],wander=0.8)
npc('elder_bao','Elder Bao','town_elder_male','quest',["Haven Town watches every cultivator who walks the Path.","Prove yourself against the beasts and bandits, and the Town will remember your name."],quests=["q_boars","q_boar_boss"],wander=0.5)
npc('madam_shen','Madam Shen','town_elder_female','quest',["A frost-fire wolf leads the pack in the north-west. It is no ordinary beast.","Meditate at the Heart Tree when you tire. Its spirit renews all who sit beneath it."],quests=["q_wolf_boss"],wander=0.5)
npc('captain_ren','Captain Ren','town_male','quest',["Warlord Iron Fang has raided three caravans this month.","If you topple him, Haven Town will owe you a great debt."],quests=["q_bandit_boss"],wander=0.6)
npc('lady_mingyu','Lady Mingyu','town_female','talk',["Fly on your sword once you reach the Foundation realm. Rivers and lakes are only roads then.","Qi cannot be forced. Let it flow."])
npc('boy_wei','Little Wei','town_child_male','talk',["The big spirit tree glows brightest at night!","I saw a bandit once. He was very tall."],wander=5.0)
npc('girl_lin','Little Lin','town_child_female','talk',["My doll is a cultivator. She is a Golden Core already!","Mama says wealthy merchants have hidden treasure."],wander=5.0)
npc('merchant_qian','Merchant Qian','merchant_wealthy_male','shop_quest',["Spirit stones, silver or steel - I trade in all of it. Welcome!","Bandits keep robbing my caravans. Clear them out and I will pay handsomely."],quests=["q_bandits"],shop=["healing_pill","qi_pill","cultivation_pill","dagger","wooden_spear","bow"])
npc('merchant_lan','Merchant Lan','merchant_wealthy_female','shop',["Fine blades and finer trinkets! Everything half the price of the capital.","A cultivator without a good weapon is a cultivator in a coffin."],shop=["sword","short_katana","iron_spear","long_katana","gourd","healing_pill"])
npc('merchant_wu','Old Wu','trader_male','shop',["Buying ore, bars, tools, anything shiny! Selling pills and provisions.","Sell me your spare materials and I will pay in good coin."],shop=["healing_pill","qi_pill","bread","apple","pear","wooden_plank"])
npc('merchant_rong','Rong','trader_female','shop',["Fresh bread and fruit, still warm!","Hold still... lovely, you are not bleeding. Good."],shop=["apple","pear","bread","noodle_soup"])
npc('boss_merchant','Grand Merchant Zhao','merchant_boss','shop',["Hmph. Only the finest for the finest. Cultivation pills are my specialty.","Do not haggle. Do not stare. Buy."],shop=["cultivation_pill","gourd","long_katana","healing_pill","qi_pill"],wander=0.3)
w('npcs.json',N)

# ---------------------------------------------------------------- quests
Q={}
def q(id,name,desc,giver,kind,target,count,reward,**k):
    d=dict(name=name,desc=desc,giver=giver,kind=kind,target=target,count=count,reward=reward); d.update(k); Q[id]=d
q('q_wood','Firewood for Winter','Chop trees with your axe and bring 6 wooden planks to Elder Lin.','elder_lin','collect','wooden_plank',6,dict(xp=60,coins=250,items=dict(bread=2)),done_text="That will keep the village warm. Thank you, child.")
q('q_wolves','Howls at the Gate','Cull the grey wolves around Qingyun Village.','elder_lin','kill','wolf',5,dict(xp=90,coins=400,stones=3,items=dict(healing_pill=3)),done_text="The wolves will think twice now. Take this, child.")
q('q_fruit','An Old Woman\'s Medicine','Pick 5 apples from the bushes and bring them to Granny Mei.','granny_mei','collect','apple',5,dict(xp=50,coins=150,items=dict(qi_pill=2)),done_text="Sweet and sound. Now I can brew.")
q('q_ore','Ore for the Forge','Mine rocks with your pickaxe and bring 4 iron ore to Smith Dao.','smith_dao','collect','iron_ore',4,dict(xp=80,coins=300,items=dict(wooden_plank=2)),done_text="Good ore! Smelt it at the smelter, two ore per bar.")
q('q_forge','Your First Blade','Smelt iron ore into 3 iron bars and bring them to Smith Dao.','smith_dao','collect','iron_bar',3,dict(xp=140,coins=300,items=dict(short_katana=1)),after='q_ore',done_text="Fine work. Take this katana, forged by honest hands.")
q('q_boars','Tusks in the Grain','Hunt wild boars for Haven Town.','elder_bao','kill','boar',4,dict(xp=160,coins=700,stones=5,items=dict(qi_pill=3)),after='q_wolves',done_text="Good. The Town notes your name.")
q('q_bandits','Smoke on the Road','Defeat 8 bandits that raid Merchant Qian\'s caravans.','merchant_qian','kill','bandit',8,dict(xp=300,coins=1500,stones=8,items=dict(cultivation_pill=1)),after='q_boars',done_text="Wonderful! My caravans can roll again.")
q('q_wolf_boss','The Frost Fang Alpha','Slay the Frost Fang Alpha in the north-west wilds.','madam_shen','kill','wolf_boss',1,dict(xp=600,coins=1200,stones=15,items=dict(qi_pill=3,healing_pill=3)),after='q_boars',done_text="The wilds breathe again. Impressive.")
q('q_boar_boss','The Thunder-Hide Tusker','Slay the lightning-scarred Tusker in the northern thicket.','elder_bao','kill','boar_boss',1,dict(xp=900,coins=2000,stones=20,items=dict(cultivation_pill=2)),after='q_bandits',done_text="Even the beasts bow to your path.")
q('q_bandit_boss','Fall of the Iron Fang','Destroy the bandit warlord at the south-western camp.','captain_ren','kill','bandit_boss',1,dict(xp=1000,coins=2500,stones=25,items=dict(breakthrough_pill=1)),after='q_bandits',done_text="Haven Town owes you a debt. Take this pill.")
q('q_bear_boss','King of the Mountain','The Golden-Mane Bear King sleeps in the far south-east. Wake it, and end it.','granny_mei','kill','bear_boss',1,dict(xp=2200,coins=5000,stones=50,items=dict(breakthrough_pill=2)),after='q_wolf_boss',done_text="You actually did it. The Heavens are watching you now.")
w('quests.json',Q)
print('data2 ok: items',len(I),'recipes',len(RC),'enemies',len(E),'npcs',len(N),'quests',len(Q))
