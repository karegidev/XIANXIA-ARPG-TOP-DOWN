"""Asset pipeline v2 for ASSETS_FOR_XIANXIA_RPG.zip -> Godot project.
Cleans (haze, specks, edge AA), trims, sizes sprites from real-world metres, builds 96px icons + terrain atlas."""
import sys, os, json
sys.path.insert(0, '/home/claude/tools')
from spriteclean import *
from PIL import ImageDraw, ImageFilter

SRC = '/home/claude/newsrc/ASSETS FOR XIANXIA RPG'
OUT = '/home/claude/proj/XianxiaARPG'
PPM = 64.0
A = {}
def add(id, path, group, kind, mode, m, **kw): A[id] = dict(path=path, group=group, kind=kind, mode=mode, m=m, **kw)
P = 'Player character/'; V = 'Npcs and Buildings/Village/'; T = 'Npcs and Buildings/Town/'; B = 'Npcs and Buildings/Bandit/'; K = 'Npcs and Buildings/Beast/'; E = 'Environments/'; I = 'item and object/'; O = 'others/'

# ---- player realm forms (aura, sized by solid body) ----
for i, (id, f, h) in enumerate([('player_base','base form',1.75),('player_advanced','advanced form',1.77),('player_core','core form',1.79),('player_ultimate','ultimate form',1.82),('player_god','god form',1.85)]):
    add(id, P + f + '.png', 'player', 'aura', 'body', h)
# ---- village folk ----
for id, f, h in [('villager_male','male villager',1.70),('villager_female','female villager',1.60),('villager_child_male','child male villager',1.20),('villager_child_female','child female villager',1.15),('villager_elder_male','elder male villager',1.66),('villager_elder_female','elder female villager',1.50),('trader_male','common merchant male',1.70),('trader_female','common female merchant',1.62)]:
    add(id, V + f + '.png', 'npc', 'char', 'h', h)
# ---- town folk ----
for id, f, h in [('town_male','townsfolk male',1.74),('town_female','townsfolk female',1.62),('town_child_male','townsfolk child male',1.22),('town_child_female','townsfolk child female',1.17),('town_elder_male','townsfolk elder male',1.66),('town_elder_female','townsfolk elder female',1.52)]:
    add(id, T + f + '.png', 'npc', 'char', 'h', h)
for id, f, h in [('merchant_wealthy_male','wealthy merchant male',1.78),('merchant_wealthy_female','wealthy merchant female',1.68),('merchant_boss','wealthy merchant boss',2.25)]:
    add(id, T + f + '.png', 'npc', 'char', 'h', h)
# ---- bandits ----
for id, f, h in [('bandit_male','bandit male',1.76),('bandit_female','bandit female',1.64),('assassin_male','assassin male',1.74),('assassin_female','assassin female',1.66),('bandit_boss','bandit boss',2.10)]:
    add(id, B + f + '.png', 'enemy', 'char', 'h', h)
# ---- beasts (body length) ----
for id, f, w in [('wolf','wild wolf',1.70),('wolf_boss','boss wolf',2.45),('boar','wild boar',1.60),('boar_boss','boss boar',2.40),('bear','wild bear',2.10),('bear_boss','boss bear',2.95)]:
    add(id, K + f + '.png', 'enemy', 'beast', 'w', w)
# ---- buildings (footprint width) ----
for id, p, w in [('house_poor',V+'villager poor house.png',5.0),('house_common',V+'villager common house.png',6.2),('house_leader',V+'villager leader house.png',8.6),('well_village',V+'village well.png',2.0),
                 ('shop_common',V+'common merchant shop.png',7.0),('house_town',T+'townsfolk house common.png',6.6),('hall_town',T+'townsfolk leader house.png',9.6),('well_town',T+'town well.png',2.4),('shop_wealthy',T+'wealthy merchant shop.png',8.2)]:
    add(id, p, 'building', 'building', 'w', w)
# ---- environment props (height for trees, width for rocks/bushes) ----
for id, f, mode, m in [('tree_small','small tree','h',4.0),('tree_medium','medium tree','h',5.6),('tree_big','big tree','h',8.0),('tree_dead','dead tree','h',6.2),('tree_sakura','sakura tree','h',5.4),
                       ('spirit_small','small spirit tree','h',3.8),('spirit_medium','medium spirit tree','h',6.0),('spirit_big','big spirit tree','h',9.0),
                       ('rock_small','small rock','w',0.9),('rock_medium','medium rock','w',1.7),('rock_big','big rock','w',2.8),('bush_small','small bush','w',1.1),('bush_medium','medium bush','w',1.6),('log','log wood','w',1.4)]:
    add(id, E + f + '.png', 'prop', 'prop', mode, m, sparkle=id.startswith('spirit'))
# ---- crafting stations & objects ----
for id, p, mode, m in [('st_alchemy',O+'alchemy furnace.png','w',1.5),('st_anvil',O+'anvil.png','w',1.2),('st_cooking',O+'cooking fireplace.png','w',2.0),('st_table',O+'crafting table.png','w',2.0),('st_smelter',O+'furnace smelter.png','w',1.9),
                       ('obj_chest',I+'items/wooden chest.png','w',0.95),('obj_loot',O+'loot drop package.png','w',0.62)]:
    add(id, p, 'object', 'prop', mode, m)
# ---- in-hand weapons (pivot at the grip) ----
for id, f, mode, m, piv in [('w_sword','sword','w',1.10,0.0),('w_short_katana','short katana','w',0.95,0.0),('w_long_katana','long katana','w',1.35,0.0),('w_dagger','dagger','w',0.50,0.0),
                            ('w_wooden_spear','wooden spear','w',2.1,0.25),('w_iron_spear','iron spear','w',2.3,0.25),('w_bow','bow','h',1.25,-1),('w_arrow','arrow','w',0.75,0.0)]:
    add(id, I + 'weapon/' + f + '.png', 'weapon', 'item', mode, m, pivot=piv)
# ---- skill effects ----
for id, p, m, mode in [('fx_fireball','skills/projectiles/fireball.png',0.95,'w'),('fx_waterball','skills/projectiles/waterball.png',1.0,'w'),('fx_lightning','skills/projectiles/lightning ball.png',1.05,'w'),('fx_flying_sword','skills/mount/flying sword.png',1.5,'w')]:
    add(id, p, 'fx', 'item', mode, m)

def process(id, d):
    a = load(os.path.join(SRC, d['path'])); k = d['kind']; log = []
    al = a[..., 3]
    if k == 'aura':
        faint = (al > 0) & (al < 24); a[faint, 3] = 0; log.append('haze=%d' % faint.sum())
        a = remove_specks(a, min_px=14, abs_frac=0.0002); a = smooth_edge(a, aura=True)
    else:
        faint = (al > 0) & (al < 10); a[faint, 3] = 0
        keep = 8 if (d.get('sparkle') or id.endswith('boss') or id in ('wolf_boss','bear_boss','boar_boss')) else 30
        if k in ('item',) : keep = 6
        a = remove_specks(a, min_px=keep, abs_frac=0.0001); a = fill_pinholes(a, 6) if k in ('char',) else a
        a = smooth_edge(a, sigma=0.6)
    return a, log

def resize_pm(tr, nw, nh):
    f = tr.astype(np.float32); al = f[..., 3:4] / 255.0
    pm = np.concatenate([f[..., :3] * al, f[..., 3:4]], axis=2)
    ch = [np.array(Image.fromarray(pm[..., c]).resize((nw, nh), Image.LANCZOS)) for c in range(4)]
    r = np.stack(ch, axis=2); ra = np.clip(r[..., 3:4], 0, 255) / 255.0
    rgb = np.where(ra > 1e-3, r[..., :3] / np.maximum(ra, 1e-3), 0)
    return np.concatenate([np.clip(rgb, 0, 255), np.clip(r[..., 3:4], 0, 255)], axis=2).astype(np.uint8)

manifest = {'ppm': PPM, 'sprites': {}}
cleaned = {}
for id, d in A.items():
    a, log = process(id, d); cleaned[id] = a
for id, d in A.items():
    a = cleaned[id]
    solid = a[..., 3] >= (250 if d['kind'] == 'aura' else 128)
    ys, xs = np.where(solid); bx0, bx1, by0, by1 = xs.min(), xs.max(), ys.min(), ys.max()
    tr, (ox, oy) = trim(a, thr=1); th, tw = tr.shape[:2]
    feet_y = int(by1 - oy); body_cx = float((bx0 + bx1) / 2.0 - ox); body_h = int(by1 - by0 + 1); body_w = int(bx1 - bx0 + 1)
    native = body_h if d['mode'] == 'body' else (th if d['mode'] == 'h' else tw)
    target_px = d['m'] * PPM; scale = target_px / native
    art = scale * 2.0 if scale < 0.5 else 1.0
    nw, nh = max(1, int(round(tw * art))), max(1, int(round(th * art)))
    im = Image.fromarray(tr if art == 1.0 else resize_pm(tr, nw, nh))
    run = target_px / (native * art)
    gdir = os.path.join(OUT, 'assets', 'sprites', d['group']); os.makedirs(gdir, exist_ok=True)
    im.save(os.path.join(gdir, id + '.png'), optimize=True)
    ax, ay = body_cx * art, feet_y * art
    if d['kind'] == 'item' and d['group'] == 'weapon':
        pv = d.get('pivot', 0.0)
        if pv == -1: ax, ay = nw / 2.0, nh / 2.0
        else: ax, ay = nw * pv, nh / 2.0
    elif d['group'] == 'fx': ax, ay = nw / 2.0, nh / 2.0
    elif d['group'] == 'prop' and d['group'] == 'prop' and id in ('log','rock_small','rock_medium','rock_big','bush_small','bush_medium'):
        ax, ay = nw / 2.0, nh * 0.92 if id.startswith('bush') or id == 'log' else nh * 0.9
    elif d['kind'] in ('building','prop'):
        ax, ay = nw / 2.0, nh - 1.0
    manifest['sprites'][id] = dict(file='res://assets/sprites/%s/%s.png' % (d['group'], id), group=d['group'], kind=d['kind'], w=nw, h=nh,
        anchor=[round(ax, 1), round(ay, 1)], scale=round(run, 4), size_m=d['m'], size_mode=d['mode'],
        world_w_m=round(nw * run / PPM, 2), world_h_m=round(nh * run / PPM, 2), body_w_m=round(body_w * art * run / PPM, 2))
    flag = '  <-- UPSCALE %.2f' % run if run > 1.0 else ''
    print('%-22s trim %4dx%4d -> art %4dx%4d  scale %.3f  world %.2f x %.2f m%s' % (id, tw, th, nw, nh, run, nw * run / PPM, nh * run / PPM, flag))
os.makedirs(os.path.join(OUT, 'data'), exist_ok=True)
json.dump(manifest, open(os.path.join(OUT, 'data', 'sprites.json'), 'w'), indent=1)

# ================= ICONS (96px) =================
ICON = 96
def icon_from(path, out, pad=8, rot=0):
    a = load(os.path.join(SRC, path)); a[(a[..., 3] > 0) & (a[..., 3] < 10), 3] = 0
    a = remove_specks(a, min_px=6, abs_frac=0.0); tr, _ = trim(a)
    if rot:
        tr = np.array(Image.fromarray(tr).rotate(rot, expand=True, resample=Image.BICUBIC)); tr, _ = trim(tr)
    h, w = tr.shape[:2]; s = (ICON - pad * 2) / max(w, h)
    nw, nh = max(1, int(round(w * s))), max(1, int(round(h * s)))
    r = resize_pm(tr, nw, nh); canvas = Image.new('RGBA', (ICON, ICON), (0, 0, 0, 0))
    canvas.alpha_composite(Image.fromarray(r), ((ICON - nw) // 2, (ICON - nh) // 2)); canvas.save(os.path.join(OUT, 'assets', 'icons', out + '.png'), optimize=True)
ICONS = {
 'apple': I+'consumables/apple.png', 'pear': I+'consumables/peer.png', 'bread': I+'consumables/bread.png', 'noodle_soup': I+'consumables/bowl of tofu mushrooms noodle soup.png',
 'coin_copper': I+'currency/copper coin.png', 'coin_silver': I+'currency/silver coin.png', 'coin_gold': I+'currency/gold coin.png', 'coin_platinum': I+'currency/platinum coin.png',
 'spirit_stone': I+'currency/spirit stone.png', 'high_stone': I+'currency/high grade spirit stone.png',
 'wooden_plank': I+'items/wooden plank.png', 'chest': I+'items/wooden chest.png', 'loot_pack': O+'loot drop package.png',
 'copper_ore': I+'materials/copper ore.png', 'iron_ore': I+'materials/iron ore.png', 'silver_ore': I+'materials/silver ore.png', 'gold_ore': I+'materials/gold ore.png',
 'copper_bar': I+'materials/copper bar.png', 'iron_bar': I+'materials/iron bar.png', 'silver_bar': I+'materials/silver bar.png', 'gold_bar': I+'materials/gold bar.png',
 'axe': I+'tool/axe.png', 'empty_bucket': I+'tool/empty bucket.png', 'filled_bucket': I+'tool/filled water bucket.png', 'gourd': I+'tool/gourd.png', 'hammer': I+'tool/hammer.png',
 'hoe': I+'tool/hoe.png', 'pickaxe': I+'tool/pickaxe.png', 'scissor': I+'tool/scissor.png', 'scoop': I+'tool/scoop.png',
 'sword': I+'weapon/sword.png', 'long_katana': I+'weapon/long katana.png', 'short_katana': I+'weapon/short katana.png', 'dagger': I+'weapon/dagger.png',
 'iron_spear': I+'weapon/iron spear.png', 'wooden_spear': I+'weapon/wooden spear.png', 'bow': I+'weapon/bow.png', 'arrow': I+'weapon/arrow.png',
 'skill_fireball': 'skills/projectiles/fireball.png', 'skill_waterball': 'skills/projectiles/waterball.png', 'skill_lightning': 'skills/projectiles/lightning ball.png', 'skill_swords': 'skills/mount/flying sword.png',
 'st_alchemy': O+'alchemy furnace.png', 'st_anvil': O+'anvil.png', 'st_cooking': O+'cooking fireplace.png', 'st_table': O+'crafting table.png', 'st_smelter': O+'furnace smelter.png',
}
ROT = {'sword':42,'long_katana':42,'short_katana':42,'dagger':35,'iron_spear':42,'wooden_spear':42,'arrow':42,'skill_swords':42,'hoe':25}
for k, p in ICONS.items(): icon_from(p, k, rot=ROT.get(k, 0))

# procedural icons for things the pack has no art for (supersampled for smooth edges)
SS = 4
def new(): return Image.new('RGBA', (ICON * SS, ICON * SS), (0, 0, 0, 0))
def fin(im, name): im.resize((ICON, ICON), Image.LANCZOS).save(os.path.join(OUT, 'assets', 'icons', name + '.png'), optimize=True)
def pill(name, c1, c2, star=False):
    im = new(); d = ImageDraw.Draw(im); R = ICON * SS
    d.ellipse([R*0.16, R*0.16, R*0.84, R*0.84], fill=(20, 16, 30, 255))
    for i in range(30):
        t = i / 29.0; r = R*0.32*(1-t*0.9); cx, cy = R*0.5 - t*R*0.05, R*0.5 - t*R*0.05
        col = tuple(int(c1[j]*(1-t)+c2[j]*t) for j in range(3)) + (255,)
        d.ellipse([cx-r, cy-r, cx+r, cy+r], fill=col)
    d.ellipse([R*0.36, R*0.33, R*0.46, R*0.4], fill=(255, 255, 255, 200))
    if star:
        d.polygon([(R*0.5, R*0.28), (R*0.55, R*0.45), (R*0.72, R*0.5), (R*0.55, R*0.55), (R*0.5, R*0.72), (R*0.45, R*0.55), (R*0.28, R*0.5), (R*0.45, R*0.45)], fill=(255, 255, 255, 230))
    fin(im, name)
pill('healing_pill', (255, 120, 110), (150, 20, 40)); pill('qi_pill', (130, 190, 255), (20, 60, 170)); pill('cultivation_pill', (255, 235, 140), (200, 130, 20)); pill('breakthrough_pill', (220, 160, 255), (90, 30, 160), True)
# golden bell skill icon
im = new(); d = ImageDraw.Draw(im); R = ICON * SS
d.pieslice([R*0.22, R*0.14, R*0.78, R*0.74], 180, 360, fill=(235, 190, 60, 255), outline=(90, 55, 10, 255), width=SS*2)
d.polygon([(R*0.22, R*0.44), (R*0.78, R*0.44), (R*0.86, R*0.72), (R*0.14, R*0.72)], fill=(235, 190, 60, 255), outline=(90, 55, 10, 255))
d.rectangle([R*0.14, R*0.70, R*0.86, R*0.76], fill=(200, 150, 40, 255), outline=(90, 55, 10, 255), width=SS)
d.ellipse([R*0.42, R*0.72, R*0.58, R*0.86], fill=(120, 80, 20, 255)); d.ellipse([R*0.43, R*0.06, R*0.57, R*0.2], outline=(90, 55, 10, 255), width=SS*2)
for x in (0.34, 0.5, 0.66): d.line([(R*x, R*0.5), (R*(x+(x-0.5)*0.35), R*0.7)], fill=(255, 235, 140, 255), width=SS*2)
d.ellipse([R*0.3, R*0.24, R*0.42, R*0.34], fill=(255, 250, 200, 200)); fin(im, 'skill_bell')
# heavenly palm skill icon (glowing seal with hand-print)
im = new(); d = ImageDraw.Draw(im)
d.ellipse([R*0.08, R*0.08, R*0.92, R*0.92], fill=(255, 215, 90, 70)); d.ellipse([R*0.14, R*0.14, R*0.86, R*0.86], outline=(255, 215, 90, 255), width=SS*3)
d.ellipse([R*0.24, R*0.24, R*0.76, R*0.76], outline=(255, 235, 160, 200), width=SS*2)
d.rounded_rectangle([R*0.36, R*0.5, R*0.64, R*0.72], radius=R*0.05, fill=(255, 225, 120, 255), outline=(120, 70, 10, 255), width=SS*2)
for i, x in enumerate([0.355, 0.43, 0.505, 0.58]):
    top = [0.3, 0.24, 0.22, 0.28][i]
    d.rounded_rectangle([R*x, R*top, R*(x+0.06), R*0.56], radius=R*0.03, fill=(255, 225, 120, 255), outline=(120, 70, 10, 255), width=SS*2)
d.rounded_rectangle([R*0.6, R*0.46, R*0.72, R*0.54], radius=R*0.03, fill=(255, 225, 120, 255), outline=(120, 70, 10, 255), width=SS*2); fin(im, 'skill_palm')
print('icons', len(os.listdir(os.path.join(OUT, 'assets', 'icons'))))
