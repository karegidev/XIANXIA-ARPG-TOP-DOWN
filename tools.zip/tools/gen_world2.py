import json, math, random
random.seed(11)
W,H=120,80; T=2.0
g=[['g']*W for _ in range(H)]
def rect(ch,x0,y0,x1,y1):
    for y in range(max(0,y0),min(H,y1+1)):
        for x in range(max(0,x0),min(W,x1+1)): g[y][x]=ch
def blob(ch,cx,cy,rx,ry,only=('g',)):
    for y in range(H):
        for x in range(W):
            if ((x-cx)/rx)**2+((y-cy)/ry)**2<=1 and g[y][x] in only: g[y][x]=ch
for _ in range(60): blob('f',random.randint(0,W-1),random.randint(0,H-1),random.randint(3,7),random.randint(2,5))
rect('f',4,3,22,16); rect('f',36,3,50,14); rect('f',98,60,116,76)
for y in range(H):
    cx=62+5*math.sin(y*0.11)
    for x in range(W):
        if abs(x-cx)<=2.2: g[y][x]='w'
blob('w',76,70,13,8,only=('g','f','w'))
w_=[r[:] for r in g]
for y in range(H):
    for x in range(W):
        if w_[y][x]!='w':
            for dy in (-1,0,1):
                for dx in (-1,0,1):
                    yy,xx=y+dy,x+dx
                    if 0<=yy<H and 0<=xx<W and w_[yy][xx]=='w' and g[y][x] in ('g','f'): g[y][x]='s'
rect('d',21,35,43,56); rect('s',29,42,35,48)           # village + plaza
rect('c',40,45,86,46)                                    # trade road
for y in range(44,48):
    for x in range(52,72):
        if g[y][x]=='w': g[y][x]='c'                     # bridge
rect('o',46,39,53,51); rect('c',40,45,45,46)             # artisan yard (wood)
rect('c',84,40,104,54)                                   # merchant plaza
rect('p',84,6,106,24); rect('c',94,24,95,40)             # haven town + road
rect('m',12,60,36,76); rect('d',27,57,28,60)             # bandit camp
def path(x0,y0,x1,y1,ch='d',wd=1):
    n=int(max(abs(x1-x0),abs(y1-y0)))
    for i in range(n+1):
        x=int(round(x0+(x1-x0)*i/n)); y=int(round(y0+(y1-y0)*i/n))
        for dy in range(wd):
            for dx in range(wd):
                if 0<=y+dy<H and 0<=x+dx<W and g[y+dy][x+dx] not in ('w','c','p','o'): g[y+dy][x+dx]=ch
path(30,35,16,16); path(32,35,43,14); path(104,54,108,62); path(100,54,106,64)
legend={'g':'grass','f':'forest','d':'dirt_path','s':'sand','w':'water','c':'cobble','m':'mud','o':'wood','p':'paving'}
rows=[''.join(r) for r in g]
def P(x,y): return [round(x*T,2),round(y*T,2)]
B=[]
def bld(sprite,x,y,fw,fd,kind=None):
    d={"sprite":sprite,"pos":P(x,y),"footprint":[fw,fd]}
    if kind: d["kind"]=kind
    B.append(d)
bld('house_leader',32,38,6.6,2.6)
for (x,y) in [(25,42),(39,42),(26,52)]: bld('house_common',x,y,4.8,2.4)
for (x,y) in [(24,47.5),(38,48),(34,54)]: bld('house_poor',x,y,3.8,2.2)
bld('well_village',32,45.5,1.6,1.0,'well')
for (x,y,sp_) in [(89,44,'shop_common'),(99,44,'shop_wealthy'),(89,54,'shop_wealthy'),(99,54,'shop_common')]: bld(sp_,x,y,5.4,2.5)
bld('hall_town',95,12,7.6,3.0)
for (x,y) in [(87,11),(103,11),(88,20),(102,20)]: bld('house_town',x,y,5.0,2.4)
bld('well_town',95,19,1.9,1.1,'well')
ST=[]
for t,x,y in [('table',47.5,42),('anvil',50.5,42),('cooking',52.8,42.3),('smelter',47.5,49.5),('alchemy',50.5,49.5),('cooking',24,64)]: ST.append({"type":t,"pos":P(x,y)})
NP=[]
def npc(d,x,y): NP.append({"def":d,"pos":P(x,y)})
for d,x,y in [('elder_lin',31,43),('granny_mei',30,47),('farmer_han',26,45),('seamstress_yu',35,46),('boy_xiao',33,43.5),('girl_hua',29.5,43.5),('trader_ping',35.5,51)]: npc(d,x,y)
npc('smith_dao',50,45.5)
for d,x,y in [('elder_bao',91,17),('madam_shen',99,17),('captain_ren',95,22),('lady_mingyu',90,14.5),('boy_wei',92,21.5),('girl_lin',99,21.5)]: npc(d,x,y)
for d,x,y in [('merchant_qian',92,49),('merchant_lan',96,49),('merchant_wu',90,50.5),('merchant_rong',100,49.5),('boss_merchant',95,52)]: npc(d,x,y)
CH=[]
def chest(id,x,y,tier):
    loot={1:[("healing_pill",.8,1,2),("apple",.6,1,3),("copper_ore",.6,1,3),("wooden_plank",.5,2,4)],
          2:[("qi_pill",.7,1,2),("iron_ore",.8,2,4),("silver_ore",.5,1,2),("bread",.7,1,2),("dagger",.15,1,1)],
          3:[("cultivation_pill",.6,1,1),("silver_bar",.7,1,2),("gold_ore",.6,1,2),("short_katana",.2,1,1),("gourd",.08,1,1)]}[tier]
    coins={1:[60,180],2:[200,520],3:[600,1400]}[tier]
    CH.append({"id":id,"pos":P(x,y),"tier":tier,"coins":coins,"loot":[{"item":a,"chance":b,"min":c,"max":d} for a,b,c,d in loot]})
for id,x,y,t in [('c_camp1',17,62,2),('c_camp2',33,67,2),('c_camp3',19,74,3),('c_w1',46,24,1),('c_w2',74,16,1),('c_w3',14,28,1),('c_w4',70,60,2),('c_w5',113,40,2),('c_w6',60,74,1),('c_den',112,72,3),('c_lair',8,12,3),('c_thick',48,6,3)]: chest(id,x,y,t)
S=[]
def sp(e,x,y,r,c,resp=50): S.append({"enemy":e,"pos":P(x,y),"radius":round(r*T,1),"count":c,"respawn":resp})
sp('wolf',18,26,6,4); sp('wolf',30,22,6,3); sp('wolf',10,12,5,3); sp('wolf',46,28,5,3)
sp('boar',42,30,6,3); sp('boar',46,18,5,3); sp('boar',52,58,6,3)
sp('bear',104,66,6,2); sp('bear',112,28,6,2); sp('bear',60,10,4,1)
for e,x,y,c in [('bandit_male',20,70,3),('bandit_female',28,66,2),('assassin_male',24,73,2),('assassin_female',32,64,2),('bandit_male',16,63,2)]: sp(e,x,y,4,c,60)
sp('wolf_boss',12,9,3,1,300); sp('boar_boss',43,8,3,1,300); sp('bear_boss',107,68,3,1,420); sp('bandit_boss',24,68,2,1,420)
POI=[{"id":"village","name":"Qingyun Village","pos":P(32,45),"color":[.95,.85,.5]},{"id":"yard","name":"Artisan Yard","pos":P(50,45),"color":[.9,.6,.3]},
 {"id":"town","name":"Haven Town","pos":P(95,14),"color":[.5,.8,1]},{"id":"market","name":"Merchant Quarter","pos":P(95,47),"color":[1,.7,.4]},
 {"id":"camp","name":"Iron Fang Camp","pos":P(24,68),"color":[1,.4,.4]},{"id":"wolf_lair","name":"Frost Fang Lair","pos":P(12,9),"color":[.7,.8,1]},
 {"id":"boar_lair","name":"Tusker Thicket","pos":P(43,8),"color":[.8,.6,.5]},{"id":"bear_lair","name":"Bear King Den","pos":P(107,68),"color":[.9,.5,.3]},
 {"id":"heart","name":"Heart Tree","pos":P(109,14),"color":[.5,.9,1]}]
ZN=[{"name":"Qingyun Village","rect":[40,68,88,114],"safe":True},{"name":"Artisan Yard","rect":[90,76,108,104],"safe":True},{"name":"Haven Town","rect":[164,10,224,50],"safe":True},
 {"name":"Merchant Quarter","rect":[166,78,212,110],"safe":True},{"name":"Iron Fang Camp","rect":[24,120,72,152],"safe":False},{"name":"Frost Fang Lair","rect":[8,6,44,32],"safe":False},
 {"name":"Tusker Thicket","rect":[72,6,100,28],"safe":False},{"name":"Bear King Den","rect":[196,120,232,152],"safe":False}]
# ---------------- props ----------------
SP=[('spirit_small',14,42),('spirit_small',73,52),('spirit_medium',18,15),('spirit_medium',50,11),('spirit_medium',97,60),('spirit_big',109,14)]
props=[{"id":a,"pos":P(x,y)} for a,x,y in SP]
placed=[(x*T,y*T,3.0) for a,x,y in SP]
DECOR=[('bush_medium',22,38),('bush_medium',42,38),('bush_medium',22,54),('bush_medium',42,54),('tree_medium',19.5,44),('tree_small',44.5,40),('tree_medium',44.5,52),('tree_small',20,50),
  ('tree_sakura',86,7.5),('tree_sakura',104,7.5),('tree_sakura',86,23),('tree_sakura',104,23),('bush_medium',91,13),('bush_medium',99,13),
  ('bush_medium',85,41.5),('bush_medium',103,41.5),('bush_medium',85,52.5),('bush_medium',103,52.5),('bush_small',45.5,37.8),('bush_small',54.5,37.8)]
for a,x,y in DECOR:
    props.append({'id':a,'pos':P(x,y),'decor':True}); placed.append((x*T,y*T,1.6))

def near_any(x,y,r):
    for (px,py,pr) in placed:
        if (px-x)**2+(py-y)**2 < (pr+r)**2: return True
    return False
excl=[]
for b in B:
    fw,fd=b['footprint']; excl.append((b['pos'][0],b['pos'][1],max(fw,fd)*0.5+3.0))
for s in ST: excl.append((s['pos'][0],s['pos'][1],3.2))
for n in NP: excl.append((n['pos'][0],n['pos'][1],2.5))
for c in CH: excl.append((c['pos'][0],c['pos'][1],2.8))
for s in S: excl.append((s['pos'][0],s['pos'][1],s['radius']*0.35 if s['count']>1 else 4.0))
excl.append((P(33,46)[0],P(33,46)[1],5.0))
VILLAGE_RECT=(21*T,35*T,43*T,56*T)

YARD_RECT=(44*T,37*T,55*T,52*T)
def blocked(x,y):
    if YARD_RECT[0]<=x<=YARD_RECT[2] and YARD_RECT[1]<=y<=YARD_RECT[3]: return True
    if VILLAGE_RECT[0]<=x<=VILLAGE_RECT[2] and VILLAGE_RECT[1]<=y<=VILLAGE_RECT[3]: return True
    for (ex,ey,er) in excl:
        if (ex-x)**2+(ey-y)**2<er*er: return True
    return False
def tile(x,y): return g[int(y/T)][int(x/T)]
def scatter(tiles,kinds,count,dmin,region=None,tries=4000):
    n=0
    for _ in range(tries):
        if n>=count: break
        x=random.uniform(2,W*T-2); y=random.uniform(2,H*T-2)
        if tile(x,y) not in tiles: continue
        if region and not (region[0]<=x<=region[2] and region[1]<=y<=region[3]): continue
        if blocked(x,y): continue
        k=random.choices([a for a,b in kinds],[b for a,b in kinds])[0]
        r={'tree_big':2.4,'tree_medium':2.0,'tree_small':1.7,'tree_sakura':2.0,'tree_dead':1.8,'rock_big':2.0,'rock_medium':1.4,'rock_small':0.9,'bush_small':0.9,'bush_medium':1.1,'log':1.1}[k]
        if near_any(x,y,max(r,dmin)): continue
        props.append({"id":k,"pos":[round(x,2),round(y,2)]}); placed.append((x,y,r)); n+=1
    return n
forest=[('tree_big',20),('tree_medium',38),('tree_small',32),('tree_dead',3),('bush_medium',4),('rock_small',3)]
print('forest',scatter({'f'},forest,300,1.0))
print('grass trees',scatter({'g'},[('tree_medium',3),('tree_small',3),('tree_big',1)],45,2.0))
print('grass bushes',scatter({'g'},[('bush_small',5),('bush_medium',4)],85,1.2))
print('grass rocks',scatter({'g'},[('rock_small',6),('rock_medium',3),('rock_big',1),('log',2)],55,1.5))
print('sakura',scatter({'g','f'},[('tree_sakura',1)],14,2.0,region=(70,6,100,28)))
print('camp',scatter({'m'},[('tree_dead',4),('rock_small',3),('rock_medium',2),('log',3)],26,1.5))
print('den',scatter({'f','g'},[('rock_big',3),('rock_medium',3),('tree_dead',3)],18,2.2,region=(196,120,232,152)))
print('lair',scatter({'f','g'},[('rock_medium',2),('tree_dead',1),('bush_medium',1)],10,2.0,region=(8,6,44,32)))
print('sand',scatter({'s'},[('rock_small',4),('log',1)],14,1.2))
out={"tile_m":T,"size":[W,H],"legend":legend,"blocked":["w"],"rows":rows,"player_start":P(33,47.5),"buildings":B,"stations":ST,"npcs":NP,"chests":CH,"spawners":S,"pois":POI,"zones":ZN,"props":props}
json.dump(out,open('/home/claude/proj/XianxiaARPG/data/world.json','w'),separators=(',',':'))
print('props',len(props),'bytes',len(json.dumps(out)))
# preview
cols={'g':(137,159,112),'f':(95,120,85),'d':(176,119,76),'s':(237,208,169),'w':(94,129,148),'c':(118,132,146),'m':(90,60,50),'o':(165,106,72),'p':(193,185,170)}
from PIL import Image,ImageDraw
K=8; im=Image.new('RGB',(W*K,H*K)); d=ImageDraw.Draw(im)
for y in range(H):
    for x in range(W): d.rectangle([x*K,y*K,x*K+K-1,y*K+K-1],fill=cols[g[y][x]])
pc={'tree':(30,90,40),'rock':(110,110,115),'bush':(70,150,60),'log':(120,80,40),'spirit':(60,200,255)}
for p in props:
    k=p['id'].split('_')[0]; d.ellipse([p['pos'][0]*K/T*1-3,p['pos'][1]*K/T-3,p['pos'][0]*K/T+3,p['pos'][1]*K/T+3],fill=pc.get(k,(255,255,255)))
for b in B: d.rectangle([b['pos'][0]*K/T-10,b['pos'][1]*K/T-10,b['pos'][0]*K/T+10,b['pos'][1]*K/T],fill=(120,40,30))
for n in NP: d.ellipse([n['pos'][0]*K/T-4,n['pos'][1]*K/T-4,n['pos'][0]*K/T+4,n['pos'][1]*K/T+4],fill=(255,255,0))
for s in ST: d.rectangle([s['pos'][0]*K/T-5,s['pos'][1]*K/T-5,s['pos'][0]*K/T+5,s['pos'][1]*K/T+5],fill=(255,140,0))
for c in CH: d.rectangle([c['pos'][0]*K/T-4,c['pos'][1]*K/T-4,c['pos'][0]*K/T+4,c['pos'][1]*K/T+4],fill=(255,0,255))
for s in S: d.ellipse([s['pos'][0]*K/T-4,s['pos'][1]*K/T-4,s['pos'][0]*K/T+4,s['pos'][1]*K/T+4],fill=(255,0,0))
im.save('/home/claude/prev2/world2.png')
bad=[]
for b in B:
    if tile(*b['pos'])=='w': bad.append(('b',b['sprite']))
for n in NP:
    if tile(*n['pos'])=='w': bad.append(('n',n['def']))
for c in CH:
    if tile(*c['pos'])=='w': bad.append(('c',c['id']))
for s in S:
    if tile(*s['pos'])=='w': bad.append(('s',s['enemy']))
for s in ST:
    if tile(*s['pos'])=='w': bad.append(('st',s['type']))
print('on water:',bad)
