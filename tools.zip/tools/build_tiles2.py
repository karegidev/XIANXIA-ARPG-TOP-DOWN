import numpy as np, os, json
from PIL import Image
SRC='/home/claude/newsrc/ASSETS FOR XIANXIA RPG/Environments/tilesets'; OUT='/home/claude/proj/XianxiaARPG'
os.makedirs(OUT+'/assets/tiles',exist_ok=True)
TS=128
def load(n,size=512):
    im=Image.open(os.path.join(SRC,n)).convert('RGB')
    if im.width!=size: im=im.resize((size,size),Image.LANCZOS)
    return np.array(im).astype(np.float32)
def seamless(t,axes=(0,1)):
    N=t.shape[0]; s=t
    for ax in axes: s=np.roll(s,N//2,ax)
    x=np.linspace(0,1,N,endpoint=False); w=np.sin(np.pi*x)**2
    if axes==(0,1): W=np.outer(w,w)[...,None]
    elif axes==(1,): W=np.tile(w[None,:,None],(N,1,1))
    else: W=np.tile(w[:,None,None],(1,N,1))
    return np.clip(W*t+(1-W)*s,0,255)
MAP=[('grass','ground tile.png',(0,1)),('dirt_path','dirt tile.png',(0,1)),('sand','sand tile.png',(0,1)),('water','water tile.png',(0,1)),
     ('cobble','stone road tile.png',None),('slab','concrete floor.png',(0,1)),('wood','wood floor.png',(1,))]
tiles=[];ids=[]
for tid,fn,ax in MAP:
    t=load(fn)
    if ax: t=seamless(t,ax)
    tiles.append(np.array(Image.fromarray(t.astype(np.uint8)).resize((TS,TS),Image.LANCZOS)).astype(np.float32)); ids.append(tid)
g=tiles[0]; d=tiles[1]; sl=tiles[5]
tiles.append(np.clip(g*np.array([0.70,0.80,0.68]),0,255)); ids.append('forest')
tiles.append(np.clip(d*np.array([0.52,0.50,0.50]),0,255)); ids.append('mud')
tiles.append(np.clip(sl*np.array([1.02,0.97,0.90]),0,255)); ids.append('paving')
atlas=np.zeros((TS,TS*len(tiles),3),np.uint8)
for i,t in enumerate(tiles): atlas[:,i*TS:(i+1)*TS]=t.astype(np.uint8)
Image.fromarray(atlas).save(OUT+'/assets/tiles/terrain_atlas.png',optimize=True)
Image.fromarray(tiles[3].astype(np.uint8)).save(OUT+'/assets/tiles/water_tile.png',optimize=True)
cols={ids[i]:[round(float(c)/255,3) for c in tiles[i].reshape(-1,3).mean(0)] for i in range(len(ids))}
json.dump({'tile_px':TS,'tile_m':2.0,'ids':ids,'colors':cols},open(OUT+'/data/tiles.json','w'),indent=1)
for i,tid in enumerate(ids):
    t=atlas[:,i*TS:(i+1)*TS].astype(float)
    print('%-10s seam x %.1f y %.1f | interior x %.1f y %.1f'%(tid,np.abs(t[:,0]-t[:,-1]).mean(),np.abs(t[0]-t[-1]).mean(),np.abs(t[:,TS//2]-t[:,TS//2+1]).mean(),np.abs(t[TS//2]-t[TS//2+1]).mean()))
prev=Image.new('RGB',(TS*3*5,TS*3*2))
for i in range(len(ids)):
    t=Image.fromarray(atlas[:,i*TS:(i+1)*TS])
    for yy in range(3):
        for xx in range(3): prev.paste(t,((i%5)*TS*3+xx*TS,(i//5)*TS*3+yy*TS))
prev.resize((prev.width//2,prev.height//2)).save('/home/claude/prev2/tiles3x3.png')
