import re, os, glob, json, sys
ROOT='/home/claude/proj/XianxiaARPG'
os.chdir(ROOT)
files=glob.glob('scripts/**/*.gd',recursive=True)
errs=[]
def err(*a): errs.append(' '.join(map(str,a)))
src={f:open(f).read() for f in files}
# ---- member tables for autoloads
def members(path):
    s=open(path).read()
    m=set(re.findall(r'^(?:var|const|signal)\s+(\w+)',s,re.M))|set(re.findall(r'^func\s+(\w+)',s,re.M))|set(re.findall(r'^static var\s+(\w+)',s,re.M))
    return m
AL={'GameState':members('scripts/autoload/game_state.gd'),'GameData':members('scripts/autoload/game_data.gd'),'Sfx':members('scripts/autoload/sfx.gd')}
for f,s in src.items():
    t=re.sub(r'"(\\.|[^"\\])*"','""',s)
    t=re.sub(r'#.*','',t)
    lines=s.split('\n')
    # tabs only
    for i,l in enumerate(lines,1):
        if l.startswith(' ') and l.strip() and not l.strip().startswith('#'): err('SPACE-INDENT',f,i)
    for a,b in ('()','[]','{}'):
        if t.count(a)!=t.count(b): err('UNBALANCED',a,f,t.count(a),t.count(b))
    if ':=' in s: err(':= used',f)
    for p in re.findall(r'(?:pre)?load\("(res://[^"]+)"\)',s):
        if not os.path.exists(p.replace('res://','')): err('MISSING',f,p)
    m=re.match(r'extends\s+"(res://[^"]+)"',s)
    if m and not os.path.exists(m.group(1).replace('res://','')): err('MISSING extends',f)
    # block structure
    def indent(l): return len(l)-len(l.lstrip('\t'))
    for i,l in enumerate(lines):
        st=l.strip()
        if not st or st.startswith('#'): continue
        code=re.sub(r'#.*','',re.sub(r'"(\\.|[^"\\])*"','""',st)).rstrip()
        if code.endswith(':') and not code.endswith('::'):
            # find next code line
            j=i+1
            while j<len(lines) and (not lines[j].strip() or lines[j].strip().startswith('#')): j+=1
            if j>=len(lines) or indent(lines[j])<=indent(l): err('EMPTY BLOCK',f,i+1,st[:60])
    # autoload member refs
    for name,mem in AL.items():
        for ref in set(re.findall(r'\b'+name+r'\.(\w+)',s)):
            if ref not in mem: err('UNKNOWN MEMBER',name+'.'+ref,'in',f)
    # string literal ids
    for sid in set(re.findall(r'(?:make_sprite|GameData\.tex|sprite_info|sprite_height_px)\("([a-z_0-9]+)"\)',s)):
        if sid not in json.load(open('data/sprites.json'))['sprites']: err('UNKNOWN SPRITE',sid,f)
    for iid in set(re.findall(r'(?:GameData\.icon)\("([a-z_0-9]+)"\)',s)):
        if not os.path.exists('assets/icons/%s.png'%iid): err('UNKNOWN ICON',iid,f)
    for sn in set(re.findall(r'Sfx\.play\("([a-z_]+)"',s)):
        if '"%s"'%sn not in open('scripts/autoload/sfx.gd').read(): err('UNKNOWN SFX',sn,f)
# all func names for call checks on typed-known targets
allf=set()
for s in src.values(): allf|=set(re.findall(r'^\s*func\s+(\w+)',s,re.M))
for f,s in src.items():
    for m in re.finditer(r'\b(?:player|world|fx|hud|controls|menu|dialogue|npc|e|o|p|n|node|target|tree|st|GameState\.world|GameState\.player|GameState\.world\.fx|w|fxn)\.([a-z_]+)\(',s):
        nm=m.group(1)
        if nm not in allf and nm not in set('add_child queue_free get_nodes_in_group connect emit set_physics_process distance_to normalized bind has_point is_empty append erase get keys pop_front pop_back set_deferred add_to_group remove_from_group get_children set_process move_toward lerp length angle clear find split substr begins_with replace size min max duplicate set_anchors_preset create_timer reset_smoothing set_shader_parameter reparent create_tween tween_property tween_callback chain set_parallel set_ease set_trans set_delay get_viewport_rect get_instance_id from_angle move_child set_cell has has_method call is_in_group lerp_to cross dot get_size get_width get_height sort set_zoom bind get_noise_2d get_tile_data create_tile create_alternative_tile add_source join set_pixel create_from_image resize to_lower is_valid is_valid_float limit_length slice rotated round floor ceil'.split()): err('UNKNOWN METHOD?',nm,f)
print('\n'.join(errs) if errs else 'LINT OK',len(files),'files')
