import json
G=[]
def t(id,title,icon,body,dyn=""): G.append(dict(id=id,title=title,icon=icon,body=body,dynamic=dyn))
t("start","Getting Started","skill_swords",[
 "WELCOME, cultivator! You begin in Qingyun Village with a sword, an axe, a pickaxe, a bucket, a few pills and some coin.",
 "1. Talk to NPCs with a golden ! above their head (press the TALK button when it appears). Elder Lin gives your first quests.",
 "2. Fight wolves outside the village to earn Qi (cultivation XP), coins and loot. Watch the red warning zones on the ground - they show where an attack will land.",
 "3. Chop trees and mine rocks (press CHOP / MINE near them, HOLD the button to keep swinging). Planks and ore are used for crafting.",
 "4. Visit the Artisan Yard (just east of the village) to smelt ore, forge weapons, cook food and brew pills.",
 "5. Level up, then BREAKTHROUGH to the next realm (see the Cultivation topic). Each realm changes your look, boosts your stats and unlocks new skills.",
 "HUD guide: red bar = HP, blue = Qi (skills and flying), green = stamina (dash), gold = cultivation progress. Top-right is the minimap. Quests are tracked under your bars."])
t("controls","Controls","sword",[
 "LEFT STICK (touch anywhere on the left side): move.",
 "Big WEAPON button: attack. HOLD it to chain a 3-hit combo - the 3rd hit is a heavy finisher. The game aims at the nearest enemy for you.",
 "DASH: a quick dodge with brief invulnerability. Costs stamina.",
 "FLY: ride your flying sword (unlocked at the Foundation Establishment realm).",
 "6 SKILL buttons (arc above the weapon button): each costs Qi and has a cooldown. Locked skills show R2, R3... = the realm that unlocks them.",
 "HP and QI buttons: quickly use a healing pill or Qi pill from your bag.",
 "CONTEXT button (appears near things): TALK, SHOP, CHOP, MINE, PICK, MEDITATE, OPEN, FILL, FORGE, SMELT, CRAFT, COOK, BREW. HOLD it to keep chopping or mining.",
 "MENU button (top, left of the minimap) or the Android Back button opens the menu: Status, Guide, Gear, Bag, Skills, Quests, Codex, Map, Settings, System.",
 "Settings lets you change control size and opacity, go left-handed, adjust camera zoom, sound volume, screen shake and more."])
t("combat","Combat","dagger",[
 "COMBO: attacks chain automatically while you hold the weapon button. Hit 3 is stronger and knocks enemies back.",
 "DASH has invulnerability frames. PERFECT DODGE: dash at the exact moment an enemy's attack would hit you. Time slows for a moment, you recover stamina and Qi, and you deal +50% damage and extra crits for 3 seconds (FOCUS).",
 "SKILLS: Crimson Fireball (burns), Azure Torrent Orb (pierces and slows), Heavenly Thunder Orb (chain lightning), Golden Bell Shield (absorbs damage, then shatters and stuns), Ten Thousand Swords (homing blades), Heavenly Buddha Palm (huge stunning slam). Check the Skills tab for details and unlock realms.",
 "RED WARNING ZONES: enemies show where they will strike. Cone = swipe, line = charge or lunge, circle = ground slam. Move out of it, or dash through it for a perfect dodge.",
 "ELITE monsters have a gold ring: much tougher, but they drop twice the loot. BOSSES have a big health bar on screen and become enraged below 50% health. Bosses drop a Loot Pack and a High-Grade Spirit Stone.",
 "If you fall in battle you wake in the village and lose 10% of your coins. Eat food and use pills before big fights."],"weapons")
t("cultivation","Cultivation & Breakthrough","qi_pill",[
 "Your power comes from CULTIVATION. You have a REALM (5 in total) and each realm has 9 STAGES. Every stage raises your HP, Qi and attack a little.",
 "HOW TO GAIN QI (cultivation XP): defeat monsters, complete quests, MEDITATE at Spirit Trees (see that topic), drink Cultivation Pills, and even gather and craft for small amounts.",
 "STEP 1 - Reach stage 9: keep gaining Qi until you hit stage 9 of your realm.",
 "STEP 2 - Fill the gold bar: at stage 9 the gold cultivation bar must be completely full. When it is, a message appears: 'Cultivation complete!' and the HUD shows [Breakthrough ready].",
 "STEP 3 - Collect SPIRIT STONES: each breakthrough costs spirit stones (see the cost table below). The HUD tells you if you are short.",
 "STEP 4 - Open MENU > Status and tap the big BREAKTHROUGH button. You ascend: a new realm, a new look, full HP/Qi, and new skills.",
 "WHERE TO GET SPIRIT STONES: monsters drop them (bosses drop lots plus a High-Grade Stone worth 100), quests reward them, and you can buy Spirit Stone Pouches (10 stones each) from Grand Merchant Zhao or Merchant Qian in the Merchant Quarter. Alchemy also uses a few stones.",
 "REWARDS: Foundation Establishment unlocks FLYING and the Golden Bell + Thunder Orb. Golden Core unlocks Ten Thousand Swords. Nascent Soul unlocks the Heavenly Buddha Palm. Dao Ascendant is the peak."],"breakthrough")
t("meditation","Spirit Trees & Meditation","spirit_stone",[
 "Glowing blue trees are SPIRIT TREES. Walk up to one and press MEDITATE. You sit and gain Qi, Qi regeneration and HP every second - a great way to cultivate safely.",
 "Move the stick to stop meditating. Taking damage also interrupts you.",
 "Each tree has a limited charge (about one minute of meditation) and slowly recharges over several minutes. A drained tree looks dim.",
 "Small trees give 1x, medium trees 2x, and the big HEART TREE (just east of Haven Town) gives 4x. More are scattered in the wilds - check the Map tab."])
t("gathering","Gathering","pickaxe",[
 "Stand near a tree or log and press CHOP (needs the Woodcutter Axe). Rocks need the Miner Pickaxe - press MINE. Bushes can be picked by hand (PICK).",
 "HOLD the button to keep swinging. Each node takes a few hits, then drops materials and later grows back.",
 "TREES and LOGS give Wooden Planks (big trees can drop apples). SMALL rocks give copper ore, MEDIUM rocks iron and silver ore, BIG rocks silver and gold ore. BUSHES give apples and pears.",
 "If you lose a tool, buy another from Trader Ping in the village, or craft one at the Crafting Table.",
 "WELLS (in the village and Haven Town): press FILL with an empty bucket to get a Bucket of Water (needed for cooking soup). Without a bucket you can DRINK to restore stamina."])
t("crafting","Crafting","st_anvil",[
 "All crafting stations stand in the ARTISAN YARD (east edge of Qingyun Village, across from the river bridge). A cooking fireplace also sits in the bandit camp.",
 "Walk up and press SMELT / FORGE / CRAFT / COOK / BREW. The station lists every recipe; ingredients are green if you have enough and red if not.",
 "THE ORE CHAIN: mine ore -> Furnace Smelter (2 ore = 1 bar) -> Anvil (bars + planks = weapons) -> equip it in MENU > Gear.",
 "THE FOOD CHAIN: pick apples and pears -> Cooking Fireplace (bread) -> fill a bucket at a well -> noodle soup (heals over time and gives +15% attack for 3 minutes).",
 "THE PILL CHAIN: apples, pears and a few spirit stones -> Alchemy Furnace -> healing, Qi and cultivation pills.",
 "Crafting also gives a little cultivation XP. Here is the full recipe list:"],"recipes")
t("gear","Weapons, Gear & Items","long_katana",[
 "Open MENU > Gear to see your equipped weapon and trinket, and to equip anything you own. Open MENU > Bag to use pills and food.",
 "WEAPON STYLES: swords and katanas SLASH in an arc; spears THRUST in a long narrow line and pierce several enemies; the bow SHOOTS arrows from a distance (every 3rd shot fires three arrows).",
 "The dagger is the fastest with the best crit chance, the long katana hits hardest with the longest sword reach.",
 "TRINKET slot: the Spirit Gourd gives +20% max Qi and +4 Qi regeneration per second. Bosses and the weapon merchant sell or drop them.",
 "FOOD gives HP and sometimes a timed buff (shown on the HUD). Pills restore HP, Qi, or give cultivation XP.",
 "You can only sell items you do not have equipped."])
t("money","Coins, Shops & Stones","coin_gold",[
 "COINS: 100 copper = 1 silver, 100 silver = 1 gold, 100 gold = 1 platinum. Your purse is shown on the HUD with the gold coin icon.",
 "SPIRIT STONES (blue gem) are separate: they pay for breakthroughs and alchemy. High-Grade Stones (purple crystal) are worth 100 stones and drop from bosses.",
 "MERCHANTS (look for SHOP): Browse wares to buy, and Sell items to sell ore, bars, food, tools and spare weapons for coin. Gold and silver bars sell for a lot.",
 "Trader Ping (village) sells tools and food. Old Wu and Rong sell provisions. Merchant Lan sells weapons and the Spirit Gourd. Merchant Qian and Grand Merchant Zhao sell pills and Spirit Stone Pouches.",
 "CHESTS: wooden chests are hidden around the world, especially in the bandit camp and beast lairs. Press OPEN for coins and loot."])
t("quests","Quests & Progress","chest",[
 "NPCs with a golden ! have a new quest. A green ? means a quest is ready to turn in - talk to them again.",
 "KILL quests count enemies automatically. COLLECT quests count the items in your bag - gather them, then hand them in (they are taken from your bag).",
 "Quests unlock in chains: Elder Lin (wolves) -> Elder Bao in Haven Town (boars) -> Merchant Qian (bandits) -> boss hunts. Smith Dao teaches you ore and forging.",
 "The Quests tab shows what is active and what you can still pick up. The Codex tab records every creature you have defeated.",
 "The game auto-saves every two minutes. You can also save manually in MENU > System."])
t("flying","Flying Sword","skill_swords",[
 "At the Foundation Establishment realm the FLY button unlocks. Tap it to ride your flying sword: you move much faster and can cross rivers and lakes.",
 "Flying drains Qi steadily and you cannot attack or use skills while flying. Tap LAND to dismount, or you will drop automatically when your Qi runs out.",
 "If you land over water you are carried to the nearest shore. Use it to take shortcuts across the river and lake."])
t("world","The World & Tips","chest",[
 "QINGYUN VILLAGE (start, safe): elders, trader, wells. ARTISAN YARD (safe): all crafting stations. HAVEN TOWN (safe, north-east): town elders, captain, the big Heart Tree. MERCHANT QUARTER (safe, east): shops.",
 "WILDS: wolves roam north-west and around the village, boars north, bears far east and south-east. IRON FANG CAMP (south-west): bandits and a warlord boss with chests. Beast lairs hold bosses in the far corners.",
 "The Map tab marks every point of interest. Safe zones show a green banner; danger zones show an orange one.",
 "TIPS: dash through red zones for perfect dodges; keep a few pills in the HP/QI buttons; cook soup before bosses; meditate to recharge safely; mount your sword to escape; elite monsters are worth the risk.",
 "Stuck? Use MENU > Quests to see what to do next, and MENU > Guide any time."])
json.dump(G,open('/home/claude/proj/XianxiaARPG/data/guide.json','w'),indent=1)
print(len(G),'topics')
