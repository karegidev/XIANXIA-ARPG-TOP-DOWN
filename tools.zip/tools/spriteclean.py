"""Sprite cleanup pipeline for the Xianxia ARPG asset pack.
Goals: remove baked-in matte/halo/mist, kill stray specks, give every sprite a clean
anti-aliased 1-2px edge, WITHOUT touching interior pixel art (no visual corruption)."""
import numpy as np, cv2
from PIL import Image
from scipy import ndimage as ndi

K3 = np.ones((3, 3), np.uint8)

def load(p):
    return np.array(Image.open(p).convert('RGBA'))

def lum_of(a):
    return a[..., :3].astype(np.int32).mean(2)

def exterior_zone(solid, px=3):
    ext = ~solid
    return cv2.dilate(ext.astype(np.uint8), np.ones((2 * px + 1, 2 * px + 1), np.uint8)) > 0

def label_touching(mask, zone):
    lab, n = ndi.label(mask)
    if n == 0:
        return np.zeros_like(mask)
    ids = np.unique(lab[zone & (lab > 0)])
    return np.isin(lab, ids[ids > 0])

# ---------- baked dark navy "plate" (halo) around characters ----------
def remove_matte(a, grow=2):
    rgb = a[..., :3].astype(np.int32)
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    lum = rgb.mean(2)
    solid = a[..., 3] > 40
    core = solid & (lum >= 10) & (lum <= 38) & ((b - r) >= 0) & ((b - r) <= 16) & (np.abs(r - g) <= 7)
    rem = label_touching(core, exterior_zone(solid, 3))
    # grow into neighbouring dark low-saturation noise, never into pure black outline
    mx = rgb.max(2); mn = rgb.min(2)
    soft = solid & (lum >= 9) & (lum <= 52) & ((mx - mn) <= 30)
    for _ in range(grow):
        nb = cv2.dilate(rem.astype(np.uint8), K3) > 0
        rem = rem | (nb & soft)
    out = a.copy()
    out[rem, 3] = 0
    return out, int(rem.sum())

# ---------- baked blue mist behind animals ----------
def remove_mist(a, lum_max=80, bd=7, erode=1):
    rgb = a[..., :3].astype(np.int32)
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    lum = rgb.mean(2)
    solid = a[..., 3] > 40
    cand = solid & ((b - r) >= bd) & (lum < lum_max)
    core = cv2.erode(cand.astype(np.uint8), K3, iterations=erode) > 0
    rem = label_touching(core, exterior_zone(solid, 3))
    rem = cv2.dilate(rem.astype(np.uint8), K3, iterations=erode + 1) > 0
    rem &= cand
    out = a.copy(); out[rem, 3] = 0
    return out, int(rem.sum())

def drop_bluish_wisps(a, keep_frac=0.05):
    """remove detached components that are small & blue-ish (qi wisps floating off the feet)"""
    solid = a[..., 3] > 40
    lab, n = ndi.label(solid)
    if n <= 1: return a
    sizes = ndi.sum(solid, lab, range(1, n + 1)); big = sizes.max()
    out = a.copy()
    for i, s in enumerate(sizes, 1):
        if s >= big * keep_frac: continue
        m = lab == i
        rgb = a[m][:, :3].astype(int)
        if (rgb[:, 2] - rgb[:, 0]).mean() > 6 or s < 120:
            out[m, 3] = 0
    return out

# ---------- generic cleanup ----------
def remove_specks(a, min_px=60, abs_frac=0.002, keep_halo=3):
    al = a[..., 3]
    solid = al > 127
    lab, n = ndi.label(solid)
    if n == 0: return a
    sizes = ndi.sum(solid, lab, range(1, n + 1))
    big = sizes.max()
    ids = [i + 1 for i, s in enumerate(sizes) if s >= max(min_px, abs_frac * big)]
    keep = np.isin(lab, ids)
    zone = cv2.dilate(keep.astype(np.uint8), np.ones((2 * keep_halo + 1, 2 * keep_halo + 1), np.uint8)) > 0
    out = a.copy(); out[~zone, 3] = 0
    return out

def fill_pinholes(a, max_area=12):
    al = a[..., 3]
    solid = al > 127
    holes = ndi.binary_fill_holes(solid) & ~solid
    lab, n = ndi.label(holes)
    if n == 0: return a
    sizes = ndi.sum(holes, lab, range(1, n + 1))
    fill = np.isin(lab, [i + 1 for i, s in enumerate(sizes) if s <= max_area])
    if not fill.any(): return a
    out = a.copy()
    # take colour from nearest solid pixel
    idx = ndi.distance_transform_edt(~solid, return_distances=False, return_indices=True)
    out[fill, :3] = a[idx[0][fill], idx[1][fill], :3]
    out[fill, 3] = 255
    return out

def smooth_edge(a, sigma=0.75, aura=False):
    """re-derive a clean anti-aliased 1-2px alpha edge; fix colour fringe on edge pixels"""
    al = a[..., 3].astype(np.float32) / 255.0
    core = al >= 0.5
    inner = cv2.erode(core.astype(np.uint8), K3, iterations=2) > 0
    outer = cv2.dilate(core.astype(np.uint8), K3, iterations=2) > 0
    band = outer & ~inner
    soft = cv2.GaussianBlur(core.astype(np.float32), (0, 0), sigma)
    new_a = np.clip((soft - 0.12) / 0.76, 0, 1)
    final = al.copy()
    if aura:
        # keep semi-transparent aura glow untouched; only polish the very edge of the solid body
        solid_body = al >= 0.98
        b_inner = cv2.erode(solid_body.astype(np.uint8), K3, iterations=2) > 0
        b_outer = cv2.dilate(solid_body.astype(np.uint8), K3, iterations=1) > 0
        bband = b_outer & ~b_inner & (al >= 0.2)
        body_soft = cv2.GaussianBlur(solid_body.astype(np.float32), (0, 0), sigma)
        cand = np.clip((body_soft - 0.12) / 0.76, 0, 1)
        final = np.where(bband, np.maximum(cand, 0.0) * 1.0, final)
        final = np.where(bband & (al > cand), al, final)
        out = a.copy(); out[..., 3] = (np.clip(final, 0, 1) * 255 + 0.5).astype(np.uint8)
        out[out[..., 3] == 0, :3] = 0
        return out
    final = np.where(band, new_a, np.where(inner, 1.0, 0.0))
    out = a.copy()
    out[..., 3] = (final * 255 + 0.5).astype(np.uint8)
    # colour: any pixel that was not fully opaque (or newly opaque) takes colour of nearest solid interior pixel
    need = (final > 0) & (al < 0.98)
    if need.any():
        src = al >= 0.98
        idx = ndi.distance_transform_edt(~src, return_distances=False, return_indices=True)
        out[need, :3] = a[idx[0][need], idx[1][need], :3]
    out[out[..., 3] == 0, :3] = 0
    return out

# ---------- player aura forms: dark semi-transparent smudge removal ----------
def remove_dark_haze(a, solid_thr=250):
    al = a[..., 3]
    rgb = a[..., :3].astype(np.int32)
    lum = rgb.mean(2); sat = rgb.max(2) - rgb.min(2)
    core = al >= solid_thr
    near = cv2.dilate(core.astype(np.uint8), np.ones((3, 3), np.uint8), iterations=1) > 0
    haze = (al > 0) & (al < solid_thr) & (lum < 95) & (sat < 60) & ~near
    out = a.copy(); out[haze, 3] = 0
    return out, int(haze.sum())

# ---------- flat plate on a rectangle (wealthy merchant male) ----------
def remove_flat_plate(a, tol=9):
    al = a[..., 3] > 0
    ys, xs = np.where(al)
    y0, y1, x0, x1 = ys.min(), ys.max(), xs.min(), xs.max()
    reg = a[y0:y1 + 1, x0:x1 + 1, :3].astype(np.int32)
    border = np.concatenate([reg[:4].reshape(-1, 3), reg[-4:].reshape(-1, 3), reg[:, :4].reshape(-1, 3), reg[:, -4:].reshape(-1, 3)])
    ref = np.median(border, axis=0)
    close = (np.abs(reg - ref).max(2) <= tol)
    # flood from border only
    lab, n = ndi.label(close)
    edge_ids = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))) - {0}
    rem_reg = np.isin(lab, list(edge_ids))
    rem = np.zeros(al.shape, bool); rem[y0:y1 + 1, x0:x1 + 1] = rem_reg
    out = a.copy(); out[rem, 3] = 0
    return out, int(rem.sum())

def trim(a, thr=1):
    ys, xs = np.where(a[..., 3] >= thr)
    return a[ys.min():ys.max() + 1, xs.min():xs.max() + 1], (xs.min(), ys.min())

def preview(a, bg=(255, 0, 255), crop=None, scale=1):
    im = Image.fromarray(a)
    if crop: im = im.crop(crop)
    b = Image.new('RGBA', im.size, bg + (255,)); b.alpha_composite(im)
    if scale != 1: b = b.resize((im.width * scale, im.height * scale), Image.NEAREST)
    return b

# ---------- conservative matte removal (v2): never eat dark clothing ----------
def disk(r):
    return cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * r + 1, 2 * r + 1))

def remove_matte_v2(a, hull_r=6, peel=2):
    rgb = a[..., :3].astype(np.int32)
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    lum = rgb.mean(2)
    solid = a[..., 3] > 40
    matte_like = solid & (lum >= 10) & (lum <= 40) & ((b - r) >= -1) & ((b - r) <= 18) & (np.abs(r - g) <= 8)
    content = solid & ~matte_like
    # drop tiny content specks so they do not anchor the hull
    lab, n = ndi.label(content)
    if n:
        sizes = ndi.sum(content, lab, range(1, n + 1))
        content = np.isin(lab, [i + 1 for i, s in enumerate(sizes) if s >= 25])
    hull = cv2.morphologyEx(content.astype(np.uint8), cv2.MORPH_CLOSE, disk(hull_r)) > 0
    hull = ndi.binary_fill_holes(hull)
    outside = solid & ~hull
    # only remove the plate colour outside the hull; anything non-plate outside the hull is kept (it is content)
    rem = outside & matte_like
    out = a.copy(); out[rem, 3] = 0
    # peel remaining plate-coloured pixels that touch the (new) exterior, a few passes
    cur = out[..., 3] > 40
    for _ in range(peel):
        ext_nb = cv2.dilate((~cur).astype(np.uint8), K3) > 0
        p = cur & ext_nb & matte_like & ~(cv2.erode(content.astype(np.uint8), K3) > 0)
        out[p, 3] = 0
        cur = out[..., 3] > 40
    return out, int(((a[..., 3] > 40) & ~cur).sum())
