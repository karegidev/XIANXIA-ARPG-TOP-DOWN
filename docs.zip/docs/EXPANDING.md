# Expanding Azure Ascension

Almost everything is data-driven. Edit JSON in `data/` - no code changes needed for most additions. (`GameData` loads them at start.)
Run `python3 tools/lint2.py` (from the project root's parent paths set in the script) to re-check scripts and references after edits.

## Sprites and icons
* World sprite: PNG in `assets/sprites/<group>/`, entry in `data/sprites.json`: `file`, `anchor` [ax, ay] (the ground point), `scale` (game px per image px).
  Real size: `scale = height_m * 64 / image_height_px`. `tools/build_assets2.py` does the cleaning + sizing for a whole pack.
* UI icon: 96x96 PNG in `assets/icons/<id>.png`. Items use `icon` (defaults to the item id).

## Items (`items.json`)
`type`: consumable | material | tool | weapon | trinket | junk. `price` (buy, copper), `sell`, `rarity` 0-3.
Consumable effects: `hp`, `qi`, `xp`, `hot:{amount,dur}`, `buff:{id,name,atk,speed,regen,dur}`. Tools: `tool` = axe | pickaxe | bucket.
Trinkets: `qi_regen`, `max_qi_mult`. Weapons: `weapon` = id in `weapons.json`.
Coins: 100 copper = 1 silver, 100 silver = 1 gold, 100 gold = 1 platinum.

## Weapons (`weapons.json`)
`style` slash | thrust | shoot, `sprite`, `dmg`, `reach` (m), `arc` (rad), `dur` [hit1, hit2, hit3 seconds], `crit`, `knock`, `hand` (grip offset).
Add the item in `items.json` with the same id and (optionally) a recipe.

## Recipes and stations (`recipes.json`, `stations.json`)
Recipe: `station`, `inputs{item:n}`, `outputs{item:n}`, optional `returns`, `coins`, `stones`. Stations are placed in `world.json -> stations`.
New station: add art + entry in `stations.json` (`sprite`, `icon`, `verb`, `footprint`) and recipes with that station id.

## Resource nodes and props (`props.json`)
`kind` tree | rock | bush | log | spirit. `tool` (axe/pickaxe/none), `hits`, `yields[{item,min,max,chance}]`, `respawn` seconds, `collider{r}` or `{w,d}`, `sway`.
Spirit trees: `mult` (meditation speed), `capacity` (seconds of meditation before it needs recharging). Place props in `world.json -> props` (`"decor":true` = not gatherable).

## Enemies (`enemies.json`)
`ai` chase | circle; `attacks[]` kinds swipe, lunge, charge, shockwave, summon, blink (`phase:2` = below 50% HP).
Loot: `coins[min,max]`, `stones[min,max]`, `loot[{item,chance,min,max}]`; bosses add `pack[...]` (a loot pack drops) and a high-grade stone. 8% of non-boss spawns are elites.

## NPCs, quests, shops
* `npcs.json`: `role` talk | quest | shop | shop_quest, `lines`, `quests`, `shop` (item ids sold), merchants always buy sellable items.
* `quests.json`: `kind` kill (target = enemy id or tag) or collect (target = item id; items are consumed on turn-in). `reward{xp,coins,stones,items}`, `after`.

## Skills (`skills.json`)
Add the entry and append to `order` (6 slots; change the loop in `touch_controls.gd` `_layout()` for more).
Kinds: `projectile` (explode / pierce / slow / burn / chain), `palm`, `swords`, `shield`. New kinds: add a `match` arm in `Player.cast_skill()`.

## Map (`world.json`)
`rows` = ASCII tiles (1 char = 2 m); `legend` maps chars -> tile ids (`tiles.json`); `blocked` chars are water (walkers blocked, flying sword crosses).
Lists: `buildings` (sprite, pos metres, footprint, `kind:"well"`), `props`, `stations`, `chests`, `npcs`, `spawners`, `pois`, `zones`.
`tools/gen_world2.py` regenerates the whole map procedurally.

## Code map
* `entities/player.gd` - weapons, skills, gathering, meditation, mount, perfect dodge.
* `entities/enemy.gd` - AI state machine, elites. `world/world.gd` - map build, interaction priorities, loot, spawners.
* Interactable API (duck-typed): a node in group `interactables` with `ikind`, `iprio`, `iradius`, `iprompt()`; handled in `main.gd _on_interact()`.
