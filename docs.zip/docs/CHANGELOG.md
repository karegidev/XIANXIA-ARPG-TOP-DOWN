# v2.1 fixes
* FIXED: HUD crashed with "unsupported format character in operator %" right after a perfect dodge (the "FOCUS +50% damage" text). The editor debugger pauses on script errors, which looked like a freeze.
* Hardened slow-motion / hit-stop: the time scale is now always restored using real time, and reset when opening menus.
* NEW: MENU > Guide (12 topics, live breakthrough checker, live recipe and weapon lists).
* Breakthrough made discoverable: HUD hints at stage 9, a message when cultivation is complete, a help card in Status.
* Breakthrough costs lowered (60 / 300 / 1000 / 3500 spirit stones) and Spirit Stone Pouches (10 stones) added to Merchant Qian and Grand Merchant Zhao.

# v2 changes (asset replacement + major update)

## Assets
* Removed all v1 sprites/tiles; imported ASSETS_FOR_XIANXIA_RPG.zip (110 files).
* Audit result: this pack is far cleaner than v1 (no baked dark plates, no mist blobs). Applied: faint-alpha haze removal on player aura forms,
  speck cleanup, light edge anti-aliasing, trim + feet/base anchoring, real-world sizing (metres), premultiplied LANCZOS downscale.
* Tiles: names were correct this time. Made grass/dirt/sand/water/slab seamless; wood floor blended horizontally only (keeps plank lines);
  derived forest, mud and paving tiles; separate water tile for the animated water shader.
* Generated 96px UI icons for all items; made matching procedural icons for pills, Golden Bell and Heavenly Palm (no art in the pack).

## Systems added
Gathering, crafting stations + recipes, weapons (slash/thrust/shoot), trinkets, coins economy + sell, food buffs and heal-over-time,
flying-sword mount (water layer collision), meditation at spirit trees, perfect dodge, elite enemies, chests, boss loot packs, wells/buckets,
Codex tab, Gear tab, chain-lightning skill, procedural audio, animated water, wind sway, terrain variation.

## Layout
World rebuilt around compact settlements: Qingyun Village, Artisan Yard (wood floor), Haven Town (+ Heart Tree), Merchant Quarter, bandit camp, 3 beast lairs; ~560 props.
