Beasts and Creatures SFX — optimized for game use

Format: Ogg Vorbis (.ogg), quality setting 5 (high quality).
All 12 audio clips were decoded successfully after conversion.
Original stereo channels and sample rate were preserved; audio durations match the originals exactly.
The source WAV files contained an embedded PNG stream; the converted files retain the audio only.

Note: Ogg Vorbis is lossy compression, so it is not bit-for-bit identical to WAV, but this setting is intended to retain good SFX quality while dramatically reducing size. Keep the original WAV archive as a backup if you need lossless masters.
For Godot, import the .ogg files and update any references that still point to .wav.
