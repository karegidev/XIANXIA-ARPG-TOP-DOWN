extends Node
## Main - flow controller: title -> world + HUD + touch controls + menus.

const WorldScript: GDScript = preload("res://scripts/world/world.gd")
const HudScript: GDScript = preload("res://scripts/ui/hud.gd")
const ControlsScript: GDScript = preload("res://scripts/ui/touch_controls.gd")
const MenuScript: GDScript = preload("res://scripts/ui/menu_ui.gd")
const DialogueScript: GDScript = preload("res://scripts/ui/dialogue_ui.gd")
const TitleScript: GDScript = preload("res://scripts/ui/title_ui.gd")

var world = null
var hud = null
var controls = null
var menu = null
var dialogue = null
var title = null
var game_layer: CanvasLayer = null
var menu_layer: CanvasLayer = null
var autosave_t: float = 120.0
var in_game: bool = false


func _ready() -> void:
	get_tree().set_auto_accept_quit(false)
	_show_title()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if in_game and menu != null and is_instance_valid(menu):
			if menu.open_flag:
				menu.close()
			elif dialogue != null and is_instance_valid(dialogue) and dialogue.open_flag:
				dialogue.close()
			else:
				_on_menu()
	elif what == NOTIFICATION_WM_CLOSE_REQUEST:
		if in_game:
			GameState.save_game()
		get_tree().quit()


func _show_title() -> void:
	_clear_game()
	title = TitleScript.new()
	var layer: CanvasLayer = CanvasLayer.new()
	layer.name = "TitleLayer"
	layer.layer = 30
	add_child(layer)
	layer.add_child(title)
	title.new_game.connect(_start.bind(false))
	title.continue_game.connect(_start.bind(true))


func _start(load_save: bool) -> void:
	var tl: Node = get_node_or_null("TitleLayer")
	if tl != null:
		tl.queue_free()
	title = null
	_clear_game()
	if load_save and GameState.load_game():
		pass
	else:
		GameState.reset_new_game()
	world = WorldScript.new()
	world.name = "World"
	add_child(world)
	game_layer = CanvasLayer.new()
	game_layer.layer = 10
	add_child(game_layer)
	hud = HudScript.new()
	game_layer.add_child(hud)
	controls = ControlsScript.new()
	game_layer.add_child(controls)
	menu_layer = CanvasLayer.new()
	menu_layer.layer = 20
	menu_layer.process_mode = Node.PROCESS_MODE_ALWAYS
	add_child(menu_layer)
	menu = MenuScript.new()
	menu_layer.add_child(menu)
	dialogue = DialogueScript.new()
	menu_layer.add_child(dialogue)
	_connect_game()
	in_game = true
	autosave_t = 120.0
	GameState.say("Welcome to Qingyun Village, cultivator.", Color(1, 0.95, 0.75))
	GameState.say("Left stick: move.  Right: attack, dash, skills.  Chop trees and mine rocks with your tools!", Color(0.8, 0.9, 1.0))
	GameState.say("Visit the Artisan Yard to smelt, forge, cook and brew.", Color(0.8, 0.9, 1.0))
	GameState.say("New here? Open MENU > Guide for how everything works.", Color(1, 0.9, 0.5))


func _connect_game() -> void:
	var p = world.player
	controls.attack_down.connect(_on_attack_down)
	controls.attack_up.connect(_on_attack_up)
	controls.dash_pressed.connect(p.try_dash)
	controls.skill_pressed.connect(p.cast_skill)
	controls.interact_pressed.connect(_on_interact)
	controls.menu_pressed.connect(_on_menu)
	controls.heal_pressed.connect(_on_heal)
	controls.qi_pressed.connect(_on_qi)
	controls.fly_pressed.connect(p.toggle_mount)
	world.interact_target_changed.connect(_on_interact_target)
	world.zone_entered.connect(_on_zone)
	menu.closed.connect(_on_overlay_closed)
	menu.title_requested.connect(_show_title)
	menu.load_requested.connect(_reload)
	dialogue.finished.connect(_on_overlay_closed)


func _clear_game() -> void:
	in_game = false
	Engine.time_scale = 1.0
	for n in [world, game_layer, menu_layer]:
		if n != null and is_instance_valid(n):
			n.queue_free()
	world = null
	game_layer = null
	menu_layer = null
	hud = null
	controls = null
	menu = null
	dialogue = null
	GameState.world = null
	GameState.player = null


func _reload() -> void:
	_start(true)


func _process(delta: float) -> void:
	if not in_game or world == null or not is_instance_valid(world):
		return
	var p = world.player
	if p != null and is_instance_valid(p):
		p.move_dir = controls.move_vec if controls.enabled else Vector2.ZERO
	# Interact is edge-triggered by TouchControls._fire(). Polling a held
	# button here can restart gathering forever as soon as the player returns
	# to the free state.
	autosave_t -= delta
	if autosave_t <= 0.0:
		autosave_t = 120.0
		if p != null and p.state != "dead":
			GameState.save_game()


func _on_attack_down() -> void:
	var p = world.player
	p.attack_held = true
	p.try_attack()


func _on_attack_up() -> void:
	if world != null and is_instance_valid(world):
		world.player.attack_held = false


func _set_world_paused(paused: bool) -> void:
	# Pause gameplay by disabling the world subtree, not SceneTree.paused.
	# This keeps Android touch/UI input responsive while all world physics and
	# NPC/enemy processing remain frozen behind modal interfaces.
	if world != null and is_instance_valid(world):
		world.process_mode = Node.PROCESS_MODE_DISABLED if paused else Node.PROCESS_MODE_INHERIT


func _on_interact() -> void:
	if not in_game or world == null or not is_instance_valid(world):
		return
	if controls == null or not is_instance_valid(controls) or not controls.enabled:
		return
	var p = world.player
	if p == null or not is_instance_valid(p):
		return
	var n = world.nearest_interact
	if n == null or not is_instance_valid(n):
		return
	Engine.time_scale = 1.0
	match String(n.ikind):
		"npc":
			if dialogue == null or not is_instance_valid(dialogue):
				return
			dialogue.open_npc(n)
			if dialogue.open_flag:
				_set_world_paused(true)
				controls.set_enabled(false)
				p.move_dir = Vector2.ZERO
				p.attack_held = false
				n.talking = true
				n.face_player(p)
		"station":
			if dialogue == null or not is_instance_valid(dialogue):
				return
			dialogue.open_station(n)
			if dialogue.open_flag:
				_set_world_paused(true)
				controls.set_enabled(false)
				p.move_dir = Vector2.ZERO
				p.attack_held = false
		"resource":
			p.start_gather(n)
		"chest":
			n.open_chest()
		"spirit":
			p.start_meditate(n)
		"well":
			n.use_well()


func _on_menu() -> void:
	if not in_game or world == null or not is_instance_valid(world):
		return
	if menu == null or not is_instance_valid(menu) or controls == null or not is_instance_valid(controls):
		return
	if dialogue != null and is_instance_valid(dialogue) and dialogue.open_flag:
		dialogue.close()
		return
	Engine.time_scale = 1.0
	var p = world.player
	if p != null and is_instance_valid(p):
		p.move_dir = Vector2.ZERO
		p.attack_held = false
	menu.open_menu()
	if menu.open_flag:
		_set_world_paused(true)
		controls.set_enabled(false)


func _on_overlay_closed() -> void:
	var menu_open: bool = menu != null and is_instance_valid(menu) and menu.open_flag
	var dialogue_open: bool = dialogue != null and is_instance_valid(dialogue) and dialogue.open_flag
	var overlay_open: bool = menu_open or dialogue_open
	_set_world_paused(overlay_open)
	if controls != null and is_instance_valid(controls):
		controls.set_enabled(not overlay_open)
	var active_npc = dialogue.npc if dialogue_open else null
	for n in get_tree().get_nodes_in_group("npcs"):
		if is_instance_valid(n):
			n.talking = n == active_npc
	if world != null and is_instance_valid(world) and world.player != null and is_instance_valid(world.player):
		world.player.set_zoom(float(GameState.settings.get("cam_zoom", 1.0)))


func _on_heal() -> void:
	if world.player.state != "dead":
		GameState.use_item("healing_pill")


func _on_qi() -> void:
	if world.player.state != "dead":
		GameState.use_item("qi_pill")


func _on_interact_target(n) -> void:
	if n == null or not is_instance_valid(n):
		controls.interact_visible = false
		return
	controls.interact_visible = true
	controls.interact_label = String(n.iprompt())


func _on_zone(zone_name: String, safe: bool) -> void:
	hud.show_banner(zone_name, safe)
