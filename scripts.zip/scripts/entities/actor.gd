extends CharacterBody2D
## Actor - shared visuals/behaviour for Player, Enemy and NPC.
## Sprite origin is the actor's feet, scale comes from real-world size data (true proportions).

const ShadowScript: GDScript = preload("res://scripts/combat/shadow.gd")

var sprite_id: String = ""
var body_root: Node2D = null
var sprite: Sprite2D = null
var shadow = null
var flash_mat: ShaderMaterial = null
var col_shape: CollisionShape2D = null

var face: float = 1.0
var flash_t: float = 0.0
var flash_dur: float = 0.12
var bob_t: float = 0.0
var squash: Vector2 = Vector2.ONE
var lean: float = 0.0
var radius_px: float = 20.0
var height_px: float = 110.0


func build_visual(id: String, collision_radius_m: float) -> void:
	sprite_id = id
	radius_px = GameData.m(collision_radius_m)
	shadow = ShadowScript.new()
	add_child(shadow)
	shadow.set_radius(maxf(radius_px * 1.5, 22.0))
	body_root = Node2D.new()
	add_child(body_root)
	sprite = GameData.make_sprite(id)
	flash_mat = GameData.make_flash_material()
	sprite.material = flash_mat
	body_root.add_child(sprite)
	height_px = GameData.sprite_height_px(id)
	col_shape = CollisionShape2D.new()
	var c: CircleShape2D = CircleShape2D.new()
	c.radius = radius_px
	col_shape.shape = c
	col_shape.position = Vector2(0, -radius_px * 0.5)
	add_child(col_shape)


func change_sprite(id: String) -> void:
	if sprite == null:
		return
	sprite_id = id
	var info: Dictionary = GameData.sprite_info(id)
	if info.is_empty():
		return
	sprite.texture = GameData.tex(id)
	var a: Array = info.get("anchor", [0, 0])
	sprite.offset = Vector2(-float(a[0]), -float(a[1]))
	var sc: float = float(info.get("scale", 0.5))
	sprite.scale = Vector2(sc, sc)
	height_px = GameData.sprite_height_px(id)


func flash(strength: float = 1.0, dur: float = 0.12, color: Color = Color(1, 1, 1, 1)) -> void:
	flash_t = dur
	flash_dur = dur
	if flash_mat != null:
		flash_mat.set_shader_parameter("flash_color", color)
		flash_mat.set_shader_parameter("flash", strength)


func visual_update(delta: float, move_ratio: float) -> void:
	## move_ratio 0..1 -> walking bob; also decays squash and applies facing.
	if flash_t > 0.0:
		flash_t -= delta
		if flash_mat != null:
			flash_mat.set_shader_parameter("flash", clampf(flash_t / maxf(flash_dur, 0.001), 0.0, 1.0))
	bob_t += delta * (6.0 + 8.0 * move_ratio)
	var bob: float = 0.0
	if move_ratio > 0.05:
		bob = -absf(sin(bob_t)) * 5.0 * move_ratio
	else:
		bob = sin(bob_t * 0.35) * 1.2
	squash = squash.lerp(Vector2.ONE, clampf(delta * 12.0, 0.0, 1.0))
	body_root.position.y = bob
	body_root.scale = Vector2(face * squash.x, squash.y)
	body_root.rotation = lerpf(body_root.rotation, lean + (sin(bob_t) * 0.04 * move_ratio), clampf(delta * 14.0, 0.0, 1.0))


func face_toward(dx: float) -> void:
	if absf(dx) > 0.5:
		face = 1.0 if dx > 0.0 else -1.0
