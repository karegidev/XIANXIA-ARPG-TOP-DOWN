extends Node2D
## Chest - one-time treasure chest. Interactable API: ikind, iprio, iradius, iprompt().

var cid: String = ""
var tier: int = 1
var coins: Array = [0, 0]
var loot: Array = []
var ikind: String = "chest"
var iprio: int = 3
var iradius: float = 130.0
var opened: bool = false
var sprite: Sprite2D = null


func _ready() -> void:
	sprite = GameData.make_sprite("obj_chest")
	add_child(sprite)
	var body: StaticBody2D = StaticBody2D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	var cs: CollisionShape2D = CollisionShape2D.new()
	var r: RectangleShape2D = RectangleShape2D.new()
	r.size = Vector2(GameData.m(0.8), GameData.m(0.4))
	cs.shape = r
	cs.position = Vector2(0, -r.size.y * 0.5)
	body.add_child(cs)
	add_child(body)
	iradius = GameData.m(2.2)
	opened = GameState.opened_chests.has(cid)
	if opened:
		sprite.modulate = Color(0.5, 0.5, 0.55, 1.0)
	add_to_group("interactables")


func iprompt() -> String:
	return "" if opened else "OPEN"


func open_chest() -> void:
	if opened:
		return
	opened = true
	GameState.opened_chests.append(cid)
	Sfx.play("chest")
	var tw: Tween = create_tween()
	tw.tween_property(sprite, "scale", sprite.scale * Vector2(1.15, 0.85), 0.08)
	tw.tween_property(sprite, "scale", sprite.scale, 0.12)
	tw.tween_property(sprite, "modulate", Color(0.5, 0.5, 0.55, 1.0), 0.3)
	var w: Node = GameState.world
	var cmin: int = int(coins[0])
	var cmax: int = int(coins[1])
	w.fx.burst(global_position + Vector2(0, -30), Color(1, 0.85, 0.4), 16, 280.0, 0.6, 5.0)
	w.drop_loot(global_position + Vector2(0, -10), loot, Vector2(cmin, cmax))
	GameState.say("You open the chest!", Color(1, 0.9, 0.5))
