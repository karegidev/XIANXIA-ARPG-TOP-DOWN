extends "res://scripts/entities/actor.gd"
## NPC - wandering villager / disciple / merchant. Data from data/npcs.json.

var nid: String = ""
var def: Dictionary = {}
var home: Vector2 = Vector2.ZERO
var wander_t: float = 0.0
var wander_dir: Vector2 = Vector2.ZERO
var talking: bool = false
var marker: int = 0
var marker_t: float = 0.0
var line_i: int = 0
var ikind: String = "npc"
var iprio: int = 4
var iradius: float = 170.0


func _ready() -> void:
	def = GameData.npcs.get(nid, {})
	collision_layer = 8
	collision_mask = 17
	motion_mode = CharacterBody2D.MOTION_MODE_FLOATING
	build_visual(String(def.get("sprite", "villager_male")), 0.3)
	home = position
	face = 1.0 if randf() < 0.5 else -1.0
	wander_t = randf_range(0.5, 3.0)
	iradius = GameData.m(2.7)
	add_to_group("npcs")
	add_to_group("interactables")
	_refresh_marker()


func _physics_process(delta: float) -> void:
	marker_t -= delta
	if marker_t <= 0.0:
		marker_t = 0.5
		_refresh_marker()
	var vel: Vector2 = Vector2.ZERO
	if not talking:
		wander_t -= delta
		if wander_t <= 0.0:
			wander_t = randf_range(2.0, 5.0)
			var radius: float = GameData.m(float(def.get("wander", 3.0)))
			if radius < 8.0 or randf() < 0.45:
				wander_dir = Vector2.ZERO
			else:
				wander_dir = Vector2.from_angle(randf() * TAU)
			if global_position.distance_to(home) > radius:
				wander_dir = (home - global_position).normalized()
		vel = wander_dir * GameData.m(float(def.get("speed", 1.2)))
		if vel.length() > 1.0:
			face_toward(vel.x)
	velocity = vel
	move_and_slide()
	visual_update(delta, clampf(vel.length() / maxf(GameData.m(1.2), 1.0), 0.0, 1.0))


func iprompt() -> String:
	var role: String = String(def.get("role", "talk"))
	return "SHOP" if role == "shop" else "TALK"


func face_player(p: Node2D) -> void:
	face_toward(p.global_position.x - global_position.x)


func _refresh_marker() -> void:
	var m: int = 0
	for qid in def.get("quests", []):
		var q: String = String(qid)
		if GameState.quest_ready(q):
			m = 2
			break
		if GameState.quest_available(q):
			m = maxi(m, 1)
	if m != marker:
		marker = m
		queue_redraw()


func _draw() -> void:
	if marker == 0:
		return
	var f: Font = ThemeDB.fallback_font
	var txt: String = "!" if marker == 1 else "?"
	var col: Color = Color(1.0, 0.85, 0.25) if marker == 1 else Color(0.5, 1.0, 0.6)
	var pos: Vector2 = Vector2(-9, -height_px - 18)
	draw_string_outline(f, pos, txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 40, 8, Color(0, 0, 0, 0.9))
	draw_string(f, pos, txt, HORIZONTAL_ALIGNMENT_LEFT, -1, 40, col)
