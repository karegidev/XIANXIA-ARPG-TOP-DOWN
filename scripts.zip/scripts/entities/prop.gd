extends Node2D
## Prop - gatherable trees / rocks / bushes / logs and meditation spirit trees. Data: data/props.json
## Interactable API (duck-typed): ikind, iprio, iradius, iprompt().

var pid: String = ""
var decor: bool = false                 # decorative only: no gathering, no interaction
var def: Dictionary = {}
var sway_mat: ShaderMaterial = null     # shared wind-sway material (set by World)

var ikind: String = "resource"
var iprio: int = 1
var iradius: float = 120.0

var kind: String = ""
var hits_left: int = 1
var depleted: bool = false
var respawn_t: float = 0.0
var charge: float = 60.0                # spirit tree meditation charge (seconds)
var sprite: Sprite2D = null
var glow_sprite: Sprite2D = null
var body: StaticBody2D = null
var spark_t: float = 0.0
var pulse: float = 0.0


func _ready() -> void:
	def = GameData.props.get(pid, {})
	kind = String(def.get("kind", ""))
	sprite = GameData.make_sprite(String(def.get("sprite", pid)))
	add_child(sprite)
	if bool(def.get("sway", false)) and sway_mat != null:
		sprite.material = sway_mat
	hits_left = int(def.get("hits", 1))
	charge = float(def.get("capacity", 60.0))
	var col: Variant = def.get("collider", null)
	if typeof(col) == TYPE_DICTIONARY:
		body = StaticBody2D.new()
		body.collision_layer = 1
		body.collision_mask = 0
		var cs: CollisionShape2D = CollisionShape2D.new()
		if col.has("r"):
			var c: CircleShape2D = CircleShape2D.new()
			c.radius = GameData.m(float(col["r"]))
			cs.shape = c
			cs.position = Vector2(0, -c.radius * 0.6)
		else:
			var r: RectangleShape2D = RectangleShape2D.new()
			r.size = Vector2(GameData.m(float(col.get("w", 1.0))), GameData.m(float(col.get("d", 0.6))))
			cs.shape = r
			cs.position = Vector2(0, -r.size.y * 0.5)
		body.add_child(cs)
		add_child(body)
	match kind:
		"spirit":
			ikind = "spirit"
			iprio = 2
			iradius = GameData.m(3.2)
			_make_glow()
			set_process(true)
		"tree":
			iradius = GameData.m(1.9)
			set_process(false)
		"rock":
			iradius = GameData.m(2.0)
			set_process(false)
		_:
			iradius = GameData.m(1.7)
			set_process(false)
	if not decor:
		add_to_group("interactables")


func _make_glow() -> void:
	glow_sprite = GameData.make_sprite(String(def.get("sprite", pid)))
	var mat: CanvasItemMaterial = CanvasItemMaterial.new()
	mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	glow_sprite.material = mat
	glow_sprite.modulate = Color(0.4, 0.7, 1.0, 0.0)
	add_child(glow_sprite)


func iprompt() -> String:
	if depleted:
		return ""
	if kind == "spirit":
		return "MEDITATE" if charge >= 3.0 else ""
	return String(def.get("verb", "USE"))


func tool_needed() -> String:
	return String(def.get("tool", ""))


func spirit_mult() -> float:
	return float(def.get("mult", 1.0))


func meditate_use(delta: float) -> float:
	## consumes charge, returns seconds of meditation actually granted
	var use: float = minf(delta, charge)
	charge -= use
	return use


# ------------------------------------------------------------------ gathering
func hit(strength: float = 1.0) -> void:
	if depleted:
		return
	hits_left -= maxi(1, int(round(strength)))
	var fxn: Node2D = GameState.world.fx
	var tint: Color = Color(0.7, 0.55, 0.35)
	var snd: String = "chop"
	if kind == "rock":
		tint = Color(0.8, 0.8, 0.85)
		snd = "mine"
	elif kind == "bush":
		tint = Color(0.5, 0.9, 0.4)
		snd = "pick"
	fxn.burst(global_position + Vector2(0, -GameData.m(0.8)), tint, 7, 190.0, 0.35, 3.5)
	Sfx.play(snd)
	_shake()
	if hits_left <= 0:
		_deplete()


func _shake() -> void:
	var tw: Tween = create_tween()
	tw.tween_property(sprite, "rotation", 0.05, 0.05)
	tw.tween_property(sprite, "rotation", -0.05, 0.08)
	tw.tween_property(sprite, "rotation", 0.0, 0.06)


func _deplete() -> void:
	depleted = true
	GameState.gathered += 1
	var got: Array = []
	for y in def.get("yields", []):
		if randf() > float(y.get("chance", 1.0)):
			continue
		var n: int = randi_range(int(y.get("min", 1)), int(y.get("max", 1)))
		if n <= 0:
			continue
		GameState.add_item(String(y["item"]), n)
		got.append("%d %s" % [n, GameData.item_name(String(y["item"]))])
	var fxn: Node2D = GameState.world.fx
	if got.is_empty():
		fxn.damage_number(global_position + Vector2(0, -GameData.m(1.2)), 0, Color(0.8, 0.8, 0.8), false, "Nothing found")
	else:
		fxn.damage_number(global_position + Vector2(0, -GameData.m(1.2)), 0, Color(0.7, 1, 0.75), false, "+ " + ", ".join(got))
	GameState.add_xp(float(def.get("xp", 1)))
	fxn.burst(global_position + Vector2(0, -GameData.m(1.0)), Color(0.9, 0.8, 0.5), 14, 260.0, 0.5, 4.0)
	Sfx.play("pickup", 0.7, 0.8)
	if body != null:
		body.set_deferred("collision_layer", 0)
	var tw: Tween = create_tween()
	tw.set_parallel(true)
	if kind == "tree" or kind == "log":
		var dir: float = 1.0 if randf() < 0.5 else -1.0
		tw.tween_property(sprite, "rotation", dir * 1.3, 0.55).set_trans(Tween.TRANS_QUAD).set_ease(Tween.EASE_IN)
	else:
		tw.tween_property(sprite, "scale", sprite.scale * Vector2(1.1, 0.05), 0.4)
	tw.tween_property(sprite, "modulate:a", 0.0, 0.55)
	tw.chain().tween_callback(_hide_depleted)
	respawn_t = float(def.get("respawn", 240.0)) * randf_range(0.8, 1.2)
	set_process(true)


func _hide_depleted() -> void:
	visible = false


func _respawn() -> void:
	depleted = false
	hits_left = int(def.get("hits", 1))
	visible = true
	var info: Dictionary = GameData.sprite_info(String(def.get("sprite", pid)))
	var sc: float = float(info.get("scale", 0.5))
	sprite.rotation = 0.0
	sprite.scale = Vector2(sc, sc)
	sprite.modulate = Color(1, 1, 1, 0.0)
	var tw: Tween = create_tween()
	tw.tween_property(sprite, "modulate:a", 1.0, 0.8)
	if body != null:
		body.collision_layer = 1
	if kind != "spirit":
		set_process(false)


func _process(delta: float) -> void:
	if depleted:
		respawn_t -= delta
		if respawn_t <= 0.0:
			_respawn()
		return
	if kind != "spirit":
		return
	var cap: float = float(def.get("capacity", 60.0))
	if charge < cap:
		charge = minf(cap, charge + delta * cap / 300.0)
	pulse += delta
	var ratio: float = charge / maxf(cap, 1.0)
	sprite.modulate = Color(0.55 + 0.45 * ratio, 0.55 + 0.45 * ratio, 0.6 + 0.4 * ratio, 1.0)
	glow_sprite.modulate = Color(0.4, 0.75, 1.0, (0.08 + 0.07 * sin(pulse * 1.6)) * ratio)
	spark_t -= delta
	var pl: Node2D = GameState.player
	if spark_t <= 0.0 and ratio > 0.1 and pl != null and is_instance_valid(pl) and pl.global_position.distance_to(global_position) < GameData.m(18.0):
		spark_t = randf_range(0.5, 1.1)
		var g: Array = def.get("glow", [0.5, 0.8, 1.0])
		var top: float = GameData.sprite_height_px(String(def.get("sprite", pid))) * randf_range(0.35, 0.85)
		GameState.world.fx.burst(global_position + Vector2(randf_range(-60.0, 60.0), -top), Color(float(g[0]), float(g[1]), float(g[2]), 1.0), 3, 40.0, 1.0, 3.0)
