extends "res://scripts/entities/actor.gd"
## Enemy - data-driven AI (see data/enemies.json).
## States: idle -> chase -> windup -> active -> recover (+ stagger, dead).
## Attack kinds: swipe, lunge, charge, shockwave, summon, blink.

const TeleScript: GDScript = preload("res://scripts/combat/telegraph.gd")

var eid: String = ""
var def: Dictionary = {}
var max_hp: float = 50.0
var hp: float = 50.0
var state: String = "idle"
var is_boss: bool = false
var minion: bool = false
var spawn_idx: int = -1            # which world spawner owns this enemy (-1 = none)
var phase: int = 1
var elite: bool = false
var dmg_mul: float = 1.0

var home: Vector2 = Vector2.ZERO
var target: Node2D = null
var atk: Dictionary = {}
var atk_t: float = 0.0
var atk_total: float = 0.0
var gcd: float = 0.6
var aim: Vector2 = Vector2.RIGHT
var tele = null

var stun_t: float = 0.0
var slow_t: float = 0.0
var slow_mul: float = 0.0
var burn_t: float = 0.0
var burn_dps: float = 0.0
var burn_tick: float = 0.0

var kb: Vector2 = Vector2.ZERO
var wander_t: float = 0.0
var wander_dir: Vector2 = Vector2.ZERO
var circle_sign: float = 1.0
var circle_t: float = 2.0
var lunge_left: float = 0.0
var hit_done: bool = false
var bar_t: float = 0.0
var frame_i: int = 0


func _ready() -> void:
	def = GameData.enemies.get(eid, {})
	collision_layer = 4
	collision_mask = 17
	motion_mode = CharacterBody2D.MOTION_MODE_FLOATING
	build_visual(String(def.get("sprite", "wolf")), float(def.get("radius", 0.5)))
	max_hp = float(def.get("hp", 50))
	hp = max_hp
	is_boss = bool(def.get("boss", false))
	if not is_boss and not minion and randf() < 0.08:
		elite = true
		max_hp *= 2.2
		hp = max_hp
		dmg_mul = 1.35
		sprite.scale *= 1.18
		height_px *= 1.18
		queue_redraw()
	home = position
	face = 1.0 if randf() < 0.5 else -1.0
	circle_sign = 1.0 if randf() < 0.5 else -1.0
	wander_t = randf_range(0.2, 2.5)
	frame_i = randi() % 3
	add_to_group("enemies")


func speed_px() -> float:
	var s: float = GameData.m(float(def.get("speed", 3.0)))
	if slow_t > 0.0:
		s *= (1.0 - slow_mul)
	return s


func _physics_process(delta: float) -> void:
	if state == "dead":
		return
	frame_i += 1
	var pl: Node2D = GameState.player
	if target == null or not is_instance_valid(target):
		target = pl
	_tick_status(delta)
	if bar_t > 0.0:
		bar_t -= delta
		if bar_t <= 0.0:
			queue_redraw()
	var move_ratio: float = 0.0
	var desired: Vector2 = Vector2.ZERO
	if stun_t > 0.0 and state != "dead":
		stun_t -= delta
		if state != "stagger":
			_cancel_tele()
			state = "stagger"
		if stun_t <= 0.0:
			state = "chase"
			gcd = 0.4
		lean = 0.15 * face
	else:
		match state:
			"idle":
				desired = _do_idle(delta)
			"chase":
				desired = _do_chase(delta)
			"windup":
				_do_windup(delta)
			"active":
				desired = _do_active(delta)
			"recover":
				_do_recover(delta)
	if state == "active" and (String(atk.get("kind", "")) == "lunge" or String(atk.get("kind", "")) == "charge"):
		velocity = desired
	else:
		velocity = velocity.move_toward(desired, 5000.0 * delta) if state != "stagger" else Vector2.ZERO
	velocity += kb
	kb = kb.move_toward(Vector2.ZERO, 2400.0 * delta)
	if frame_i % 2 == 0:
		velocity += _separation() * 3.0
	move_and_slide()
	move_ratio = clampf(velocity.length() / maxf(GameData.m(float(def.get("speed", 3.0))), 1.0), 0.0, 1.3)
	_apply_tint()
	visual_update(delta, move_ratio)


func _separation() -> Vector2:
	var push: Vector2 = Vector2.ZERO
	for o in get_tree().get_nodes_in_group("enemies"):
		if o == self or not is_instance_valid(o):
			continue
		var d: Vector2 = global_position - o.global_position
		var l: float = d.length()
		var minr: float = (radius_px + float(o.radius_px)) * 1.15
		if l < minr and l > 0.01:
			push += d / l * (minr - l) * 14.0
	return push


func _tick_status(delta: float) -> void:
	if slow_t > 0.0:
		slow_t -= delta
	if burn_t > 0.0:
		burn_t -= delta
		burn_tick -= delta
		if burn_tick <= 0.0:
			burn_tick = 0.5
			_hurt(burn_dps * 0.5, Color(1.0, 0.6, 0.2))


func _apply_tint() -> void:
	var c: Color = Color(1, 1, 1, 1)
	if elite:
		c = Color(1.18, 1.05, 0.72, 1)
	if stun_t > 0.0:
		c = Color(1.0, 1.0, 0.55, 1)
	elif burn_t > 0.0:
		c = Color(1.0, 0.72, 0.55, 1)
	elif slow_t > 0.0:
		c = Color(0.65, 0.85, 1.15, 1)
	if state == "windup" and String(atk.get("kind", "")) == "blink":
		c.a = clampf(1.0 - atk_t / maxf(atk_total, 0.01) * 0.85, 0.15, 1.0)
	sprite.modulate = c


# ------------------------------------------------------------------ AI states
func _player_alive() -> bool:
	return target != null and is_instance_valid(target) and target.state != "dead"


func _do_idle(delta: float) -> Vector2:
	wander_t -= delta
	if wander_t <= 0.0:
		wander_t = randf_range(1.5, 4.0)
		if randf() < 0.4:
			wander_dir = Vector2.ZERO
		else:
			wander_dir = Vector2.from_angle(randf() * TAU)
		if global_position.distance_to(home) > GameData.m(5.0):
			wander_dir = (home - global_position).normalized()
	if wander_dir.length() > 0.1:
		face_toward(wander_dir.x)
	if _player_alive():
		var d: float = global_position.distance_to(target.global_position)
		if d < GameData.m(float(def.get("aggro", 9.0))):
			aggro()
	return wander_dir * speed_px() * 0.3


func aggro() -> void:
	if state != "idle":
		return
	state = "chase"
	gcd = 0.5
	GameState.world.fx.damage_number(global_position + Vector2(0, -height_px - 10), 0, Color(1, 0.85, 0.3), false, "!")
	if is_boss:
		GameState.world.boss_engaged(self)
		Sfx.play("roar", 0.9)
	var tag: String = String(def.get("tag", ""))
	for o in get_tree().get_nodes_in_group("enemies"):
		if o != self and is_instance_valid(o) and o.state == "idle" and String(o.def.get("tag", "")) == tag:
			if o.global_position.distance_to(global_position) < GameData.m(9.0):
				o.aggro()


func _do_chase(delta: float) -> Vector2:
	if not _player_alive():
		_disengage()
		return Vector2.ZERO
	var to_p: Vector2 = target.global_position - global_position
	var dist: float = to_p.length()
	var leash: float = GameData.m(float(def.get("aggro", 9.0))) * 2.8
	if global_position.distance_to(home) > GameData.m(38.0) or dist > leash:
		_disengage()
		return Vector2.ZERO
	var dir: Vector2 = to_p.normalized() if dist > 1.0 else Vector2.RIGHT
	face_toward(dir.x)
	gcd -= delta
	var ranges_max: float = 0.0
	for a in def.get("attacks", []):
		ranges_max = maxf(ranges_max, GameData.m(float(a.get("range", 2.0))))
	var desired: Vector2 = Vector2.ZERO
	var spd: float = speed_px()
	if String(def.get("ai", "chase")) == "circle":
		circle_t -= delta
		if circle_t <= 0.0:
			circle_t = randf_range(1.2, 2.6)
			circle_sign = -circle_sign
		var ring_d: float = GameData.m(3.6)
		var side: Vector2 = Vector2(-dir.y, dir.x) * circle_sign
		if dist > ring_d + GameData.m(1.2):
			desired = dir * spd
		elif dist < ring_d - GameData.m(0.8):
			desired = (-dir * 0.5 + side) * spd * 0.8
		else:
			desired = (side + dir * 0.15) * spd * 0.9
	else:
		var stop_d: float = minf(ranges_max * 0.65, GameData.m(2.4))
		if dist > stop_d:
			desired = dir * spd
	if gcd <= 0.0:
		var a: Dictionary = _pick_attack(dist)
		if not a.is_empty():
			_begin_attack(a, dir)
	return desired


func _pick_attack(dist: float) -> Dictionary:
	var pool: Array = []
	var total: float = 0.0
	for a in def.get("attacks", []):
		if int(a.get("phase", 1)) > phase:
			continue
		if dist <= GameData.m(float(a.get("range", 2.0))):
			pool.append(a)
			total += float(a.get("weight", 1.0))
	if pool.is_empty():
		return {}
	var r: float = randf() * total
	for a in pool:
		r -= float(a.get("weight", 1.0))
		if r <= 0.0:
			return a
	return pool[0]


func _begin_attack(a: Dictionary, dir: Vector2) -> void:
	atk = a
	state = "windup"
	atk_t = 0.0
	atk_total = float(a.get("windup", 0.4)) * (0.82 if phase >= 2 else 1.0)
	aim = dir
	_make_tele()


func _make_tele() -> void:
	_cancel_tele()
	var kind: String = String(atk.get("kind", ""))
	var t = TeleScript.new()
	t.position = global_position
	match kind:
		"swipe":
			t.mode = "cone"
			t.radius = GameData.m(float(atk.get("reach", 2.5)))
			t.arc = deg_to_rad(float(atk.get("arc", 120)))
			t.angle = aim.angle()
		"lunge", "charge":
			t.mode = "line"
			t.length = GameData.m(float(atk.get("dist", 4.0)))
			t.width = GameData.m(float(atk.get("hit", 1.0)) * 2.0)
			t.angle = aim.angle()
		"shockwave":
			t.mode = "circle"
			t.radius = GameData.m(float(atk.get("radius", 3.0)))
		"summon":
			t.mode = "circle"
			t.radius = GameData.m(1.8)
			t.color = Color(0.7, 0.3, 1.0, 1.0)
		"blink":
			t.mode = "circle"
			t.radius = GameData.m(1.2)
			t.color = Color(0.6, 0.3, 0.9, 1.0)
			if _player_alive():
				t.position = target.global_position
	tele = t
	GameState.world.fx.add_ground(t)


func _cancel_tele() -> void:
	if tele != null and is_instance_valid(tele):
		tele.queue_free()
	tele = null


func _do_windup(delta: float) -> void:
	atk_t += delta
	var p: float = clampf(atk_t / maxf(atk_total, 0.01), 0.0, 1.0)
	var kind: String = String(atk.get("kind", ""))
	if tele != null and is_instance_valid(tele):
		tele.set_progress(p)
		if kind == "blink" and _player_alive():
			tele.position = target.global_position
		elif kind != "blink":
			tele.position = global_position
	# keep tracking the player until 60% of the windup, then lock (so it can be dodged)
	if p < 0.6 and _player_alive() and kind != "shockwave" and kind != "summon":
		aim = (target.global_position - global_position).normalized()
		face_toward(aim.x)
		if tele != null and is_instance_valid(tele) and (kind == "swipe" or kind == "lunge" or kind == "charge"):
			tele.angle = aim.angle()
	squash = Vector2(1.0 + 0.10 * p, 1.0 - 0.14 * p)
	lean = -0.18 * face * p
	if p > 0.7:
		flash(0.35, 0.08, Color(1.0, 0.3, 0.25))
	velocity = Vector2.ZERO
	if atk_t >= atk_total:
		_start_active()


func _start_active() -> void:
	state = "active"
	atk_t = 0.0
	hit_done = false
	var kind: String = String(atk.get("kind", ""))
	_cancel_tele()
	match kind:
		"swipe":
			_melee_hit(GameData.m(float(atk.get("reach", 2.5))), deg_to_rad(float(atk.get("arc", 120))))
			GameState.world.fx.slash(global_position + Vector2(0, -height_px * 0.4), aim.angle(), GameData.m(float(atk.get("reach", 2.5))) * 0.95, deg_to_rad(float(atk.get("arc", 120))), Color(1.0, 0.45, 0.35))
			squash = Vector2(1.25, 0.85)
			Sfx.play("swing", 0.5, 0.6)
			atk_total = float(atk.get("recover", 0.6))
			state = "recover"
			atk_t = 0.0
		"shockwave":
			var r: float = GameData.m(float(atk.get("radius", 3.0)))
			GameState.world.fx.ring(global_position, r, Color(1.0, 0.45, 0.3), 0.45)
			GameState.world.fx.shake(8.0, 0.25)
			Sfx.play("boom", 0.8)
			if _player_alive() and global_position.distance_to(target.global_position) <= r + 12.0:
				target.take_damage(_dmg(), global_position, 560.0)
			squash = Vector2(1.3, 0.75)
			atk_total = float(atk.get("recover", 0.8))
			state = "recover"
			atk_t = 0.0
		"summon":
			GameState.world.spawn_minions(String(atk.get("spawn", "wolf")), int(atk.get("count", 2)), global_position, self)
			GameState.world.fx.ring(global_position, GameData.m(3.0), Color(0.7, 0.3, 1.0), 0.5)
			atk_total = float(atk.get("recover", 0.8))
			state = "recover"
			atk_t = 0.0
		"blink":
			if _player_alive():
				var from: Vector2 = global_position
				var dir_back: Vector2 = (target.global_position - from).normalized()
				GameState.world.fx.burst(from, Color(0.6, 0.3, 0.9), 12, 260.0, 0.4, 5.0)
				global_position = target.global_position + dir_back * GameData.m(1.25)
				aim = -dir_back
				face_toward(aim.x)
				GameState.world.fx.burst(global_position, Color(0.6, 0.3, 0.9), 12, 260.0, 0.4, 5.0)
				_melee_hit(GameData.m(float(atk.get("reach", 2.0))) + 20.0, deg_to_rad(360.0))
				GameState.world.fx.slash(global_position + Vector2(0, -height_px * 0.4), aim.angle(), GameData.m(2.0), 2.4, Color(0.8, 0.5, 1.0))
			atk_total = float(atk.get("recover", 0.7))
			state = "recover"
			atk_t = 0.0
		"lunge", "charge":
			lunge_left = GameData.m(float(atk.get("dist", 4.0)))
			squash = Vector2(1.3, 0.8)
			lean = 0.2 * face


func _do_active(delta: float) -> Vector2:
	## only lunge / charge stay in the active state
	atk_t += delta
	var spd: float = GameData.m(float(atk.get("speed", 10.0)))
	var step: float = spd * delta
	lunge_left -= step
	if not hit_done and _player_alive():
		var hr: float = GameData.m(float(atk.get("hit", 1.0))) + radius_px
		if global_position.distance_to(target.global_position) <= hr:
			hit_done = true
			target.take_damage(_dmg(), global_position, 520.0)
			GameState.world.fx.burst(target.global_position + Vector2(0, -50), Color(1, 0.4, 0.3), 10, 240.0, 0.3, 4.0)
	var blocked: bool = get_slide_collision_count() > 0 and atk_t > 0.08
	if lunge_left <= 0.0 or blocked:
		if blocked and String(atk.get("kind", "")) == "charge":
			stun_t = 0.9
			GameState.world.fx.burst(global_position, Color(0.9, 0.8, 0.6), 14, 300.0, 0.4, 5.0)
			GameState.world.fx.shake(6.0, 0.2)
		state = "recover"
		atk_t = 0.0
		atk_total = float(atk.get("recover", 0.7))
		return Vector2.ZERO
	return aim * spd


func _do_recover(delta: float) -> void:
	atk_t += delta
	lean = 0.0
	if atk_t >= atk_total:
		state = "chase"
		var circle: bool = String(def.get("ai", "")) == "circle"
		gcd = randf_range(0.8, 1.6) if circle else randf_range(0.35, 0.9)
		if is_boss:
			gcd *= 0.7
	velocity = velocity.move_toward(Vector2.ZERO, 3000.0 * delta)


func _dmg() -> float:
	return float(def.get("dmg", 8)) * float(atk.get("dmgmul", 1.0)) * dmg_mul * randf_range(0.9, 1.1)


func _melee_hit(reach: float, arc: float) -> void:
	if not _player_alive():
		return
	var v: Vector2 = target.global_position - global_position
	if v.length() > reach + 14.0:
		return
	if arc < TAU - 0.1 and absf(angle_difference(aim.angle(), v.angle())) > arc * 0.5:
		return
	target.take_damage(_dmg(), global_position, 380.0)


func _disengage() -> void:
	state = "idle"
	_cancel_tele()
	wander_dir = (home - global_position).normalized()
	wander_t = 2.0
	hp = minf(max_hp, hp + max_hp * 0.4)
	if is_boss:
		GameState.world.boss_disengaged(self)


# ------------------------------------------------------------------ damage
func apply_status(kind: String, dur: float, val: float) -> void:
	if state == "dead":
		return
	match kind:
		"burn":
			burn_t = maxf(burn_t, dur)
			burn_dps = val
		"slow":
			slow_t = maxf(slow_t, dur)
			slow_mul = clampf(val, 0.0, 0.8)
		"stun":
			if val > 0.0 or dur > 0.0:
				stun_t = maxf(stun_t, dur * (0.4 if is_boss else 1.0))


func _hurt(amount: float, color: Color, crit: bool = false) -> void:
	hp -= amount
	bar_t = 3.0
	GameState.world.fx.damage_number(global_position + Vector2(0, -height_px), amount, color, crit)
	queue_redraw()
	if hp <= 0.0 and state != "dead":
		_die()
	elif is_boss and phase == 1 and hp < max_hp * 0.5:
		phase = 2
		GameState.world.fx.ring(global_position, GameData.m(6.0), Color(1.0, 0.3, 0.3), 0.7)
		GameState.world.fx.shake(14.0, 0.5)
		GameState.say("%s is enraged!" % String(def.get("name", "?")), Color(1, 0.5, 0.4))


func take_damage(amount: float, from_pos: Vector2, knock: float = 300.0, crit: bool = false, _kind: String = "") -> void:
	if state == "dead":
		return
	var col: Color = Color(1, 0.95, 0.7) if crit else Color(1, 1, 1)
	if elite:
		col = Color(1.0, 0.85, 0.4)
	flash(1.0, 0.1)
	GameState.world.fx.burst(global_position + Vector2(0, -height_px * 0.45), Color(1, 0.9, 0.7), 6, 200.0, 0.3, 4.0)
	var away: Vector2 = global_position - from_pos
	if away.length() < 1.0:
		away = Vector2.RIGHT
	var resist: float = 0.25 if is_boss else (0.6 if radius_px > GameData.m(0.7) else 1.0)
	kb += away.normalized() * knock * resist
	squash = Vector2(0.85, 1.15)
	if state == "idle":
		state = "idle"
		aggro()
	_hurt(amount, col, crit)
	if state == "dead":
		return
	if not is_boss and amount > max_hp * 0.2:
		if state == "windup":
			_cancel_tele()
		stun_t = maxf(stun_t, 0.35)


func _die() -> void:
	state = "dead"
	_cancel_tele()
	remove_from_group("enemies")
	col_shape.set_deferred("disabled", true)
	velocity = Vector2.ZERO
	var w: Node = GameState.world
	w.on_enemy_killed(self)
	if is_boss:
		w.boss_disengaged(self)
	w.fx.burst(global_position + Vector2(0, -height_px * 0.4), Color(1, 0.85, 0.5), 18, 300.0, 0.6, 5.0)
	w.fx.shake(6.0 if not is_boss else 18.0, 0.3 if not is_boss else 0.6)
	w.fx.hitstop(0.06 if not is_boss else 0.18)
	queue_redraw()
	var tw: Tween = create_tween()
	tw.set_parallel(true)
	tw.tween_property(body_root, "modulate:a", 0.0, 0.6)
	tw.tween_property(body_root, "scale", Vector2(face * 1.15, 0.2), 0.5)
	tw.tween_property(shadow, "modulate:a", 0.0, 0.6)
	tw.chain().tween_callback(queue_free)


func _draw() -> void:
	if state == "dead":
		return
	if elite:
		draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.4))
		draw_arc(Vector2.ZERO, maxf(radius_px * 2.0, 34.0), 0.0, TAU, 32, Color(1.0, 0.8, 0.25, 0.8), 3.0, true)
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if bar_t <= 0.0 and not elite:
		return
	if is_boss:
		return
	var w: float = maxf(64.0, radius_px * 2.6)
	var y: float = -height_px - 16.0
	draw_rect(Rect2(-w * 0.5, y, w, 8.0), Color(0, 0, 0, 0.65))
	draw_rect(Rect2(-w * 0.5 + 1.0, y + 1.0, (w - 2.0) * clampf(hp / max_hp, 0.0, 1.0), 6.0), Color(0.9, 0.25, 0.25, 1.0))
