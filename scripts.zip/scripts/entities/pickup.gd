extends Node2D
## Pickup - coins, spirit stones, items and boss loot packs that magnet to the player.

var kind: String = "coin"       # coin | stone | hstone | item | pack
var item_id: String = ""
var amount: int = 1
var pack_loot: Array = []       # for kind == "pack": loot table entries
var age: float = 0.0
var vel: Vector2 = Vector2.ZERO
var glow: Color = Color(1, 1, 1, 1)
var collected: bool = false
var icon_tex: Texture2D = null


func _ready() -> void:
	vel = Vector2.from_angle(randf() * TAU) * randf_range(120.0, 260.0)
	match kind:
		"coin":
			icon_tex = GameData.icon(_coin_icon(amount))
			glow = Color(1.0, 0.85, 0.4, 1.0)
		"stone":
			icon_tex = GameData.icon("spirit_stone")
			glow = Color(0.5, 0.8, 1.0, 1.0)
		"hstone":
			icon_tex = GameData.icon("high_stone")
			glow = Color(0.75, 0.55, 1.0, 1.0)
		"pack":
			icon_tex = GameData.icon("loot_pack")
			glow = Color(1.0, 0.8, 0.3, 1.0)
		_:
			icon_tex = GameData.item_icon(item_id)
			var rar: int = int(GameData.items.get(item_id, {}).get("rarity", 0))
			glow = [Color(1, 1, 1, 1), Color(0.5, 1, 0.55, 1), Color(0.5, 0.7, 1.0, 1), Color(0.85, 0.55, 1.0, 1)][clampi(rar, 0, 3)]


func _coin_icon(n: int) -> String:
	if n >= 1000000:
		return "coin_platinum"
	if n >= 10000:
		return "coin_gold"
	if n >= 100:
		return "coin_silver"
	return "coin_copper"


func _process(delta: float) -> void:
	if collected:
		return
	age += delta
	var p: Node2D = GameState.player
	if p == null or not is_instance_valid(p):
		return
	vel = vel.move_toward(Vector2.ZERO, 500.0 * delta)
	position += vel * delta
	if age > 0.45 and p.state != "dead":
		var to_p: Vector2 = (p.global_position + Vector2(0, -30)) - global_position
		var d: float = to_p.length()
		if d < GameData.m(3.4):
			position += to_p.normalized() * (280.0 + (GameData.m(3.4) - d) * 6.0) * delta
		if d < 34.0:
			_collect()
	if age > 120.0 and kind != "pack":
		queue_free()
	queue_redraw()


func _collect() -> void:
	collected = true
	var fx: Node2D = GameState.world.fx
	var top: Vector2 = global_position + Vector2(0, -20)
	match kind:
		"coin":
			GameState.add_coins(amount)
			fx.damage_number(top, amount, Color(1, 0.88, 0.4), false, "+" + GameState.format_coins(amount))
			Sfx.play("coin", 0.6)
		"stone":
			GameState.add_stones(amount)
			fx.damage_number(top, amount, Color(0.55, 0.9, 1.0), false, "+%d spirit stone" % amount)
			Sfx.play("pickup", 0.6, 1.3)
		"hstone":
			GameState.add_stones(100 * amount)
			fx.damage_number(top, amount, Color(0.85, 0.65, 1.0), true, "+%d spirit stones!" % (100 * amount))
			Sfx.play("quest", 0.7)
		"pack":
			Sfx.play("chest")
			fx.burst(global_position, Color(1, 0.85, 0.4), 18, 300.0, 0.6, 5.0)
			GameState.world.drop_loot(global_position, pack_loot, Vector2.ZERO)
		_:
			GameState.add_item(item_id, amount)
			var nm: String = GameData.item_name(item_id)
			fx.damage_number(top, amount, glow, false, "+%d %s" % [amount, nm])
			Sfx.play("pickup", 0.6)
	queue_free()


func _draw() -> void:
	var bob: float = sin(age * 5.0) * 4.0
	var c: Vector2 = Vector2(0, -22 + bob)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.4))
	draw_circle(Vector2.ZERO, 14.0, Color(0, 0, 0, 0.3))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	draw_circle(c, 24.0, Color(glow.r, glow.g, glow.b, 0.16 + 0.06 * sin(age * 6.0)))
	if icon_tex != null:
		var sz: float = 44.0 if kind != "pack" else 56.0
		draw_texture_rect(icon_tex, Rect2(c - Vector2(sz, sz) * 0.5, Vector2(sz, sz)), false)
	else:
		draw_circle(c, 9.0, glow)
