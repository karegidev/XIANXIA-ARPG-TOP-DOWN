extends "res://scripts/entities/actor.gd"
## Player - the cultivator.
## Weapons: slash (swords/katanas/dagger), thrust (spears), shoot (bow). Dash with i-frames + perfect dodge.
## 6 cultivation skills, resource gathering with tools, spirit-tree meditation and flying-sword mount.

const ProjectileScript: GDScript = preload("res://scripts/combat/projectile.gd")
const ShieldScript: GDScript = preload("res://scripts/combat/shield_fx.gd")

signal died

var move_dir: Vector2 = Vector2.ZERO       # set by touch controls
var aim_dir: Vector2 = Vector2.RIGHT
var attack_held: bool = false

var state: String = "free"                 # free, attack, dash, cast, gather, meditate, dead
var state_t: float = 0.0
var combo_i: int = 0
var combo_timer: float = 0.0
var combo_count: int = 0
var combo_count_timer: float = 0.0
var attack_dur: float = 0.3
var attack_hit_at: float = 0.1
var attack_hit_done: bool = false
var attack_dir: Vector2 = Vector2.RIGHT
var attack_buffer: float = 0.0
var sweep_sign: float = 1.0
var weapon: Dictionary = {}

var dash_dir: Vector2 = Vector2.RIGHT
var dash_after_t: float = 0.0
var iframes: float = 0.0
var dodge_window: float = 0.0
var dodge_used: bool = false
var focus_t: float = 0.0
var kb: Vector2 = Vector2.ZERO
var lunge_t: float = 0.0
var no_hurt_t: float = 0.0

var skill_cd: Array = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
var shield_hp: float = 0.0
var shield_max: float = 1.0
var shield_t: float = 0.0
var shield_def: Dictionary = {}
var shield_fx = null
var stamina_delay: float = 0.0

var gather_target = null
var gather_hit_done: bool = false
var meditate_node = null
var med_fx_t: float = 0.0
var med_rate: float = 0.0

var mounted: bool = false
var mount_k: float = 0.0
var mount_sprite: Sprite2D = null
var mount_trail_t: float = 0.0

var weapon_pivot: Node2D = null
var weapon_sprite: Sprite2D = null
var tool_pivot: Node2D = null
var tool_sprite: Sprite2D = null
var camera: Camera2D = null


func _ready() -> void:
	collision_layer = 2
	collision_mask = 17
	motion_mode = CharacterBody2D.MOTION_MODE_FLOATING
	var rd: Dictionary = GameState.realm_def()
	build_visual(String(rd.get("sprite", "player_base")), 0.32)
	add_to_group("player")
	mount_sprite = GameData.make_sprite("fx_flying_sword")
	mount_sprite.visible = false
	add_child(mount_sprite)
	move_child(mount_sprite, 1)
	weapon_pivot = Node2D.new()
	weapon_pivot.position = Vector2(0, -GameData.m(0.95))
	weapon_pivot.visible = false
	add_child(weapon_pivot)
	weapon_sprite = Sprite2D.new()
	weapon_sprite.centered = false
	weapon_pivot.add_child(weapon_sprite)
	tool_pivot = Node2D.new()
	tool_pivot.position = Vector2(0, -GameData.m(0.95))
	tool_pivot.visible = false
	add_child(tool_pivot)
	tool_sprite = Sprite2D.new()
	tool_sprite.scale = Vector2(GameData.m(0.9) / 96.0, GameData.m(0.9) / 96.0)
	tool_sprite.position = Vector2(GameData.m(0.7), 0)
	tool_pivot.add_child(tool_sprite)
	shield_fx = ShieldScript.new()
	shield_fx.position = Vector2(0, -GameData.m(0.9))
	shield_fx.radius = GameData.m(1.55)
	shield_fx.visible = false
	add_child(shield_fx)
	camera = Camera2D.new()
	camera.position = Vector2(0, -GameData.m(0.9))
	camera.position_smoothing_enabled = true
	camera.position_smoothing_speed = 8.0
	var z: float = float(GameState.settings.get("cam_zoom", 1.0))
	camera.zoom = Vector2(z, z)
	add_child(camera)
	refresh_weapon()
	GameState.realm_changed.connect(_on_realm_changed)
	GameState.equipment_changed.connect(refresh_weapon)


func refresh_weapon() -> void:
	weapon = GameState.weapon_def()
	var sid: String = String(weapon.get("sprite", "w_sword"))
	var info: Dictionary = GameData.sprite_info(sid)
	if info.is_empty() or weapon_sprite == null:
		return
	weapon_sprite.texture = GameData.tex(sid)
	var a: Array = info.get("anchor", [0, 0])
	weapon_sprite.offset = Vector2(-float(a[0]), -float(a[1]))
	var sc: float = float(info.get("scale", 0.5))
	var flip: float = -1.0 if String(weapon.get("style", "")) == "shoot" else 1.0
	weapon_sprite.scale = Vector2(sc * flip, sc)
	weapon_sprite.position = Vector2(GameData.m(float(weapon.get("hand", 0.25))), 0)


func _on_realm_changed(_idx: int) -> void:
	var rd: Dictionary = GameState.realm_def()
	change_sprite(String(rd.get("sprite", "player_base")))
	flash(1.0, 0.5, Color(1, 0.95, 0.6))
	squash = Vector2(1.3, 0.8)
	var w: Node = GameState.world
	if w != null:
		w.fx.ring(global_position, GameData.m(7.0), Color(1, 0.9, 0.5), 0.9)
		w.fx.ring(global_position, GameData.m(4.0), Color(0.6, 0.9, 1.0), 0.7)
		w.fx.burst(global_position + Vector2(0, -60), Color(1, 0.9, 0.5), 40, 520.0, 0.9, 7.0)
		w.fx.shake(16.0, 0.5)
	Sfx.play("levelup")


func set_zoom(z: float) -> void:
	if camera != null:
		camera.zoom = Vector2(z, z)


func _physics_process(delta: float) -> void:
	if state == "dead":
		visual_update(delta, 0.0)
		return
	_tick_timers(delta)
	_regen(delta)
	var speed_px: float = GameData.m(GameState.move_speed_m())
	if mounted:
		speed_px *= 1.85
	var target_vel: Vector2 = Vector2.ZERO
	match state:
		"free":
			target_vel = move_dir * speed_px
			if move_dir.length() > 0.1:
				aim_dir = move_dir.normalized()
				face_toward(move_dir.x)
			if not mounted and (attack_buffer > 0.0 or attack_held):
				try_attack()
		"attack":
			target_vel = move_dir * speed_px * 0.3
			_update_attack(delta)
		"cast":
			target_vel = move_dir * speed_px * 0.45
			state_t -= delta
			if state_t <= 0.0:
				state = "free"
		"gather":
			_update_gather(delta)
		"meditate":
			_update_meditate(delta)
		"dash":
			state_t -= delta
			target_vel = dash_dir * GameData.m(15.0)
			dash_after_t -= delta
			if dash_after_t <= 0.0:
				dash_after_t = 0.035
				GameState.world.fx.afterimage(sprite, global_position, face, Color(0.55, 0.8, 1.0, 0.55))
			if state_t <= 0.0:
				state = "free"
	if lunge_t > 0.0:
		lunge_t -= delta
		target_vel = attack_dir * GameData.m(7.0)
	if state == "dash" or lunge_t > 0.0:
		velocity = target_vel
	else:
		velocity = velocity.move_toward(target_vel, 9000.0 * delta)
	velocity += kb
	kb = kb.move_toward(Vector2.ZERO, 2600.0 * delta)
	move_and_slide()
	var mr: float = clampf(velocity.length() / maxf(speed_px, 1.0), 0.0, 1.2)
	if state == "dash":
		mr = 0.0
		lean = 0.25 * face
	elif mounted:
		lean = clampf(velocity.x / maxf(speed_px, 1.0), -1.0, 1.0) * 0.2
		mr = 0.0
	else:
		lean = clampf(velocity.x / maxf(speed_px, 1.0), -1.0, 1.0) * 0.08
	if state == "meditate":
		mr = 0.0
		squash = Vector2(1.06, 0.88)
		lean = 0.0
	visual_update(delta, mr)
	_update_mount(delta)
	_update_shield(delta)


func _tick_timers(delta: float) -> void:
	if iframes > 0.0:
		iframes -= delta
	if dodge_window > 0.0:
		dodge_window -= delta
	if focus_t > 0.0:
		focus_t -= delta
	if combo_timer > 0.0:
		combo_timer -= delta
		if combo_timer <= 0.0:
			combo_i = 0
	if combo_count_timer > 0.0:
		combo_count_timer -= delta
		if combo_count_timer <= 0.0:
			combo_count = 0
	if attack_buffer > 0.0:
		attack_buffer -= delta
	if no_hurt_t > 0.0:
		no_hurt_t -= delta
	for i in range(skill_cd.size()):
		if skill_cd[i] > 0.0:
			skill_cd[i] = maxf(0.0, skill_cd[i] - delta)
	if iframes > 0.0 and state != "dash":
		sprite.modulate.a = 0.55 + 0.45 * absf(sin(Time.get_ticks_msec() * 0.03))
	else:
		sprite.modulate.a = 1.0


func _regen(delta: float) -> void:
	var drain: float = 0.0
	if mounted:
		drain = 3.5
	GameState.qi = clampf(GameState.qi + (GameState.qi_regen() - drain - (GameState.qi_regen() if mounted else 0.0)) * delta, 0.0, GameState.max_qi())
	if stamina_delay > 0.0:
		stamina_delay -= delta
	else:
		GameState.stamina = minf(GameState.max_stamina(), GameState.stamina + 38.0 * delta)
	if no_hurt_t <= 0.0 and GameState.hp < GameState.max_hp():
		GameState.hp = minf(GameState.max_hp(), GameState.hp + GameState.max_hp() * 0.012 * delta)


# ----------------------------------------------------------------- aiming
func nearest_enemy(max_dist_px: float) -> Node2D:
	var best: Node2D = null
	var bd: float = max_dist_px
	for e in get_tree().get_nodes_in_group("enemies"):
		if not is_instance_valid(e) or e.state == "dead":
			continue
		var d: float = global_position.distance_to(e.global_position)
		if d < bd:
			bd = d
			best = e
	return best


func current_aim() -> Vector2:
	if bool(GameState.settings.get("auto_aim", true)):
		var rng: float = 7.5
		if String(weapon.get("style", "")) == "shoot":
			rng = 14.0
		var e: Node2D = nearest_enemy(GameData.m(rng))
		if e != null:
			var v: Vector2 = e.global_position - global_position
			if v.length() > 1.0:
				return v.normalized()
	return aim_dir


# ----------------------------------------------------------------- weapon attacks
func try_attack() -> void:
	if state == "dead" or mounted:
		return
	if state == "meditate":
		_stop_meditate()
	if state != "free":
		attack_buffer = 0.25
		return
	attack_buffer = 0.0
	combo_i += 1
	if combo_i > 3:
		combo_i = 1
	attack_dir = current_aim()
	face_toward(attack_dir.x)
	var durs: Array = weapon.get("dur", [0.26, 0.26, 0.42])
	attack_dur = float(durs[combo_i - 1])
	attack_hit_at = attack_dur * 0.35
	attack_hit_done = false
	state = "attack"
	state_t = 0.0
	var style: String = String(weapon.get("style", "slash"))
	lunge_t = 0.11 if style != "shoot" else 0.0
	sweep_sign = -sweep_sign if combo_i != 1 else 1.0
	weapon_pivot.visible = true
	var half: float = float(weapon.get("arc", 1.9)) * 0.66
	if style == "slash":
		weapon_pivot.rotation = attack_dir.angle() - sweep_sign * half
	else:
		weapon_pivot.rotation = attack_dir.angle()
	squash = Vector2(0.88, 1.12)
	GameState.stamina = maxf(0.0, GameState.stamina - 4.0)
	stamina_delay = 0.4
	Sfx.play("bow" if style == "shoot" else "swing", 0.7, 1.0 + 0.08 * float(combo_i))


func _update_attack(delta: float) -> void:
	state_t += delta
	var k: float = clampf(state_t / attack_dur, 0.0, 1.0)
	var style: String = String(weapon.get("style", "slash"))
	var hand: float = GameData.m(float(weapon.get("hand", 0.25)))
	if style == "slash":
		var half: float = float(weapon.get("arc", 1.9)) * 0.66
		var start_a: float = attack_dir.angle() - sweep_sign * half
		var end_a: float = attack_dir.angle() + sweep_sign * half
		var ease_k: float = 1.0 - pow(1.0 - clampf(state_t / (attack_hit_at * 2.2), 0.0, 1.0), 3.0)
		weapon_pivot.rotation = lerpf(start_a, end_a, ease_k)
	elif style == "thrust":
		var reach: float = GameData.m(float(weapon.get("reach", 3.0)))
		var pk: float = clampf(state_t / (attack_hit_at * 1.6), 0.0, 1.0)
		var out_k: float = sin(pk * PI)
		weapon_pivot.rotation = attack_dir.angle()
		weapon_sprite.position.x = hand + reach * 0.2 * out_k
	else:
		weapon_pivot.rotation = attack_dir.angle()
		weapon_sprite.position.x = hand - GameData.m(0.12) * sin(clampf(state_t / attack_dur, 0.0, 1.0) * PI)
	if not attack_hit_done and state_t >= attack_hit_at:
		attack_hit_done = true
		if style == "shoot":
			_shoot()
		else:
			_strike(style)
	if k >= 1.0:
		state = "free"
		weapon_pivot.visible = false
		weapon_sprite.position.x = hand
		combo_timer = 0.5


func _dmg_mult() -> float:
	var m: float = [0.0, 1.0, 1.1, 1.9][combo_i]
	if focus_t > 0.0:
		m *= 1.5
	return m


func _strike(style: String) -> void:
	var fx: Node2D = GameState.world.fx
	var reach: float = GameData.m(float(weapon.get("reach", 2.5)) + 0.1 * float(combo_i))
	var arc: float = float(weapon.get("arc", 1.9))
	if combo_i == 3 and style == "slash":
		arc *= 1.35
	var mult: float = _dmg_mult()
	var origin: Vector2 = global_position + Vector2(0, -GameData.m(0.8))
	var col: Color = Color(0.85, 0.95, 1.0)
	if combo_i == 3:
		col = Color(1.0, 0.9, 0.55)
	fx.slash(origin, attack_dir.angle(), reach * 0.95, arc if style == "slash" else 0.35, col)
	var hit_any: bool = false
	var crit_any: bool = false
	for e in get_tree().get_nodes_in_group("enemies"):
		if not is_instance_valid(e) or e.state == "dead":
			continue
		var v: Vector2 = e.global_position - global_position
		var ok: bool = false
		if style == "thrust":
			var along: float = v.dot(attack_dir)
			var lateral: float = absf(v.cross(attack_dir))
			ok = along > -20.0 and along <= reach + e.radius_px and lateral <= GameData.m(0.75) + e.radius_px
		else:
			if v.length() <= reach + e.radius_px:
				var diff: float = absf(angle_difference(attack_dir.angle(), v.angle()))
				ok = diff <= arc * 0.5 or v.length() <= e.radius_px * 1.2
		if not ok:
			continue
		var crit: bool = randf() < float(weapon.get("crit", 0.15)) + (0.25 if focus_t > 0.0 else 0.0)
		var dmg: float = GameState.attack_power() * float(weapon.get("dmg", 1.0)) * mult * randf_range(0.92, 1.08)
		if crit:
			dmg *= 1.8
			crit_any = true
		var knock: float = float(weapon.get("knock", 260.0)) * (1.0 if combo_i < 3 else 2.2)
		e.take_damage(dmg, global_position, knock, crit, "weapon")
		hit_any = true
		GameState.qi = minf(GameState.max_qi(), GameState.qi + 2.5)
	if hit_any:
		combo_count += 1
		combo_count_timer = 2.2
		fx.hitstop(0.045 if combo_i < 3 else 0.09)
		fx.shake(4.0 if combo_i < 3 else 10.0, 0.18)
		GameState.vibrate(12)
		Sfx.play("crit" if crit_any else "hit", 0.8)
	elif combo_i == 3:
		fx.shake(3.0, 0.12)


func _shoot() -> void:
	var count: int = 3 if combo_i == 3 else 1
	var base: float = attack_dir.angle()
	var origin: Vector2 = global_position + Vector2(0, -GameData.m(0.95)) + attack_dir * GameData.m(0.9)
	var spd: float = GameData.m(24.0)
	var rng: float = float(weapon.get("reach", 15.0))
	for i in range(count):
		var spread: float = (float(i) - float(count - 1) * 0.5) * 0.2
		var a: float = base + spread
		var p = ProjectileScript.new()
		p.position = origin
		p.setup({
			"mode": "arrow", "sprite": String(weapon.get("arrow", "w_arrow")), "dir": Vector2(cos(a), sin(a)), "speed": spd,
			"damage": GameState.attack_power() * float(weapon.get("dmg", 0.85)) * _dmg_mult() * randf_range(0.92, 1.08),
			"color": Color(1.0, 0.95, 0.8), "life": rng / 24.0, "hit_r": GameData.m(0.45), "kind": "arrow",
			"pierce": combo_i == 3, "knock": float(weapon.get("knock", 120.0)),
		})
		GameState.world.fx.add_child(p)
	GameState.qi = minf(GameState.max_qi(), GameState.qi + 1.0)


# ----------------------------------------------------------------- dash / perfect dodge
func try_dash() -> void:
	if state == "dead" or state == "dash":
		return
	if state == "meditate":
		_stop_meditate()
	if GameState.stamina < 24.0:
		return
	GameState.stamina -= 24.0
	stamina_delay = 0.7
	dash_dir = move_dir.normalized() if move_dir.length() > 0.2 else aim_dir
	face_toward(dash_dir.x)
	state = "dash"
	state_t = 0.23
	iframes = maxf(iframes, 0.32)
	dodge_window = 0.34
	dodge_used = false
	dash_after_t = 0.0
	weapon_pivot.visible = false
	tool_pivot.visible = false
	squash = Vector2(1.25, 0.8)
	GameState.world.fx.burst(global_position, Color(0.7, 0.85, 1.0), 8, 160.0, 0.3, 4.0)
	Sfx.play("dash", 0.6)


func _perfect_dodge() -> void:
	dodge_used = true
	focus_t = 3.0
	GameState.stamina = minf(GameState.max_stamina(), GameState.stamina + 35.0)
	GameState.qi = minf(GameState.max_qi(), GameState.qi + 15.0)
	var fx: Node2D = GameState.world.fx
	fx.damage_number(global_position + Vector2(0, -height_px - 10.0), 0, Color(1.0, 0.9, 0.35), true, "PERFECT DODGE!")
	fx.ring(global_position, GameData.m(2.5), Color(0.6, 0.9, 1.0), 0.4)
	fx.slowmo(0.3)
	Sfx.play("quest", 0.5, 1.4)


# ----------------------------------------------------------------- skills
func skill_unlocked(i: int) -> bool:
	if i < 0 or i >= GameData.skill_order.size():
		return false
	var d: Dictionary = GameData.skills.get(String(GameData.skill_order[i]), {})
	return GameState.realm >= int(d.get("realm", 0))


func skill_cd_ratio(i: int) -> float:
	if i < 0 or i >= GameData.skill_order.size():
		return 0.0
	var d: Dictionary = GameData.skills.get(String(GameData.skill_order[i]), {})
	var cd: float = float(d.get("cd", 1.0))
	return clampf(float(skill_cd[i]) / maxf(cd, 0.01), 0.0, 1.0)


func cast_skill(i: int) -> void:
	if state == "dead" or state == "dash" or i < 0 or i >= GameData.skill_order.size():
		return
	var id: String = String(GameData.skill_order[i])
	var d: Dictionary = GameData.skills.get(id, {})
	if d.is_empty():
		return
	if mounted:
		GameState.say("Dismount to use skills.", Color(0.8, 0.9, 1.0))
		return
	if not skill_unlocked(i):
		GameState.say("%s unlocks at %s." % [String(d["name"]), String(GameData.realm_def(int(d["realm"])).get("name", "?"))], Color(1, 0.8, 0.5))
		return
	if float(skill_cd[i]) > 0.0:
		return
	var cost: float = float(d.get("qi", 10))
	if GameState.qi < cost:
		GameState.say("Not enough Qi.", Color(0.6, 0.8, 1.0))
		return
	if state == "meditate":
		_stop_meditate()
	GameState.qi -= cost
	skill_cd[i] = float(d.get("cd", 1.0))
	state = "cast"
	state_t = 0.2
	weapon_pivot.visible = false
	tool_pivot.visible = false
	var dir: Vector2 = current_aim()
	face_toward(dir.x)
	squash = Vector2(1.12, 0.9)
	var col: Color = _col(d.get("color", [1, 1, 1]))
	var origin: Vector2 = global_position + Vector2(0, -GameData.m(0.9))
	var fx: Node2D = GameState.world.fx
	fx.ring(global_position, GameData.m(1.6), col, 0.3)
	Sfx.play(String(d.get("sfx", "fire")), 0.8)
	match String(d.get("kind", "")):
		"projectile":
			_spawn_projectile(d, id, origin + dir * GameData.m(0.7), dir, col)
		"palm":
			_cast_palm(d, dir, col)
		"swords":
			_cast_swords(d, origin, dir, col)
		"shield":
			_cast_shield(d, col)


func _col(v: Variant) -> Color:
	if typeof(v) == TYPE_ARRAY and v.size() >= 3:
		return Color(float(v[0]), float(v[1]), float(v[2]), 1.0)
	return Color.WHITE


func _spawn_projectile(d: Dictionary, id: String, pos: Vector2, dir: Vector2, col: Color) -> void:
	var p = ProjectileScript.new()
	p.position = pos
	p.setup({
		"sprite": String(d.get("sprite", "fx_fireball")), "dir": dir, "speed": GameData.m(float(d.get("speed", 10.0))),
		"damage": GameState.attack_power() * float(d.get("dmg", 2.0)), "explode": GameData.m(float(d.get("explode", 0.0))),
		"pierce": bool(d.get("pierce", false)), "slow": float(d.get("slow", 0.0)), "burn": float(d.get("burn", 0.0)),
		"chain": int(d.get("chain", 0)), "chain_range": float(d.get("chain_range", 6.0)), "chain_falloff": float(d.get("chain_falloff", 0.8)),
		"stun": float(d.get("stun", 0.0)),
		"color": col, "life": 1.6, "hit_r": GameData.m(0.55), "kind": id,
	})
	GameState.world.fx.add_child(p)


func _cast_palm(d: Dictionary, dir: Vector2, col: Color) -> void:
	var rng: float = GameData.m(float(d.get("range", 6.0)))
	var tgt: Vector2 = global_position + dir * GameData.m(3.5)
	var e: Node2D = nearest_enemy(rng)
	if e != null:
		tgt = e.global_position
	var radius: float = GameData.m(float(d.get("radius", 3.0)))
	var dmg: float = GameState.attack_power() * float(d.get("dmg", 4.0))
	var stun: float = float(d.get("stun", 1.0))
	GameState.world.fx.palm_strike(tgt, radius, col, Callable(GameState.world, "aoe_damage").bind(tgt, radius, dmg, stun, 700.0, "palm"))


func _cast_swords(d: Dictionary, origin: Vector2, dir: Vector2, col: Color) -> void:
	var n: int = int(d.get("count", 6))
	for i in range(n):
		var p = ProjectileScript.new()
		var spread: float = (float(i) - float(n - 1) * 0.5) * 0.42
		var a: float = dir.angle() + spread
		var off: Vector2 = Vector2(cos(a), sin(a)) * GameData.m(0.6)
		p.position = origin + off
		p.setup({
			"sprite": "fx_flying_sword", "dir": Vector2(cos(a), sin(a)), "speed": GameData.m(float(d.get("speed", 16.0))),
			"damage": GameState.attack_power() * float(d.get("dmg", 1.7)), "mode": "sword", "delay": 0.12 + 0.05 * float(i),
			"color": col, "life": 3.0, "hit_r": GameData.m(0.7), "pierce": true, "kind": "flying_sword", "max_hits": 2,
		})
		GameState.world.fx.add_child(p)


func _cast_shield(d: Dictionary, col: Color) -> void:
	shield_def = d
	shield_max = GameState.max_hp() * float(d.get("absorb", 0.8))
	shield_hp = shield_max
	shield_t = float(d.get("duration", 6.0))
	shield_fx.visible = true
	shield_fx.scale = Vector2(0.2, 0.2)
	var tw: Tween = create_tween()
	tw.tween_property(shield_fx, "scale", Vector2.ONE, 0.25).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	GameState.world.fx.ring(global_position, GameData.m(2.6), col, 0.5)


func _update_shield(delta: float) -> void:
	if shield_t <= 0.0 and shield_hp <= 0.0:
		return
	shield_t -= delta
	shield_fx.ratio = clampf(shield_hp / maxf(shield_max, 1.0), 0.0, 1.0)
	if shield_t <= 0.0 or shield_hp <= 0.0:
		_break_shield()


func _break_shield() -> void:
	shield_fx.visible = false
	var d: Dictionary = shield_def
	shield_hp = 0.0
	shield_t = 0.0
	if d.is_empty():
		return
	var radius: float = GameData.m(float(d.get("radius", 3.4)))
	var col: Color = _col(d.get("color", [1, 0.85, 0.3]))
	GameState.world.aoe_damage(global_position, radius, GameState.attack_power() * float(d.get("dmg", 3.0)), float(d.get("stun", 1.0)), 650.0, "bell")
	GameState.world.fx.ring(global_position, radius, col, 0.5)
	GameState.world.fx.burst(global_position + Vector2(0, -50), col, 24, 420.0, 0.6, 6.0)
	GameState.world.fx.shake(10.0, 0.25)
	Sfx.play("bell")


# ----------------------------------------------------------------- gathering
func start_gather(node) -> void:
	if state != "free" or mounted or node == null or not is_instance_valid(node) or node.depleted:
		return
	var tool_kind: String = String(node.tool_needed())
	if tool_kind != "" and not GameState.has_tool(tool_kind):
		GameState.say("You need a %s for that." % ("woodcutter axe" if tool_kind == "axe" else "miner pickaxe"), Color(1, 0.8, 0.5))
		Sfx.play("click")
		return
	gather_target = node
	gather_hit_done = false
	state = "gather"
	state_t = 0.0
	var v: Vector2 = node.global_position - global_position
	if v.length() > 1.0:
		attack_dir = v.normalized()
		face_toward(v.x)
	if tool_kind == "":
		tool_pivot.visible = false
	else:
		tool_sprite.texture = GameData.icon(tool_kind)
		tool_pivot.visible = true
		tool_pivot.rotation = attack_dir.angle() - 1.2
	GameState.stamina = maxf(0.0, GameState.stamina - 3.0)
	stamina_delay = 0.3
	squash = Vector2(0.9, 1.1)


func _update_gather(delta: float) -> void:
	state_t += delta
	var k: float = clampf(state_t / 0.4, 0.0, 1.0)
	if tool_pivot.visible:
		tool_pivot.rotation = attack_dir.angle() + lerpf(-1.2, 0.9, 1.0 - pow(1.0 - k, 3.0))
	if not gather_hit_done and state_t >= 0.18:
		gather_hit_done = true
		if gather_target != null and is_instance_valid(gather_target):
			gather_target.hit(1.0)
	if k >= 1.0:
		state = "free"
		tool_pivot.visible = false
		gather_target = null


# ----------------------------------------------------------------- meditation
func start_meditate(node) -> void:
	if state != "free" or mounted or node == null or not is_instance_valid(node):
		return
	if node.charge < 3.0:
		GameState.say("This spirit tree is drained. Give it time to recover.", Color(0.8, 0.9, 1.0))
		return
	meditate_node = node
	state = "meditate"
	state_t = 0.0
	med_fx_t = 0.0
	weapon_pivot.visible = false
	tool_pivot.visible = false
	GameState.say("You sit beneath the spirit tree. Move to stop.", Color(0.7, 0.95, 1.0))
	Sfx.play("meditate", 0.7)


func _update_meditate(delta: float) -> void:
	if meditate_node == null or not is_instance_valid(meditate_node) or move_dir.length() > 0.3:
		_stop_meditate()
		return
	var use: float = meditate_node.meditate_use(delta)
	if use <= 0.0:
		GameState.say("The spirit tree's power is spent.", Color(0.8, 0.9, 1.0))
		_stop_meditate()
		return
	var mult: float = meditate_node.spirit_mult()
	med_rate = GameState.xp_needed() * 0.0025 * mult
	GameState.add_xp(med_rate * use)
	GameState.qi = minf(GameState.max_qi(), GameState.qi + GameState.qi_regen() * 3.0 * use)
	GameState.hp = minf(GameState.max_hp(), GameState.hp + GameState.max_hp() * 0.02 * mult * use)
	med_fx_t -= delta
	if med_fx_t <= 0.0:
		med_fx_t = 0.9
		var fxn: Node2D = GameState.world.fx
		fxn.ring(global_position, GameData.m(1.8), Color(0.5, 0.85, 1.0), 0.8, 10.0)
		fxn.burst(global_position + Vector2(0, -GameData.m(0.5)), Color(0.6, 0.9, 1.0), 6, 90.0, 0.9, 3.0)


func _stop_meditate() -> void:
	if state == "meditate":
		state = "free"
	meditate_node = null
	med_rate = 0.0


# ----------------------------------------------------------------- flying sword mount
func toggle_mount() -> void:
	if state == "dead":
		return
	if mounted:
		_dismount()
		return
	if not GameState.mount_unlocked():
		GameState.say("Reach the Foundation Establishment realm to fly on a sword.", Color(1, 0.85, 0.55))
		return
	if GameState.qi < 12.0:
		GameState.say("Not enough Qi to fly.", Color(0.6, 0.8, 1.0))
		return
	if state == "meditate":
		_stop_meditate()
	if state == "attack" or state == "gather":
		state = "free"
		weapon_pivot.visible = false
		tool_pivot.visible = false
	mounted = true
	collision_mask = 1
	mount_sprite.visible = true
	GameState.world.fx.ring(global_position, GameData.m(2.0), Color(0.7, 0.9, 1.0), 0.4)
	Sfx.play("whoosh", 0.6)


func _dismount() -> void:
	mounted = false
	collision_mask = 17
	var w: Node = GameState.world
	if w != null and w.is_water_at(global_position):
		var land: Vector2 = w.nearest_land(global_position)
		w.fx.burst(global_position, Color(0.6, 0.85, 1.0), 16, 260.0, 0.5, 4.0)
		global_position = land
		w.fx.burst(land, Color(0.6, 0.85, 1.0), 10, 160.0, 0.4, 4.0)
		Sfx.play("water", 0.6)
		if camera != null:
			camera.reset_smoothing()
	else:
		Sfx.play("whoosh", 0.4, 0.8)


func _update_mount(delta: float) -> void:
	var target: float = 1.0 if mounted else 0.0
	mount_k = move_toward(mount_k, target, delta * 5.0)
	if mount_k <= 0.001 and not mounted:
		mount_sprite.visible = false
		shadow.scale = Vector2.ONE
		return
	var lift: float = GameData.m(0.5) * mount_k
	body_root.position.y -= lift
	mount_sprite.visible = true
	mount_sprite.position = Vector2(0, -GameData.m(0.28) * mount_k + sin(Time.get_ticks_msec() * 0.006) * 3.0)
	var info: Dictionary = GameData.sprite_info("fx_flying_sword")
	var sc: float = float(info.get("scale", 0.5))
	mount_sprite.scale = Vector2(sc * face, sc)
	mount_sprite.rotation = lean * 0.6
	shadow.scale = Vector2.ONE * (1.0 - 0.25 * mount_k)
	if mounted:
		mount_trail_t -= delta
		if mount_trail_t <= 0.0 and velocity.length() > 40.0:
			mount_trail_t = 0.05
			GameState.world.fx.burst(global_position + Vector2(-face * 40.0, -GameData.m(0.3)), Color(0.7, 0.9, 1.0), 2, 60.0, 0.4, 3.5)
		if GameState.qi <= 0.5:
			GameState.say("Your Qi runs dry...", Color(0.7, 0.85, 1.0))
			_dismount()


# ----------------------------------------------------------------- damage
func take_damage(amount: float, from_pos: Vector2, knock: float = 300.0) -> void:
	if state == "dead":
		return
	if iframes > 0.0:
		if dodge_window > 0.0 and not dodge_used and amount > 0.0:
			_perfect_dodge()
		return
	var dmg: float = amount * (1.0 - GameState.damage_reduction())
	var fx: Node2D = GameState.world.fx
	if state == "meditate":
		_stop_meditate()
	if shield_hp > 0.0:
		var absorbed: float = minf(shield_hp, dmg)
		shield_hp -= absorbed
		dmg -= absorbed
		fx.damage_number(global_position + Vector2(0, -height_px), absorbed, Color(1, 0.9, 0.4))
		flash(0.5, 0.1, Color(1, 0.9, 0.4))
		Sfx.play("equip", 0.5, 0.7)
		if dmg <= 0.0:
			iframes = 0.15
			return
	GameState.hp -= dmg
	no_hurt_t = 5.0
	iframes = 0.4
	flash(1.0, 0.14, Color(1, 0.35, 0.3))
	fx.damage_number(global_position + Vector2(0, -height_px), dmg, Color(1, 0.4, 0.35))
	fx.shake(9.0, 0.25)
	fx.burst(global_position + Vector2(0, -50), Color(1, 0.3, 0.3), 8, 200.0, 0.3, 4.0)
	GameState.vibrate(35)
	Sfx.play("hurt", 0.8)
	var away: Vector2 = (global_position - from_pos)
	if away.length() < 1.0:
		away = Vector2.RIGHT
	kb = away.normalized() * knock
	if state == "attack" or state == "gather":
		state = "free"
		weapon_pivot.visible = false
		tool_pivot.visible = false
	if GameState.hp <= 0.0:
		GameState.hp = 0.0
		_die()


func _die() -> void:
	state = "dead"
	weapon_pivot.visible = false
	tool_pivot.visible = false
	shield_fx.visible = false
	if mounted:
		_dismount()
	velocity = Vector2.ZERO
	lean = 1.4 * face
	GameState.world.fx.shake(14.0, 0.4)
	died.emit()


func revive_at(pos: Vector2) -> void:
	global_position = pos
	state = "free"
	GameState.hp = GameState.max_hp()
	GameState.qi = GameState.max_qi()
	GameState.stamina = GameState.max_stamina()
	iframes = 2.0
	lean = 0.0
	body_root.rotation = 0.0
	if camera != null:
		camera.reset_smoothing()
