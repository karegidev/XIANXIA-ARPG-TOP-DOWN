extends Node2D
## Station - crafting station (smelter, anvil, crafting table, cooking fireplace, alchemy furnace).
## Interactable API: ikind, iprio, iradius, iprompt().

var stype: String = ""
var def: Dictionary = {}
var ikind: String = "station"
var iprio: int = 3
var iradius: float = 150.0
var sprite: Sprite2D = null
var t: float = 0.0
var fire: bool = false


func _ready() -> void:
	def = GameData.stations.get(stype, {})
	sprite = GameData.make_sprite(String(def.get("sprite", "st_table")))
	add_child(sprite)
	var fp: Array = def.get("footprint", [1.2, 0.8])
	var body: StaticBody2D = StaticBody2D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	var cs: CollisionShape2D = CollisionShape2D.new()
	var r: RectangleShape2D = RectangleShape2D.new()
	r.size = Vector2(GameData.m(float(fp[0])), GameData.m(float(fp[1])))
	cs.shape = r
	cs.position = Vector2(0, -r.size.y * 0.5)
	body.add_child(cs)
	add_child(body)
	iradius = GameData.m(2.6)
	fire = stype == "cooking" or stype == "smelter"
	set_process(fire)
	add_to_group("interactables")


func iprompt() -> String:
	return String(def.get("verb", "USE"))


func _process(delta: float) -> void:
	t += delta
	queue_redraw()


func _draw() -> void:
	if not fire:
		return
	var f: float = 0.5 + 0.5 * sin(t * 9.0) * sin(t * 5.3)
	draw_set_transform(Vector2(0, -GameData.m(0.25)), 0.0, Vector2(1.0, 0.55))
	draw_circle(Vector2.ZERO, GameData.m(1.7), Color(1.0, 0.5, 0.15, 0.05 + 0.05 * f))
	draw_circle(Vector2.ZERO, GameData.m(1.0), Color(1.0, 0.6, 0.2, 0.07 + 0.06 * f))
