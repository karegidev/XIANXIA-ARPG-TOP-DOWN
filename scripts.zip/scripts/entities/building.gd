extends Node2D
## Building - a sprite with a collision footprint. kind "well" makes it interactable (draw water / drink).

var sprite_id: String = ""
var footprint: Array = [4.0, 2.0]
var bkind: String = ""
var ikind: String = "well"
var iprio: int = 2
var iradius: float = 150.0


func _ready() -> void:
	var sp: Sprite2D = GameData.make_sprite(sprite_id)
	add_child(sp)
	var footprint_size: Vector2 = Vector2(GameData.m(float(footprint[0])), GameData.m(float(footprint[1])))
	var body: StaticBody2D = StaticBody2D.new()
	body.collision_layer = 1
	body.collision_mask = 0
	var cs: CollisionShape2D = CollisionShape2D.new()
	var shape: RectangleShape2D = RectangleShape2D.new()
	shape.size = footprint_size
	cs.shape = shape
	cs.position = Vector2(0, -footprint_size.y * 0.5)
	body.add_child(cs)
	add_child(body)
	if bkind == "well":
		iradius = GameData.m(2.8)
		add_to_group("interactables")


func iprompt() -> String:
	if bkind != "well":
		return ""
	return "FILL" if GameState.item_count("empty_bucket") > 0 else "DRINK"


func use_well() -> void:
	var fxn: Node2D = GameState.world.fx
	if GameState.item_count("empty_bucket") > 0:
		GameState.remove_item("empty_bucket", 1)
		GameState.add_item("filled_bucket", 1)
		GameState.say("You fill your bucket with fresh water.", Color(0.6, 0.85, 1.0))
		fxn.burst(global_position + Vector2(0, -GameData.m(1.0)), Color(0.6, 0.85, 1.0), 10, 160.0, 0.5, 3.5)
		Sfx.play("water", 0.6)
	else:
		GameState.stamina = GameState.max_stamina()
		GameState.hp = minf(GameState.max_hp(), GameState.hp + GameState.max_hp() * 0.1)
		GameState.say("You drink cool well water. Stamina restored.", Color(0.6, 0.85, 1.0))
		Sfx.play("eat", 0.6)
