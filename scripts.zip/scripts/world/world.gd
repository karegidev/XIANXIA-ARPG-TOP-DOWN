extends Node2D
## World - builds the map from data/world.json and runs spawners, interaction, loot, combat services, day cycle and minimap.
## Edit data/world.json (ASCII tile rows, buildings, props, stations, chests, NPCs, spawners) to change/expand the map.

signal zone_entered(zone_name: String, safe: bool)
signal interact_target_changed(node)
signal player_died

const FxScript: GDScript = preload("res://scripts/combat/fx.gd")
const PlayerScript: GDScript = preload("res://scripts/entities/player.gd")
const EnemyScript: GDScript = preload("res://scripts/entities/enemy.gd")
const NpcScript: GDScript = preload("res://scripts/entities/npc.gd")
const PickupScript: GDScript = preload("res://scripts/entities/pickup.gd")
const PropScript: GDScript = preload("res://scripts/entities/prop.gd")
const StationScript: GDScript = preload("res://scripts/entities/station.gd")
const ChestScript: GDScript = preload("res://scripts/entities/chest.gd")
const BuildingScript: GDScript = preload("res://scripts/entities/building.gd")
const SWAY_SHADER: Shader = preload("res://shaders/sway.gdshader")
const WATER_SHADER: Shader = preload("res://shaders/water.gdshader")

const TILE_PX: int = 128
const MINI_PX: int = 3
const LAYER_WORLD: int = 1
const LAYER_WATER: int = 16

var ground: TileMapLayer = null
var water_layer: TileMapLayer = null
var ground_fx: Node2D = null
var entities: Node2D = null
var fx = null
var player = null
var canvas_mod: CanvasModulate = null
var sway_mat: ShaderMaterial = null

var map_w: int = 120
var map_h: int = 80
var rows: Array = []
var tile_char_to_index: Dictionary = {}
var blocked_chars: Array = []
var building_rects: Array = []     # Rect2 in px (footprints) for spawn validation
var obstacle_buckets: Dictionary = {}

var spawners: Array = []
var active_boss = null
var minimap_tex: ImageTexture = null
var nearest_interact = null
var _last_prompt: String = ""
var zone_name: String = ""
var zone_safe: bool = true
var pois: Array = []

var _cull_t: float = 0.0
var _interact_t: float = 0.0
var _zone_t: float = 0.0
var _respawn_t: float = -1.0


func _ready() -> void:
	GameState.world = self
	var wd: Dictionary = GameData.world
	map_w = int(wd.get("size", [120, 80])[0])
	map_h = int(wd.get("size", [120, 80])[1])
	rows = wd.get("rows", [])
	blocked_chars = wd.get("blocked", ["w"])
	pois = wd.get("pois", [])
	sway_mat = ShaderMaterial.new()
	sway_mat.shader = SWAY_SHADER
	_build_ground(wd)
	ground_fx = Node2D.new()
	ground_fx.name = "GroundFx"
	add_child(ground_fx)
	entities = Node2D.new()
	entities.name = "Entities"
	entities.y_sort_enabled = true
	add_child(entities)
	fx = FxScript.new()
	fx.name = "Fx"
	fx.ground = ground_fx
	add_child(fx)
	canvas_mod = CanvasModulate.new()
	add_child(canvas_mod)
	_build_colliders()
	_build_buildings(wd)
	_build_props(wd)
	_build_stations(wd)
	_build_chests(wd)
	_build_npcs(wd)
	_build_player(wd)
	_build_spawners(wd)
	_build_minimap()
	GameState.player = player
	player.died.connect(_on_player_died)
	_update_daylight()


# ------------------------------------------------------------------ build: terrain
func _build_ground(wd: Dictionary) -> void:
	var ids: Array = GameData.tiles.get("ids", [])
	var legend: Dictionary = wd.get("legend", {})
	for ch in legend.keys():
		tile_char_to_index[String(ch)] = ids.find(String(legend[ch]))
	var tset: TileSet = TileSet.new()
	tset.tile_size = Vector2i(TILE_PX, TILE_PX)
	var src: TileSetAtlasSource = TileSetAtlasSource.new()
	src.texture = load("res://assets/tiles/terrain_atlas.png")
	src.texture_region_size = Vector2i(TILE_PX, TILE_PX)
	var variants: Dictionary = {}
	for i in range(ids.size()):
		src.create_tile(Vector2i(i, 0))
		variants[i] = [0]
	# subtle brightness variants so big fields look like patchy meadow instead of a flat repeat
	for tid in ["grass", "forest", "dirt_path", "sand", "mud", "paving", "slab"]:
		var idx: int = ids.find(tid)
		if idx < 0:
			continue
		var a1: int = src.create_alternative_tile(Vector2i(idx, 0))
		var a2: int = src.create_alternative_tile(Vector2i(idx, 0))
		var td1: TileData = src.get_tile_data(Vector2i(idx, 0), a1)
		var td2: TileData = src.get_tile_data(Vector2i(idx, 0), a2)
		td1.modulate = Color(0.92, 0.94, 0.92, 1.0)
		td2.modulate = Color(1.07, 1.06, 1.0, 1.0)
		variants[idx] = [0, a1, a2]
	var sid: int = tset.add_source(src)
	ground = TileMapLayer.new()
	ground.name = "Ground"
	ground.tile_set = tset
	add_child(ground)
	var noise: FastNoiseLite = FastNoiseLite.new()
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise.frequency = 0.085
	noise.seed = 7
	# animated water layer (own atlas so the shader can wobble UVs safely)
	var wset: TileSet = TileSet.new()
	wset.tile_size = Vector2i(TILE_PX, TILE_PX)
	var wsrc: TileSetAtlasSource = TileSetAtlasSource.new()
	wsrc.texture = load("res://assets/tiles/water_tile.png")
	wsrc.texture_region_size = Vector2i(TILE_PX, TILE_PX)
	wsrc.create_tile(Vector2i(0, 0))
	var wsid: int = wset.add_source(wsrc)
	water_layer = TileMapLayer.new()
	water_layer.name = "Water"
	water_layer.tile_set = wset
	var wmat: ShaderMaterial = ShaderMaterial.new()
	wmat.shader = WATER_SHADER
	water_layer.material = wmat
	for y in range(rows.size()):
		var row: String = String(rows[y])
		for x in range(row.length()):
			var ch: String = row.substr(x, 1)
			var idx: int = int(tile_char_to_index.get(ch, 0))
			if idx < 0:
				idx = 0
			var alt: int = 0
			var vlist: Array = variants.get(idx, [0])
			if vlist.size() > 1:
				var n: float = noise.get_noise_2d(float(x), float(y))
				if n < -0.22:
					alt = int(vlist[1])
				elif n > 0.22:
					alt = int(vlist[2])
			ground.set_cell(Vector2i(x, y), sid, Vector2i(idx, 0), alt)
			if blocked_chars.has(ch):
				water_layer.set_cell(Vector2i(x, y), wsid, Vector2i(0, 0))
	add_child(water_layer)


func _add_rect_body(rect: Rect2, layer: int) -> void:
	var body: StaticBody2D = StaticBody2D.new()
	body.collision_layer = layer
	body.collision_mask = 0
	var cs: CollisionShape2D = CollisionShape2D.new()
	var shape: RectangleShape2D = RectangleShape2D.new()
	shape.size = rect.size
	cs.shape = shape
	body.position = rect.position + rect.size * 0.5
	body.add_child(cs)
	add_child(body)


func _build_colliders() -> void:
	# merge blocked tiles (water) into rectangles on the WATER layer: walkers collide, flying sword does not
	var open: Dictionary = {}
	var inset: float = 10.0
	for y in range(rows.size() + 1):
		var cur: Dictionary = {}
		if y < rows.size():
			var row: String = String(rows[y])
			var x: int = 0
			while x < row.length():
				if blocked_chars.has(row.substr(x, 1)):
					var x0: int = x
					while x < row.length() and blocked_chars.has(row.substr(x, 1)):
						x += 1
					cur["%d:%d" % [x0, x - 1]] = true
				else:
					x += 1
		for k in open.keys():
			if not cur.has(k):
				_emit_block(k, int(open[k]), y - 1, inset)
				open.erase(k)
		for k in cur.keys():
			if not open.has(k):
				open[k] = y
	var wpx: float = float(map_w * TILE_PX)
	var hpx: float = float(map_h * TILE_PX)
	_add_rect_body(Rect2(-300, -300, wpx + 600, 300), LAYER_WORLD)
	_add_rect_body(Rect2(-300, hpx, wpx + 600, 300), LAYER_WORLD)
	_add_rect_body(Rect2(-300, 0, 300, hpx), LAYER_WORLD)
	_add_rect_body(Rect2(wpx, 0, 300, hpx), LAYER_WORLD)


func _emit_block(key: String, y0: int, y1: int, inset: float) -> void:
	var parts: PackedStringArray = key.split(":")
	var x0: int = int(parts[0])
	var x1: int = int(parts[1])
	var r: Rect2 = Rect2(float(x0 * TILE_PX) + inset, float(y0 * TILE_PX) + inset, float((x1 - x0 + 1) * TILE_PX) - inset * 2.0, float((y1 - y0 + 1) * TILE_PX) - inset * 2.0)
	_add_rect_body(r, LAYER_WATER)


# ------------------------------------------------------------------ build: objects
func _add_obstacle(pos: Vector2, r: float) -> void:
	var key: Vector2i = Vector2i(int(floor(pos.x / 256.0)), int(floor(pos.y / 256.0)))
	if not obstacle_buckets.has(key):
		obstacle_buckets[key] = []
	obstacle_buckets[key].append(Vector3(pos.x, pos.y, r))


func _build_buildings(wd: Dictionary) -> void:
	for b in wd.get("buildings", []):
		var node = BuildingScript.new()
		var p: Array = b.get("pos", [0, 0])
		node.position = Vector2(GameData.m(float(p[0])), GameData.m(float(p[1])))
		node.sprite_id = String(b.get("sprite", "house_common"))
		node.footprint = b.get("footprint", [4.0, 2.0])
		node.bkind = String(b.get("kind", ""))
		entities.add_child(node)
		var fp: Array = node.footprint
		var size: Vector2 = Vector2(GameData.m(float(fp[0])), GameData.m(float(fp[1])))
		building_rects.append(Rect2(node.position + Vector2(-size.x * 0.5 - 40.0, -size.y - 40.0), size + Vector2(80.0, 80.0)))


func _build_props(wd: Dictionary) -> void:
	for pr in wd.get("props", []):
		var id: String = String(pr.get("id", ""))
		if not GameData.props.has(id):
			continue
		var node = PropScript.new()
		node.pid = id
		node.decor = bool(pr.get("decor", false))
		var p: Array = pr.get("pos", [0, 0])
		node.position = Vector2(GameData.m(float(p[0])), GameData.m(float(p[1])))
		node.sway_mat = sway_mat
		entities.add_child(node)
		var col: Variant = GameData.props[id].get("collider", null)
		var r: float = 0.5
		if typeof(col) == TYPE_DICTIONARY:
			r = float(col.get("r", float(col.get("w", 1.0)) * 0.5))
		_add_obstacle(node.position, GameData.m(r + 0.4))


func _build_stations(wd: Dictionary) -> void:
	for s in wd.get("stations", []):
		var node = StationScript.new()
		node.stype = String(s.get("type", "table"))
		var p: Array = s.get("pos", [0, 0])
		node.position = Vector2(GameData.m(float(p[0])), GameData.m(float(p[1])))
		entities.add_child(node)
		_add_obstacle(node.position, GameData.m(1.4))


func _build_chests(wd: Dictionary) -> void:
	for c in wd.get("chests", []):
		var node = ChestScript.new()
		node.cid = String(c.get("id", ""))
		node.tier = int(c.get("tier", 1))
		node.coins = c.get("coins", [0, 0])
		node.loot = c.get("loot", [])
		var p: Array = c.get("pos", [0, 0])
		node.position = Vector2(GameData.m(float(p[0])), GameData.m(float(p[1])))
		entities.add_child(node)
		_add_obstacle(node.position, GameData.m(1.0))


func _build_npcs(wd: Dictionary) -> void:
	for n in wd.get("npcs", []):
		var npc = NpcScript.new()
		npc.nid = String(n.get("def", ""))
		var p: Array = n.get("pos", [0, 0])
		npc.position = Vector2(GameData.m(float(p[0])), GameData.m(float(p[1])))
		entities.add_child(npc)


func _build_player(wd: Dictionary) -> void:
	player = PlayerScript.new()
	var sp: Array = wd.get("player_start", [64, 90])
	var start: Vector2 = Vector2(GameData.m(float(sp[0])), GameData.m(float(sp[1])))
	if GameState.has_saved_pos:
		start = GameState.saved_pos
	player.position = start
	entities.add_child(player)
	var cam: Camera2D = player.camera
	cam.limit_left = 0
	cam.limit_top = 0
	cam.limit_right = map_w * TILE_PX
	cam.limit_bottom = map_h * TILE_PX
	fx.camera = cam


func _build_spawners(wd: Dictionary) -> void:
	for s in wd.get("spawners", []):
		var p: Array = s.get("pos", [0, 0])
		var rec: Dictionary = {
			"enemy": String(s.get("enemy", "wolf")),
			"pos": Vector2(GameData.m(float(p[0])), GameData.m(float(p[1]))),
			"radius": GameData.m(float(s.get("radius", 6.0))),
			"respawn": float(s.get("respawn", 50.0)),
			"slots": [],
		}
		for i in range(int(s.get("count", 1))):
			rec["slots"].append({"e": null, "t": 0.0, "first": true})
		spawners.append(rec)


func _build_minimap() -> void:
	var legend: Dictionary = GameData.world.get("legend", {})
	var img: Image = Image.create_empty(map_w * MINI_PX, map_h * MINI_PX, false, Image.FORMAT_RGB8)
	for y in range(rows.size()):
		var row: String = String(rows[y])
		for x in range(row.length()):
			var tid: String = String(legend.get(row.substr(x, 1), "grass"))
			var c: Color = GameData.tile_color(tid)
			for dy in range(MINI_PX):
				for dx in range(MINI_PX):
					img.set_pixel(x * MINI_PX + dx, y * MINI_PX + dy, c)
	minimap_tex = ImageTexture.create_from_image(img)


# ------------------------------------------------------------------ update
func _process(delta: float) -> void:
	_update_spawners(delta)
	_cull_t -= delta
	if _cull_t <= 0.0:
		_cull_t = 0.4
		_cull()
	_interact_t -= delta
	if _interact_t <= 0.0:
		_interact_t = 0.12
		_find_interact()
	_zone_t -= delta
	if _zone_t <= 0.0:
		_zone_t = 0.5
		_check_zone()
	GameState.time_of_day = fposmod(GameState.time_of_day + delta / 600.0, 1.0)
	_update_daylight()
	if _respawn_t > 0.0:
		_respawn_t -= delta
		if _respawn_t <= 0.0:
			_respawn_player()


func _update_daylight() -> void:
	var t: float = GameState.time_of_day
	var k: float = 0.5 + 0.5 * cos((t - 0.5) * TAU)
	var day: Color = Color(1, 1, 1, 1)
	var night: Color = Color(0.58, 0.64, 0.88, 1)
	var dusk: Color = Color(1.0, 0.82, 0.68, 1)
	var c: Color = night.lerp(day, smoothstep(0.12, 0.6, k))
	var warm: float = clampf(1.0 - absf(k - 0.38) * 5.0, 0.0, 1.0)
	canvas_mod.color = c.lerp(dusk, warm * 0.55)


func _update_spawners(delta: float) -> void:
	if player == null or not is_instance_valid(player):
		return
	for rec in spawners:
		for s in rec["slots"]:
			var e: Variant = s["e"]
			var alive: bool = e != null and is_instance_valid(e) and e.state != "dead"
			if alive:
				continue
			if e != null:
				s["e"] = null
				s["t"] = float(rec["respawn"])
				s["first"] = false
			s["t"] = float(s["t"]) - delta
			if float(s["t"]) <= 0.0:
				var far: bool = player.global_position.distance_to(rec["pos"]) > GameData.m(32.0)
				if bool(s["first"]) or far:
					var en = _spawn_in_radius(rec)
					if en != null:
						s["e"] = en
						s["first"] = false
					else:
						s["t"] = 2.0


func _spawn_in_radius(rec: Dictionary) -> Variant:
	for i in range(14):
		var ang: float = randf() * TAU
		var r: float = sqrt(randf()) * float(rec["radius"])
		var p: Vector2 = rec["pos"] + Vector2(cos(ang), sin(ang)) * r
		if is_pos_free(p):
			return spawn_enemy(String(rec["enemy"]), p, false)
	return null


func tile_char_at(p: Vector2) -> String:
	var tx: int = int(floor(p.x / float(TILE_PX)))
	var ty: int = int(floor(p.y / float(TILE_PX)))
	if tx < 0 or ty < 0 or tx >= map_w or ty >= map_h:
		return "w"
	return String(rows[ty]).substr(tx, 1)


func is_water_at(p: Vector2) -> bool:
	return blocked_chars.has(tile_char_at(p))


func is_pos_free(p: Vector2) -> bool:
	var tx: int = int(floor(p.x / float(TILE_PX)))
	var ty: int = int(floor(p.y / float(TILE_PX)))
	if tx < 1 or ty < 1 or tx >= map_w - 1 or ty >= map_h - 1:
		return false
	if blocked_chars.has(String(rows[ty]).substr(tx, 1)):
		return false
	for r in building_rects:
		if r.has_point(p):
			return false
	var bk: Vector2i = Vector2i(int(floor(p.x / 256.0)), int(floor(p.y / 256.0)))
	for dx in range(-1, 2):
		for dy in range(-1, 2):
			var key: Vector2i = Vector2i(bk.x + dx, bk.y + dy)
			if obstacle_buckets.has(key):
				for o in obstacle_buckets[key]:
					if (Vector2(o.x, o.y)).distance_to(p) < o.z:
						return false
	return true


func nearest_land(p: Vector2) -> Vector2:
	## closest walkable spot (used when the flying sword dismounts over water)
	for ring in range(1, 18):
		var best: Vector2 = Vector2.ZERO
		var bd: float = 1e9
		var found: bool = false
		for dy in range(-ring, ring + 1):
			for dx in range(-ring, ring + 1):
				if maxi(absi(dx), absi(dy)) != ring:
					continue
				var c: Vector2 = p + Vector2(float(dx), float(dy)) * 64.0
				if is_pos_free(c):
					var d: float = c.distance_to(p)
					if d < bd:
						bd = d
						best = c
						found = true
		if found:
			return best
	var sp: Array = GameData.world.get("player_start", [64, 90])
	return Vector2(GameData.m(float(sp[0])), GameData.m(float(sp[1])))


func spawn_enemy(id: String, pos: Vector2, as_minion: bool) -> Node2D:
	var e = EnemyScript.new()
	e.eid = id
	e.position = pos
	e.minion = as_minion
	entities.add_child(e)
	return e


func spawn_minions(id: String, count: int, around: Vector2, _owner: Node2D) -> void:
	var existing: int = 0
	for e in get_tree().get_nodes_in_group("enemies"):
		if is_instance_valid(e) and e.minion:
			existing += 1
	for i in range(count):
		if existing >= 6:
			break
		for t in range(8):
			var p: Vector2 = around + Vector2.from_angle(randf() * TAU) * GameData.m(randf_range(2.0, 3.5))
			if is_pos_free(p):
				var m = spawn_enemy(id, p, true)
				m.state = "chase"
				m.gcd = 0.6
				fx.burst(p, Color(0.7, 0.3, 1.0), 10, 220.0, 0.4, 4.0)
				existing += 1
				break


func _cull() -> void:
	if player == null or not is_instance_valid(player):
		return
	var far: float = GameData.m(46.0)
	for e in get_tree().get_nodes_in_group("enemies"):
		if not is_instance_valid(e):
			continue
		var active: bool = e.global_position.distance_to(player.global_position) < far
		e.set_physics_process(active)
	for n in get_tree().get_nodes_in_group("npcs"):
		if not is_instance_valid(n):
			continue
		n.set_physics_process(n.global_position.distance_to(player.global_position) < GameData.m(36.0))


func _find_interact() -> void:
	var best = null
	var best_score: float = -1.0e9
	var prompt: String = ""
	if player != null and is_instance_valid(player) and player.state != "dead":
		var pp: Vector2 = player.global_position
		for n in get_tree().get_nodes_in_group("interactables"):
			if not is_instance_valid(n) or not n.visible:
				continue
			var d: float = n.global_position.distance_to(pp)
			if d > float(n.iradius):
				continue
			var pr: String = String(n.iprompt())
			if pr == "":
				continue
			var score: float = float(n.iprio) * 1000.0 - d
			if score > best_score:
				best_score = score
				best = n
				prompt = pr
	if best != nearest_interact or prompt != _last_prompt:
		nearest_interact = best
		_last_prompt = prompt
		interact_target_changed.emit(best)


func _check_zone() -> void:
	if player == null or not is_instance_valid(player):
		return
	var pm: Vector2 = player.global_position / GameData.ppm
	var found: String = "Whispering Wilds"
	var safe: bool = false
	for z in GameData.world.get("zones", []):
		var r: Array = z.get("rect", [0, 0, 0, 0])
		if pm.x >= float(r[0]) and pm.x <= float(r[2]) and pm.y >= float(r[1]) and pm.y <= float(r[3]):
			found = String(z.get("name", found))
			safe = bool(z.get("safe", false))
			break
	if found != zone_name:
		zone_name = found
		zone_safe = safe
		zone_entered.emit(found, safe)


# ------------------------------------------------------------------ combat services
func aoe_damage(center: Vector2, radius: float, dmg: float, stun: float, knock: float, kind: String) -> Array:
	var hits: Array = []
	for e in get_tree().get_nodes_in_group("enemies"):
		if not is_instance_valid(e) or e.state == "dead":
			continue
		var d: float = center.distance_to(e.global_position)
		if d <= radius + float(e.radius_px):
			var fall: float = 1.0 - 0.25 * clampf(d / maxf(radius, 1.0), 0.0, 1.0)
			e.take_damage(dmg * fall, center, knock, false, kind)
			if stun > 0.0 and is_instance_valid(e) and e.state != "dead":
				e.apply_status("stun", stun, 1.0)
			hits.append(e)
	return hits


func boss_engaged(e) -> void:
	active_boss = e
	GameState.say("Boss: %s" % String(e.def.get("name", "?")), Color(1, 0.5, 0.4))


func boss_disengaged(e) -> void:
	if active_boss == e:
		active_boss = null


# ------------------------------------------------------------------ loot
func on_enemy_killed(e) -> void:
	var def: Dictionary = e.def
	GameState.register_kill(e.eid, String(def.get("tag", "")))
	var mult: float = 2.0 if e.elite else 1.0
	var xp: float = float(def.get("xp", 5)) * (2.5 if e.elite else 1.0)
	GameState.add_xp(xp)
	fx.damage_number(e.global_position + Vector2(0, -e.height_px - 24), xp, Color(1, 0.9, 0.4), false, "+%d Qi" % int(xp))
	var pos: Vector2 = e.global_position
	var cr: Array = def.get("coins", [2, 8])
	drop_coins(pos, int(float(randi_range(int(cr[0]), int(cr[1]))) * mult))
	var st: Array = def.get("stones", [0, 1])
	var sn: int = int(float(randi_range(int(st[0]), int(st[1]))) * mult)
	for i in range(mini(sn, 4)):
		drop_pickup(pos, "stone", "", maxi(1, int(ceil(float(sn) / float(mini(sn, 4))))))
	for entry in def.get("loot", []):
		if randf() <= float(entry.get("chance", 0.1)) * mult:
			drop_pickup(pos, "item", String(entry["item"]), randi_range(int(entry.get("min", 1)), int(entry.get("max", 1))))
	if e.elite and randf() < 0.35:
		drop_pickup(pos, "item", "qi_pill" if randf() < 0.5 else "healing_pill", 1)
	if bool(def.get("boss", false)):
		var pk = PickupScript.new()
		pk.kind = "pack"
		pk.pack_loot = def.get("pack", [])
		pk.position = pos + Vector2(0, 20)
		entities.add_child(pk)
		drop_pickup(pos, "hstone", "", 1)
		GameState.say("%s has been slain!" % String(def.get("name", "?")), Color(1, 0.9, 0.5))


func drop_pickup(pos: Vector2, kind: String, item_id: String, amount: int) -> void:
	var p = PickupScript.new()
	p.kind = kind
	p.item_id = item_id
	p.amount = amount
	p.position = pos
	entities.add_child(p)


func drop_coins(pos: Vector2, amount: int) -> void:
	if amount <= 0:
		return
	var n: int = clampi(int(ceil(float(amount) / 80.0)), 1, 5)
	var per: int = maxi(1, floori(float(amount) / float(n)))
	var left: int = amount
	for i in range(n):
		var v: int = per if i < n - 1 else left
		if v <= 0:
			break
		drop_pickup(pos, "coin", "", v)
		left -= v


func drop_loot(pos: Vector2, table: Array, coin_range: Vector2) -> void:
	if coin_range.y > 0.0:
		drop_coins(pos, randi_range(int(coin_range.x), int(coin_range.y)))
	for entry in table:
		if randf() <= float(entry.get("chance", 0.5)):
			var n: int = randi_range(int(entry.get("min", 1)), int(entry.get("max", 1)))
			if n > 0:
				drop_pickup(pos, "item", String(entry["item"]), n)


# ------------------------------------------------------------------ player death / respawn
func _on_player_died() -> void:
	_respawn_t = 3.0
	player_died.emit()


func _respawn_player() -> void:
	var lost: int = int(GameState.coins * 0.1)
	GameState.coins -= lost
	if lost > 0:
		GameState.say("You lost %s." % GameState.format_coins(lost), Color(1, 0.6, 0.5))
	var sp: Array = GameData.world.get("player_start", [64, 90])
	player.revive_at(Vector2(GameData.m(float(sp[0])), GameData.m(float(sp[1]))))
	for e in get_tree().get_nodes_in_group("enemies"):
		if is_instance_valid(e) and e.state != "dead" and e.state != "idle":
			e._disengage()
	GameState.stats_changed.emit()
