extends Node2D
## Fx - spawns visual effects (damage numbers, rings, slashes, sparks, afterimages, palm strike).
## Lives on top of the y-sorted entity layer.

const RingFx: GDScript = preload("res://scripts/combat/ring_fx.gd")
const SlashFx: GDScript = preload("res://scripts/combat/slash_fx.gd")
const SparkFx: GDScript = preload("res://scripts/combat/spark_fx.gd")
const BoltFx: GDScript = preload("res://scripts/combat/bolt_fx.gd")

var ground: Node2D = null      # layer under entities (telegraphs, decals)
var camera: Camera2D = null
var _shake: float = 0.0
var _shake_t: float = 0.0
var _label_count: int = 0
var _restore_ms: int = 0


func _process(delta: float) -> void:
	# safety net: time scale is ALWAYS restored using real (wall-clock) time, so slow-mo / hit-stop can never get stuck
	if _restore_ms > 0 and Time.get_ticks_msec() >= _restore_ms:
		Engine.time_scale = 1.0
		_restore_ms = 0
	if camera == null or not is_instance_valid(camera):
		return
	if _shake_t > 0.0:
		_shake_t -= delta
		var a: float = _shake * clampf(_shake_t / 0.35, 0.0, 1.0)
		camera.offset = Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * a
	else:
		camera.offset = camera.offset.lerp(Vector2.ZERO, 0.4)


func shake(amount: float, dur: float = 0.25) -> void:
	var s: float = float(GameState.settings.get("shake", 1.0))
	if s <= 0.0:
		return
	_shake = maxf(_shake * clampf(_shake_t, 0.0, 1.0), amount * s)
	_shake_t = maxf(_shake_t, dur)


func hitstop(sec: float) -> void:
	if Engine.time_scale < 0.5:
		return
	Engine.time_scale = 0.06
	_restore_ms = Time.get_ticks_msec() + int(sec * 1000.0) + 40
	var tm: SceneTreeTimer = get_tree().create_timer(sec, true, false, true)
	tm.timeout.connect(_end_hitstop)


func slowmo(sec: float) -> void:
	if Engine.time_scale < 0.5:
		return
	Engine.time_scale = 0.35
	_restore_ms = Time.get_ticks_msec() + int(sec * 1000.0) + 40
	var tm: SceneTreeTimer = get_tree().create_timer(sec, true, false, true)
	tm.timeout.connect(_end_hitstop)


func _end_hitstop() -> void:
	Engine.time_scale = 1.0
	_restore_ms = 0


func _exit_tree() -> void:
	Engine.time_scale = 1.0


func damage_number(pos: Vector2, amount: float, color: Color, crit: bool = false, text_override: String = "") -> void:
	if not bool(GameState.settings.get("damage_numbers", true)):
		return
	if _label_count > 28:
		return
	var l: Label = Label.new()
	l.text = text_override if text_override != "" else str(int(round(amount)))
	l.add_theme_font_size_override("font_size", 34 if crit else 24)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	l.add_theme_constant_override("outline_size", 7)
	l.position = pos + Vector2(randf_range(-18.0, 18.0) - 20.0, -20.0)
	l.z_index = 50
	l.pivot_offset = Vector2(20, 14)
	add_child(l)
	_label_count += 1
	var tw: Tween = create_tween()
	tw.set_parallel(true)
	if crit:
		l.scale = Vector2(1.6, 1.6)
		tw.tween_property(l, "scale", Vector2(1.0, 1.0), 0.18)
	tw.tween_property(l, "position:y", l.position.y - 70.0, 0.7).set_ease(Tween.EASE_OUT)
	tw.tween_property(l, "modulate:a", 0.0, 0.35).set_delay(0.4)
	tw.chain().tween_callback(_free_label.bind(l))


func _free_label(l: Label) -> void:
	_label_count = maxi(0, _label_count - 1)
	if is_instance_valid(l):
		l.queue_free()


func ring(pos: Vector2, radius: float, color: Color, life: float = 0.4, start: float = 10.0) -> void:
	var r = RingFx.new()
	r.position = pos
	r.r0 = start
	r.r1 = radius
	r.life = life
	r.color = color
	add_child(r)


func slash(pos: Vector2, angle: float, reach: float, arc: float, color: Color) -> void:
	var s = SlashFx.new()
	s.position = pos
	s.rotation = angle
	s.reach = reach
	s.arc = arc
	s.color = color
	add_child(s)


func burst(pos: Vector2, color: Color, count: int = 10, speed: float = 220.0, life: float = 0.45, size: float = 4.0) -> void:
	var s = SparkFx.new()
	s.position = pos
	s.setup(count, speed, color, life, size)
	add_child(s)


func afterimage(src: Sprite2D, gpos: Vector2, flip: float, tint: Color) -> void:
	if src == null or src.texture == null:
		return
	var g: Sprite2D = Sprite2D.new()
	g.texture = src.texture
	g.centered = false
	g.offset = src.offset
	g.scale = Vector2(src.scale.x * flip, src.scale.y)
	g.global_position = gpos
	g.modulate = tint
	g.z_index = 0
	add_child(g)
	var tw: Tween = create_tween()
	tw.tween_property(g, "modulate:a", 0.0, 0.28)
	tw.tween_callback(g.queue_free)


func add_ground(node: Node2D) -> void:
	if ground != null and is_instance_valid(ground):
		ground.add_child(node)
	else:
		add_child(node)


func bolt(from_pos: Vector2, to_pos: Vector2, color: Color = Color(1.0, 0.95, 0.6)) -> void:
	var b = BoltFx.new()
	b.from_p = from_pos
	b.to_p = to_pos
	b.color = color
	add_child(b)


func palm_strike(pos: Vector2, radius_px: float, color: Color, on_land: Callable) -> void:
	## Telegraph ring, golden seal blooms, pillars of light slam down.
	ring(pos, radius_px, color, 0.42, radius_px * 0.9)
	var holder: Node2D = Node2D.new()
	holder.position = pos
	holder.modulate = Color(1, 1, 1, 0.0)
	add_child(holder)
	var spark = SparkFx.new()
	spark.setup(14, radius_px * 0.8, color, 0.5, 5.0)
	holder.add_child(spark)
	var tw: Tween = create_tween()
	tw.tween_property(holder, "modulate:a", 1.0, 0.3)
	tw.tween_callback(on_land)
	tw.tween_callback(_palm_impact.bind(pos, radius_px, color))
	tw.tween_property(holder, "modulate:a", 0.0, 0.25)
	tw.tween_callback(holder.queue_free)


func _palm_impact(pos: Vector2, radius_px: float, color: Color) -> void:
	ring(pos, radius_px * 1.15, color, 0.45)
	ring(pos, radius_px * 0.6, Color(1, 1, 1, 1), 0.3)
	burst(pos, color, 26, 400.0, 0.55, 6.0)
	shake(14.0, 0.3)
	hitstop(0.07)
	Sfx.play("palm")
