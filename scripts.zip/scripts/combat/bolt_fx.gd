extends Node2D
## Jagged lightning bolt between two points; fades quickly.

var from_p: Vector2 = Vector2.ZERO
var to_p: Vector2 = Vector2(100, 0)
var color: Color = Color(1.0, 0.95, 0.6, 1.0)
var life: float = 0.22
var t: float = 0.0
var pts: PackedVector2Array = PackedVector2Array()


func _ready() -> void:
	var seg: int = 9
	var dir: Vector2 = to_p - from_p
	var nrm: Vector2 = Vector2(-dir.y, dir.x).normalized()
	for i in range(seg + 1):
		var k: float = float(i) / float(seg)
		var p: Vector2 = from_p.lerp(to_p, k)
		if i > 0 and i < seg:
			p += nrm * randf_range(-26.0, 26.0)
		pts.append(p)


func _process(delta: float) -> void:
	t += delta
	if t >= life:
		queue_free()
		return
	queue_redraw()


func _draw() -> void:
	var a: float = 1.0 - t / life
	if pts.size() < 2:
		return
	draw_polyline(pts, Color(color.r, color.g, color.b, 0.35 * a), 12.0, true)
	draw_polyline(pts, Color(color.r, color.g, color.b, 0.9 * a), 5.0, true)
	draw_polyline(pts, Color(1, 1, 1, a), 2.0, true)
