extends Node2D
## Golden bell shield dome drawn around the player (procedural - no sprite needed).

var ratio: float = 1.0
var t: float = 0.0
var radius: float = 110.0


func _process(delta: float) -> void:
	t += delta
	queue_redraw()


func _draw() -> void:
	var a: float = 0.28 + 0.1 * sin(t * 6.0)
	var col: Color = Color(1.0, 0.85, 0.35, 1.0)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 1.0))
	draw_circle(Vector2.ZERO, radius, Color(col.r, col.g, col.b, a * 0.35 * ratio + 0.04))
	draw_arc(Vector2.ZERO, radius, 0.0, TAU, 48, Color(col.r, col.g, col.b, 0.5 + 0.4 * ratio), 4.0, true)
	draw_arc(Vector2.ZERO, radius * 0.82, 0.0, TAU, 40, Color(1, 1, 0.8, 0.22 * ratio), 2.0, true)
	for i in range(6):
		var ang: float = t * 0.8 + TAU * float(i) / 6.0
		var p1: Vector2 = Vector2(cos(ang), sin(ang)) * radius * 0.82
		var p2: Vector2 = Vector2(cos(ang + 0.5), sin(ang + 0.5)) * radius
		draw_line(p1, p2, Color(1, 0.95, 0.6, 0.35 * ratio), 2.0)
