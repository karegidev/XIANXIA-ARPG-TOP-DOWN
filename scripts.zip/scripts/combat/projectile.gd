extends Node2D
## Projectile - fireball / water orb ("ball" mode) and homing flying swords ("sword" mode).

var cfg: Dictionary = {}
var vel: Vector2 = Vector2.ZERO
var t: float = 0.0
var mode: String = "ball"
var delay: float = 0.0
var target: Node2D = null
var hits_left: int = 1
var hit_set: Dictionary = {}
var sprite: Sprite2D = null
var glow: Sprite2D = null
var trail_t: float = 0.0
var dying: bool = false
var col: Color = Color.WHITE


func setup(c: Dictionary) -> void:
	cfg = c
	mode = String(c.get("mode", "ball"))
	var d: Vector2 = c.get("dir", Vector2.RIGHT)
	vel = d.normalized() * float(c.get("speed", 600.0))
	delay = float(c.get("delay", 0.0))
	hits_left = int(c.get("max_hits", 1))
	col = c.get("color", Color.WHITE)


func _ready() -> void:
	sprite = GameData.make_sprite(String(cfg.get("sprite", "fx_fireball")))
	var info: Dictionary = GameData.sprite_info(String(cfg.get("sprite", "fx_fireball")))
	var a: Array = info.get("anchor", [0, 0])
	sprite.offset = Vector2(-float(a[0]), -float(a[1]))
	add_child(sprite)
	if mode == "arrow":
		if sprite.texture != null:
			sprite.offset = -sprite.texture.get_size() * 0.5
		rotation = vel.angle()
		GameState.world.fx.ring(global_position, GameData.m(0.5), col, 0.15, 3.0)
		return
	glow = GameData.make_sprite(String(cfg.get("sprite", "fx_fireball")))
	glow.offset = sprite.offset
	glow.scale = sprite.scale * 1.5
	var mat: CanvasItemMaterial = CanvasItemMaterial.new()
	mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	glow.material = mat
	glow.modulate = Color(col.r, col.g, col.b, 0.45)
	add_child(glow)
	move_child(glow, 0)
	rotation = 0.0
	if mode == "sword":
		rotation = vel.angle()
		sprite.scale *= 1.15
		glow.scale = sprite.scale * 1.35
	GameState.world.fx.ring(global_position, GameData.m(0.9), col, 0.25, 4.0)


func _center(e: Node2D) -> Vector2:
	return e.global_position + Vector2(0, -float(e.height_px) * 0.4)


func _process(delta: float) -> void:
	t += delta
	if dying:
		return
	if t > float(cfg.get("life", 2.0)):
		_fade()
		return
	if mode == "sword":
		_update_sword(delta)
	elif mode == "arrow":
		position += vel * delta
	else:
		position += vel * delta
		sprite.rotation += delta * 9.0
		_trail(delta)
	_check_hits()


func _trail(delta: float) -> void:
	trail_t -= delta
	if trail_t <= 0.0:
		trail_t = 0.045
		GameState.world.fx.burst(global_position, col, 2, 70.0, 0.3, 4.5)


func _update_sword(delta: float) -> void:
	if t < delay:
		position += vel.normalized() * 60.0 * delta
		rotation = vel.angle()
		return
	if target == null or not is_instance_valid(target) or target.state == "dead":
		target = _pick_target()
	var spd: float = float(cfg.get("speed", 900.0))
	if target != null:
		var want: Vector2 = (_center(target) - global_position).normalized() * spd
		vel = vel.lerp(want, clampf(delta * 11.0, 0.0, 1.0))
	else:
		vel = vel.normalized() * spd
	position += vel * delta
	rotation = vel.angle()
	trail_t -= delta
	if trail_t <= 0.0:
		trail_t = 0.03
		GameState.world.fx.burst(global_position, col, 1, 40.0, 0.25, 3.5)


func _pick_target() -> Node2D:
	var best: Node2D = null
	var bd: float = GameData.m(14.0)
	for e in get_tree().get_nodes_in_group("enemies"):
		if not is_instance_valid(e) or e.state == "dead" or hit_set.has(e.get_instance_id()):
			continue
		var d: float = global_position.distance_to(e.global_position)
		if d < bd:
			bd = d
			best = e
	return best


func _check_hits() -> void:
	if mode == "sword" and t < delay:
		return
	var hr: float = float(cfg.get("hit_r", 30.0))
	for e in get_tree().get_nodes_in_group("enemies"):
		if not is_instance_valid(e) or e.state == "dead":
			continue
		var id: int = e.get_instance_id()
		if hit_set.has(id):
			continue
		if _center(e).distance_to(global_position) > hr + float(e.radius_px) * 1.1:
			continue
		hit_set[id] = true
		_on_hit(e)
		if dying:
			return


func _on_hit(e: Node2D) -> void:
	var fx: Node2D = GameState.world.fx
	var dmg: float = float(cfg.get("damage", 10.0)) * randf_range(0.92, 1.08)
	var crit: bool = randf() < 0.12
	if crit:
		dmg *= 1.7
	var kind: String = String(cfg.get("kind", "skill"))
	var chain_n: int = int(cfg.get("chain", 0))
	if chain_n > 0:
		_chain(e, dmg, chain_n)
		_fade()
		return
	var explode: float = float(cfg.get("explode", 0.0))
	if explode > 0.0:
		var hit_list: Array = GameState.world.aoe_damage(e.global_position, explode, dmg, 0.0, 480.0, kind)
		var burn: float = float(cfg.get("burn", 0.0))
		if burn > 0.0:
			for h in hit_list:
				if is_instance_valid(h):
					h.apply_status("burn", burn, dmg * 0.12)
		fx.ring(e.global_position, explode, col, 0.4)
		fx.burst(global_position, col, 20, 360.0, 0.5, 6.0)
		fx.shake(7.0, 0.2)
		fx.hitstop(0.05)
		_fade()
		return
	e.take_damage(dmg, global_position - vel.normalized() * 40.0, float(cfg.get("knock", 320.0)), crit, kind)
	Sfx.play("crit" if crit else "hit", 0.7)
	var slow: float = float(cfg.get("slow", 0.0))
	if slow > 0.0:
		e.apply_status("slow", 2.5, slow)
	fx.burst(global_position, col, 8, 240.0, 0.35, 4.5)
	fx.shake(3.0, 0.12)
	hits_left -= 1
	if mode == "sword":
		target = null
		if hits_left <= 0:
			_fade()
	elif not bool(cfg.get("pierce", false)):
		_fade()


func _fade() -> void:
	if dying:
		return
	dying = true
	var tw: Tween = create_tween()
	tw.tween_property(self, "modulate:a", 0.0, 0.15)
	tw.tween_callback(queue_free)


func _chain(first: Node2D, dmg: float, jumps: int) -> void:
	## Thunder orb: strike the first enemy, then leap between nearby foes with falling damage.
	var fx: Node2D = GameState.world.fx
	var range_px: float = GameData.m(float(cfg.get("chain_range", 6.0)))
	var fall: float = float(cfg.get("chain_falloff", 0.8))
	var stun: float = float(cfg.get("stun", 0.0))
	var cur: Node2D = first
	var from_pos: Vector2 = global_position
	var amount: float = dmg
	Sfx.play("thunder", 0.8)
	for i in range(jumps + 1):
		if cur == null or not is_instance_valid(cur) or cur.state == "dead":
			break
		var to_pos: Vector2 = _center(cur)
		fx.bolt(from_pos, to_pos, col)
		hit_set[cur.get_instance_id()] = true
		cur.take_damage(amount, from_pos, 220.0, false, "lightning")
		if stun > 0.0 and is_instance_valid(cur) and cur.state != "dead":
			cur.apply_status("stun", stun, 1.0)
		fx.burst(to_pos, col, 8, 260.0, 0.3, 4.0)
		from_pos = to_pos
		amount *= fall
		var nxt: Node2D = null
		var bd: float = range_px
		for o in get_tree().get_nodes_in_group("enemies"):
			if not is_instance_valid(o) or o.state == "dead" or hit_set.has(o.get_instance_id()):
				continue
			var d: float = _center(o).distance_to(from_pos)
			if d < bd:
				bd = d
				nxt = o
		cur = nxt
	fx.shake(6.0, 0.2)
