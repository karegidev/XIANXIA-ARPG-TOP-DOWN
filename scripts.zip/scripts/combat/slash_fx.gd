extends Node2D
## Crescent sword slash that fades quickly.

var reach: float = 150.0
var arc: float = 2.0          # radians
var life: float = 0.2
var color: Color = Color(0.9, 0.95, 1.0, 1.0)
var t: float = 0.0
var thick: float = 0.45


func _process(delta: float) -> void:
	t += delta
	if t >= life:
		queue_free()
		return
	queue_redraw()


func _draw() -> void:
	var k: float = clampf(t / life, 0.0, 1.0)
	var a: float = 1.0 - k
	var steps: int = 14
	var pts: PackedVector2Array = PackedVector2Array()
	var sweep: float = arc * (0.55 + 0.45 * k)
	for i in range(steps + 1):
		var ang: float = -sweep * 0.5 + sweep * float(i) / float(steps)
		pts.append(Vector2(cos(ang), sin(ang)) * reach)
	for i in range(steps, -1, -1):
		var ang2: float = -sweep * 0.5 + sweep * float(i) / float(steps)
		var inner: float = reach * (1.0 - thick * (1.0 - 0.6 * k))
		pts.append(Vector2(cos(ang2), sin(ang2)) * inner)
	draw_colored_polygon(pts, Color(color.r, color.g, color.b, 0.85 * a))
