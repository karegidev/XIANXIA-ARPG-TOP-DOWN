extends Node2D
## A burst of small particles drawn from a single node (cheap on mobile).

var parts: Array = []
var color: Color = Color(1, 0.8, 0.4, 1)
var gravity: float = 0.0


func setup(count: int, speed: float, col: Color, life: float = 0.45, size: float = 4.0) -> void:
	color = col
	for i in range(count):
		var ang: float = randf() * TAU
		var sp: float = speed * (0.35 + randf() * 0.65)
		parts.append({
			"p": Vector2.ZERO,
			"v": Vector2(cos(ang), sin(ang)) * sp,
			"t": 0.0,
			"l": life * (0.6 + randf() * 0.5),
			"s": size * (0.6 + randf() * 0.8),
		})


func _process(delta: float) -> void:
	var alive: int = 0
	for p in parts:
		p["t"] += delta
		if p["t"] < p["l"]:
			alive += 1
			p["p"] += p["v"] * delta
			p["v"] *= 0.94
			p["v"].y += gravity * delta
	if alive == 0:
		queue_free()
		return
	queue_redraw()


func _draw() -> void:
	for p in parts:
		if p["t"] >= p["l"]:
			continue
		var k: float = p["t"] / p["l"]
		draw_circle(p["p"], p["s"] * (1.0 - k * 0.6), Color(color.r, color.g, color.b, 1.0 - k))
