extends Node2D
## Ground warning shape shown before an enemy attack. mode: circle | cone | line

var mode: String = "circle"
var radius: float = 100.0
var arc: float = 2.0
var angle: float = 0.0
var length: float = 300.0
var width: float = 80.0
var progress: float = 0.0
var color: Color = Color(1.0, 0.25, 0.2, 1.0)


func set_progress(p: float) -> void:
	progress = clampf(p, 0.0, 1.0)
	queue_redraw()


func _draw() -> void:
	var a_out: float = 0.55
	var a_fill: float = 0.12 + 0.30 * progress
	var fc: Color = Color(color.r, color.g, color.b, a_fill)
	var oc: Color = Color(color.r, color.g, color.b, a_out)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.8))
	if mode == "circle":
		draw_circle(Vector2.ZERO, radius, Color(fc.r, fc.g, fc.b, 0.10))
		draw_circle(Vector2.ZERO, radius * progress, fc)
		draw_arc(Vector2.ZERO, radius, 0.0, TAU, 40, oc, 3.0, true)
	elif mode == "cone":
		var pts: PackedVector2Array = PackedVector2Array([Vector2.ZERO])
		var n: int = 14
		for i in range(n + 1):
			var ang: float = angle - arc * 0.5 + arc * float(i) / float(n)
			pts.append(Vector2(cos(ang), sin(ang)) * radius)
		draw_colored_polygon(pts, Color(fc.r, fc.g, fc.b, 0.10))
		var pts2: PackedVector2Array = PackedVector2Array([Vector2.ZERO])
		for i in range(n + 1):
			var ang2: float = angle - arc * 0.5 + arc * float(i) / float(n)
			pts2.append(Vector2(cos(ang2), sin(ang2)) * radius * maxf(progress, 0.02))
		draw_colored_polygon(pts2, fc)
		draw_arc(Vector2.ZERO, radius, angle - arc * 0.5, angle + arc * 0.5, 20, oc, 3.0, true)
	else:
		var dir: Vector2 = Vector2(cos(angle), sin(angle))
		var side: Vector2 = Vector2(-dir.y, dir.x) * width * 0.5
		var tip: Vector2 = dir * length
		draw_colored_polygon(PackedVector2Array([-side, side, tip + side, tip - side]), Color(fc.r, fc.g, fc.b, 0.10))
		var tip2: Vector2 = dir * length * maxf(progress, 0.02)
		draw_colored_polygon(PackedVector2Array([-side, side, tip2 + side, tip2 - side]), fc)
		draw_line(-side, tip - side, oc, 3.0)
		draw_line(side, tip + side, oc, 3.0)
