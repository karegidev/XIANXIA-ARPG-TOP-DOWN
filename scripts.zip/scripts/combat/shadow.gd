extends Node2D
## Soft elliptical ground shadow.

var radius: float = 24.0
var alpha: float = 0.32


func _draw() -> void:
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.38))
	draw_circle(Vector2.ZERO, radius, Color(0, 0, 0, alpha))
	draw_circle(Vector2.ZERO, radius * 0.7, Color(0, 0, 0, alpha * 0.8))


func set_radius(r: float) -> void:
	radius = r
	queue_redraw()
