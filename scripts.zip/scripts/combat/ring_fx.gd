extends Node2D
## Expanding ring / shockwave.

var r0: float = 10.0
var r1: float = 120.0
var life: float = 0.4
var color: Color = Color(1, 1, 1, 1)
var width: float = 6.0
var fill: bool = true
var t: float = 0.0


func _process(delta: float) -> void:
	t += delta
	if t >= life:
		queue_free()
		return
	queue_redraw()


func _draw() -> void:
	var k: float = clampf(t / life, 0.0, 1.0)
	var r: float = lerpf(r0, r1, 1.0 - pow(1.0 - k, 2.5))
	var a: float = 1.0 - k
	draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, 0.75))
	if fill:
		draw_circle(Vector2.ZERO, r, Color(color.r, color.g, color.b, 0.18 * a))
	draw_arc(Vector2.ZERO, r, 0.0, TAU, 48, Color(color.r, color.g, color.b, a), maxf(1.0, width * a + 1.0), true)
