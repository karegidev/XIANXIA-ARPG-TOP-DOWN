extends Node
## GameData - loads every data-driven definition (sprites, items, weapons, recipes, props, enemies, npcs ...).
## To expand the game, edit the JSON files in res://data/ - no code changes are needed for most content.

const FLASH_SHADER: Shader = preload("res://shaders/flash.gdshader")

var ppm: float = 64.0                   # game pixels per metre (world scale)
var sprites: Dictionary = {}
var tiles: Dictionary = {}
var realms: Array = []
var skills: Dictionary = {}
var skill_order: Array = []
var enemies: Dictionary = {}
var npcs: Dictionary = {}
var items: Dictionary = {}
var weapons: Dictionary = {}
var recipes: Array = []
var guide: Array = []
var props: Dictionary = {}
var stations: Dictionary = {}
var quests: Dictionary = {}
var world: Dictionary = {}

var _tex_cache: Dictionary = {}
var _icon_cache: Dictionary = {}


func _ready() -> void:
	var s: Variant = _load_json("res://data/sprites.json")
	if typeof(s) == TYPE_DICTIONARY:
		ppm = float(s.get("ppm", 64.0))
		sprites = s.get("sprites", {})
	tiles = _dict("res://data/tiles.json")
	var r: Variant = _load_json("res://data/realms.json")
	if typeof(r) == TYPE_ARRAY:
		realms = r
	var sk: Variant = _load_json("res://data/skills.json")
	if typeof(sk) == TYPE_DICTIONARY:
		skills = sk.get("skills", {})
		skill_order = sk.get("order", [])
	var rc: Variant = _load_json("res://data/recipes.json")
	if typeof(rc) == TYPE_ARRAY:
		recipes = rc
	var gd: Variant = _load_json("res://data/guide.json")
	if typeof(gd) == TYPE_ARRAY:
		guide = gd
	enemies = _dict("res://data/enemies.json")
	npcs = _dict("res://data/npcs.json")
	items = _dict("res://data/items.json")
	weapons = _dict("res://data/weapons.json")
	props = _dict("res://data/props.json")
	stations = _dict("res://data/stations.json")
	quests = _dict("res://data/quests.json")
	world = _dict("res://data/world.json")


func _dict(path: String) -> Dictionary:
	var v: Variant = _load_json(path)
	if typeof(v) == TYPE_DICTIONARY:
		return v
	return {}


func _load_json(path: String) -> Variant:
	if not FileAccess.file_exists(path):
		push_error("GameData: missing data file " + path)
		return null
	var f: FileAccess = FileAccess.open(path, FileAccess.READ)
	if f == null:
		push_error("GameData: cannot open " + path)
		return null
	var txt: String = f.get_as_text()
	f.close()
	var parsed: Variant = JSON.parse_string(txt)
	if parsed == null:
		push_error("GameData: JSON parse error in " + path)
	return parsed


func m(metres: float) -> float:
	## metres -> game pixels
	return metres * ppm


func tex(id: String) -> Texture2D:
	if _tex_cache.has(id):
		return _tex_cache[id]
	var info: Dictionary = sprites.get(id, {})
	if info.is_empty():
		push_warning("GameData: unknown sprite id " + id)
		return null
	var t: Texture2D = load(String(info["file"]))
	_tex_cache[id] = t
	return t


func icon(id: String) -> Texture2D:
	## 96px UI icon (items, coins, skills, stations). Returns null when no icon exists.
	if _icon_cache.has(id):
		return _icon_cache[id]
	var path: String = "res://assets/icons/" + id + ".png"
	var t: Texture2D = null
	if ResourceLoader.exists(path):
		t = load(path)
	_icon_cache[id] = t
	return t


func item_icon(item_id: String) -> Texture2D:
	var d: Dictionary = items.get(item_id, {})
	return icon(String(d.get("icon", item_id)))


func item_name(item_id: String) -> String:
	return String(items.get(item_id, {}).get("name", item_id))


func sprite_info(id: String) -> Dictionary:
	return sprites.get(id, {})


func make_sprite(id: String) -> Sprite2D:
	## Returns a Sprite2D whose origin is the ground anchor (feet) and whose scale gives true real-world size.
	var sp: Sprite2D = Sprite2D.new()
	var info: Dictionary = sprites.get(id, {})
	if info.is_empty():
		return sp
	sp.texture = tex(id)
	sp.centered = false
	var a: Array = info.get("anchor", [0, 0])
	sp.offset = Vector2(-float(a[0]), -float(a[1]))
	var sc: float = float(info.get("scale", 0.5))
	sp.scale = Vector2(sc, sc)
	return sp


func make_flash_material() -> ShaderMaterial:
	var mat: ShaderMaterial = ShaderMaterial.new()
	mat.shader = FLASH_SHADER
	return mat


func sprite_height_px(id: String) -> float:
	var info: Dictionary = sprites.get(id, {})
	if info.is_empty():
		return 100.0
	var a: Array = info.get("anchor", [0, 0])
	return float(a[1]) * float(info.get("scale", 0.5))


func realm_def(index: int) -> Dictionary:
	if realms.is_empty():
		return {}
	return realms[clampi(index, 0, realms.size() - 1)]


func tile_color(tile_id: String) -> Color:
	var c: Array = tiles.get("colors", {}).get(tile_id, [0.5, 0.7, 0.4])
	return Color(float(c[0]), float(c[1]), float(c[2]), 1.0)


func recipes_for(station_type: String) -> Array:
	var out: Array = []
	for r in recipes:
		if String(r.get("station", "")) == station_type:
			out.append(r)
	return out
