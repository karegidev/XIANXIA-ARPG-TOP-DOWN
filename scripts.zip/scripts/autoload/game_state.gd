extends Node
## GameState - progression, inventory, equipment, buffs, crafting, shopping, quests, settings and save/load.

signal stats_changed
signal inventory_changed
signal quests_changed
signal equipment_changed
signal realm_changed(index: int)
signal message(text: String, color: Color)

const SAVE_PATH: String = "user://azure_ascension_save_v2.json"
const MAX_STAGE: int = 9
const SAVE_VERSION: int = 2

# --- runtime references (set by World) ---
var world: Node = null
var player: Node = null

# --- cultivation ---
var realm: int = 0
var stage: int = 1
var xp: float = 0.0
var stones: int = 5
var coins: int = 300                 # copper units (100 copper = 1 silver, 100 silver = 1 gold, 100 gold = 1 platinum)

# --- vitals ---
var hp: float = 120.0
var qi: float = 100.0
var stamina: float = 100.0

# --- progress ---
var inventory: Dictionary = {}       # item id -> count
var equipped_weapon: String = "sword"
var equipped_trinket: String = ""
var buffs: Dictionary = {}           # buff id -> {name, atk, speed, regen, t}
var hot_rate: float = 0.0            # heal-over-time (hp per second)
var hot_t: float = 0.0
var active_quests: Dictionary = {}   # quest id -> kill progress (int)
var done_quests: Array = []
var kills: Dictionary = {}           # enemy id -> count
var opened_chests: Array = []
var gathered: int = 0
var bt_notified: bool = false
var crafted: int = 0
var play_time: float = 0.0
var saved_pos: Vector2 = Vector2.ZERO
var has_saved_pos: bool = false
var time_of_day: float = 0.3         # 0..1

var settings: Dictionary = {
	"ctrl_scale": 1.0,
	"ctrl_opacity": 0.75,
	"vibration": true,
	"damage_numbers": true,
	"show_fps": false,
	"cam_zoom": 1.2,
	"shake": 1.0,
	"auto_aim": true,
	"left_handed": false,
	"sfx": 0.8,
}


func _ready() -> void:
	load_settings_only()
	reset_new_game()


func _process(delta: float) -> void:
	play_time += delta
	if not buffs.is_empty():
		var expired: Array = []
		for k in buffs.keys():
			buffs[k]["t"] = float(buffs[k]["t"]) - delta
			if float(buffs[k]["t"]) <= 0.0:
				expired.append(k)
		for k in expired:
			buffs.erase(k)
	if hot_t > 0.0:
		hot_t -= delta
		hp = minf(max_hp(), hp + hot_rate * delta)


# ------------------------------------------------------------------ stats
func realm_def() -> Dictionary:
	return GameData.realm_def(realm)


func stage_mult() -> float:
	return 1.0 + 0.07 * float(stage - 1)


func buff_mult(key: String) -> float:
	var m: float = 1.0
	for k in buffs.keys():
		m *= float(buffs[k].get(key, 1.0))
	return m


func trinket_def() -> Dictionary:
	if equipped_trinket == "":
		return {}
	return GameData.items.get(equipped_trinket, {})


func weapon_def() -> Dictionary:
	return GameData.weapons.get(equipped_weapon, GameData.weapons.get("sword", {}))


func max_hp() -> float:
	return float(realm_def().get("hp", 100)) * stage_mult()


func max_qi() -> float:
	return float(realm_def().get("qi", 100)) * stage_mult() * float(trinket_def().get("max_qi_mult", 1.0))


func max_stamina() -> float:
	return float(realm_def().get("stamina", 100))


func attack_power() -> float:
	return float(realm_def().get("atk", 10)) * stage_mult() * buff_mult("atk")


func move_speed_m() -> float:
	return float(realm_def().get("speed", 5.4)) * buff_mult("speed")


func qi_regen() -> float:
	var r: float = float(realm_def().get("qi_regen", 6)) + float(trinket_def().get("qi_regen", 0.0))
	for k in buffs.keys():
		r += float(buffs[k].get("regen", 0.0))
	return r


func damage_reduction() -> float:
	return minf(0.55, float(realm) * 0.07 + float(stage - 1) * 0.008)


func xp_needed() -> float:
	var d: Dictionary = realm_def()
	return float(d.get("stage_xp", 60)) * pow(float(d.get("stage_growth", 1.35)), float(stage - 1))


func realm_name() -> String:
	return String(realm_def().get("name", "?"))


func mount_unlocked() -> bool:
	return realm >= 1


func can_breakthrough() -> bool:
	return realm < GameData.realms.size() - 1 and stage >= MAX_STAGE and xp >= xp_needed()


func breakthrough_cost() -> int:
	if realm >= GameData.realms.size() - 1:
		return 0
	return int(GameData.realm_def(realm + 1).get("break_cost", 0))


func try_breakthrough() -> bool:
	if not can_breakthrough():
		say("Your cultivation is not yet complete.", Color(1, 0.7, 0.5))
		return false
	var cost: int = breakthrough_cost()
	if stones < cost:
		say("Need %d spirit stones to break through." % cost, Color(1, 0.7, 0.5))
		return false
	stones -= cost
	realm += 1
	stage = 1
	xp = 0.0
	bt_notified = false
	hp = max_hp()
	qi = max_qi()
	stamina = max_stamina()
	say("BREAKTHROUGH! You reach the %s realm!" % realm_name(), Color(1, 0.9, 0.4))
	if realm == 1:
		say("Sword flight unlocked! Tap FLY to ride your flying sword over water.", Color(0.7, 0.95, 1.0))
	realm_changed.emit(realm)
	stats_changed.emit()
	return true


func add_xp(amount: float) -> void:
	xp += amount
	var leveled: bool = false
	while stage < MAX_STAGE and xp >= xp_needed():
		xp -= xp_needed()
		stage += 1
		leveled = true
		hp = max_hp()
		qi = max_qi()
	if stage >= MAX_STAGE:
		xp = minf(xp, xp_needed())
	if can_breakthrough() and not bt_notified:
		bt_notified = true
		say("Cultivation complete! Open MENU > Status > BREAKTHROUGH (cost %d spirit stones)." % breakthrough_cost(), Color(1, 0.9, 0.4))
		Sfx.play("quest")
	if leveled:
		say("Cultivation advanced to stage %d!" % stage, Color(0.6, 1, 0.8))
		if stage >= MAX_STAGE and realm < GameData.realms.size() - 1:
			say("Peak reached - open Status to attempt a Breakthrough.", Color(1, 0.9, 0.5))
	stats_changed.emit()


func add_stones(n: int) -> void:
	stones += n
	stats_changed.emit()


func say(text: String, color: Color = Color.WHITE) -> void:
	message.emit(text, color)


# ------------------------------------------------------------------ coins
func add_coins(n: int) -> void:
	coins += n
	stats_changed.emit()


func spend_coins(n: int) -> bool:
	if coins < n:
		return false
	coins -= n
	stats_changed.emit()
	return true


func format_coins(n: int) -> String:
	var plat: int = n / 1000000
	var gold: int = (n / 10000) % 100
	var silver: int = (n / 100) % 100
	var copper: int = n % 100
	var parts: Array = []
	if plat > 0:
		parts.append("%dp" % plat)
	if gold > 0:
		parts.append("%dg" % gold)
	if silver > 0:
		parts.append("%ds" % silver)
	if copper > 0 or parts.is_empty():
		parts.append("%dc" % copper)
	while parts.size() > 3:
		parts.pop_back()
	return " ".join(parts)


# ------------------------------------------------------------------ items
func add_item(id: String, n: int = 1) -> void:
	inventory[id] = int(inventory.get(id, 0)) + n
	inventory_changed.emit()


func item_count(id: String) -> int:
	return int(inventory.get(id, 0))


func remove_item(id: String, n: int = 1) -> bool:
	if item_count(id) < n:
		return false
	inventory[id] = item_count(id) - n
	if int(inventory[id]) <= 0:
		inventory.erase(id)
	inventory_changed.emit()
	return true


func has_items(req: Dictionary) -> bool:
	for k in req.keys():
		if item_count(String(k)) < int(req[k]):
			return false
	return true


func take_items(req: Dictionary) -> void:
	for k in req.keys():
		remove_item(String(k), int(req[k]))


func has_tool(kind: String) -> bool:
	for k in inventory.keys():
		var d: Dictionary = GameData.items.get(k, {})
		if String(d.get("tool", "")) == kind:
			return true
	return false


func use_item(id: String) -> bool:
	if item_count(id) <= 0:
		return false
	var def: Dictionary = GameData.items.get(id, {})
	if def.is_empty():
		return false
	var typ: String = String(def.get("type", ""))
	if typ == "weapon" or typ == "trinket":
		equip_item(id)
		return true
	if typ != "consumable":
		return false
	var used: bool = false
	if def.has("hp") and hp < max_hp():
		hp = minf(max_hp(), hp + float(def["hp"]))
		used = true
	if def.has("qi") and qi < max_qi():
		qi = minf(max_qi(), qi + float(def["qi"]))
		used = true
	if def.has("xp"):
		add_xp(float(def["xp"]))
		used = true
	if def.has("stones"):
		add_stones(int(def["stones"]))
		used = true
	if def.has("hot"):
		hot_rate = float(def["hot"]["amount"]) / maxf(float(def["hot"]["dur"]), 0.1)
		hot_t = float(def["hot"]["dur"])
		used = true
	if def.has("buff"):
		var b: Dictionary = def["buff"]
		buffs[String(b.get("id", "buff"))] = {"name": String(b.get("name", "Buff")), "atk": float(b.get("atk", 1.0)), "speed": float(b.get("speed", 1.0)), "regen": float(b.get("regen", 0.0)), "t": float(b.get("dur", 60.0)), "icon": id}
		used = true
	if not used:
		say("No need to use that right now.", Color(0.8, 0.8, 0.8))
		return false
	remove_item(id, 1)
	say("Used " + String(def.get("name", id)), Color(0.8, 1, 0.8))
	Sfx.play("eat")
	stats_changed.emit()
	return true


func equip_item(id: String) -> void:
	var def: Dictionary = GameData.items.get(id, {})
	var typ: String = String(def.get("type", ""))
	if item_count(id) <= 0:
		return
	if typ == "weapon":
		equipped_weapon = String(def.get("weapon", id))
		say("Equipped " + String(def.get("name", id)), Color(1, 0.95, 0.7))
	elif typ == "trinket":
		equipped_trinket = id
		hp = minf(hp, max_hp())
		say("Equipped " + String(def.get("name", id)), Color(1, 0.95, 0.7))
	else:
		return
	Sfx.play("equip")
	equipment_changed.emit()
	stats_changed.emit()


func unequip_trinket() -> void:
	equipped_trinket = ""
	qi = minf(qi, max_qi())
	equipment_changed.emit()
	stats_changed.emit()


func is_equipped(id: String) -> bool:
	var def: Dictionary = GameData.items.get(id, {})
	if String(def.get("type", "")) == "weapon":
		return equipped_weapon == String(def.get("weapon", id))
	return equipped_trinket == id


func buy_item(id: String, price_override: int = -1) -> bool:
	var def: Dictionary = GameData.items.get(id, {})
	var price: int = int(def.get("price", 0)) if price_override < 0 else price_override
	if price <= 0 or coins < price:
		say("Not enough coin.", Color(1, 0.6, 0.5))
		return false
	coins -= price
	add_item(id, 1)
	Sfx.play("coin")
	stats_changed.emit()
	return true


func sell_item(id: String, n: int = 1) -> bool:
	var def: Dictionary = GameData.items.get(id, {})
	var value: int = int(def.get("sell", 0))
	if value <= 0 or item_count(id) < n:
		return false
	if is_equipped(id) and item_count(id) <= n:
		say("Unequip it first.", Color(1, 0.7, 0.5))
		return false
	remove_item(id, n)
	coins += value * n
	Sfx.play("coin")
	stats_changed.emit()
	return true


func can_craft(r: Dictionary) -> bool:
	if not has_items(r.get("inputs", {})):
		return false
	if coins < int(r.get("coins", 0)) or stones < int(r.get("stones", 0)):
		return false
	return true


func craft(r: Dictionary) -> bool:
	if not can_craft(r):
		say("Missing materials.", Color(1, 0.7, 0.5))
		return false
	take_items(r.get("inputs", {}))
	coins -= int(r.get("coins", 0))
	stones -= int(r.get("stones", 0))
	var outs: Dictionary = r.get("outputs", {})
	for k in outs.keys():
		add_item(String(k), int(outs[k]))
	var back: Dictionary = r.get("returns", {})
	for k in back.keys():
		add_item(String(k), int(back[k]))
	crafted += 1
	add_xp(3.0 + float(r.get("stones", 0)))
	say("Crafted " + String(r.get("name", "item")), Color(0.8, 1, 0.85))
	Sfx.play("craft")
	stats_changed.emit()
	return true


# ------------------------------------------------------------------ quests
func quest_available(qid: String) -> bool:
	var q: Dictionary = GameData.quests.get(qid, {})
	if q.is_empty() or done_quests.has(qid) or active_quests.has(qid):
		return false
	var after: String = String(q.get("after", ""))
	return after == "" or done_quests.has(after)


func quest_progress(qid: String) -> int:
	var q: Dictionary = GameData.quests.get(qid, {})
	if q.is_empty() or not active_quests.has(qid):
		return 0
	var need: int = int(q.get("count", 1))
	if String(q.get("kind", "")) == "collect":
		return mini(item_count(String(q.get("target", ""))), need)
	return mini(int(active_quests[qid]), need)


func quest_ready(qid: String) -> bool:
	if not active_quests.has(qid):
		return false
	return quest_progress(qid) >= int(GameData.quests[qid].get("count", 1))


func accept_quest(qid: String) -> void:
	if quest_available(qid):
		active_quests[qid] = 0
		say("Quest accepted: " + String(GameData.quests[qid]["name"]), Color(1, 0.9, 0.5))
		quests_changed.emit()


func complete_quest(qid: String) -> void:
	if not quest_ready(qid):
		return
	var q: Dictionary = GameData.quests[qid]
	if String(q.get("kind", "")) == "collect":
		remove_item(String(q.get("target", "")), int(q.get("count", 1)))
	var r: Dictionary = q.get("reward", {})
	active_quests.erase(qid)
	done_quests.append(qid)
	add_coins(int(r.get("coins", 0)))
	add_stones(int(r.get("stones", 0)))
	var items: Dictionary = r.get("items", {})
	for k in items.keys():
		add_item(String(k), int(items[k]))
	add_xp(float(r.get("xp", 0)))
	say("Quest complete: %s" % String(q["name"]), Color(0.7, 1, 0.7))
	Sfx.play("quest")
	quests_changed.emit()


func register_kill(enemy_id: String, tag: String) -> void:
	kills[enemy_id] = int(kills.get(enemy_id, 0)) + 1
	var changed: bool = false
	for qid in active_quests.keys():
		var q: Dictionary = GameData.quests.get(qid, {})
		if String(q.get("kind", "")) != "kill":
			continue
		var target: String = String(q.get("target", ""))
		if target == enemy_id or target == tag:
			var need: int = int(q.get("count", 1))
			if int(active_quests[qid]) < need:
				active_quests[qid] = int(active_quests[qid]) + 1
				changed = true
				if int(active_quests[qid]) >= need:
					say("Quest objective complete: " + String(q["name"]), Color(1, 0.9, 0.5))
	if changed:
		quests_changed.emit()


# ------------------------------------------------------------------ save / load
func reset_new_game() -> void:
	realm = 0
	stage = 1
	xp = 0.0
	stones = 5
	coins = 300
	inventory = {"sword": 1, "axe": 1, "pickaxe": 1, "empty_bucket": 1, "healing_pill": 3, "qi_pill": 1, "bread": 2}
	equipped_weapon = "sword"
	equipped_trinket = ""
	buffs = {}
	hot_rate = 0.0
	hot_t = 0.0
	active_quests = {}
	done_quests = []
	kills = {}
	opened_chests = []
	gathered = 0
	crafted = 0
	bt_notified = false
	play_time = 0.0
	has_saved_pos = false
	time_of_day = 0.3
	hp = max_hp()
	qi = max_qi()
	stamina = max_stamina()
	stats_changed.emit()
	inventory_changed.emit()
	quests_changed.emit()
	equipment_changed.emit()


func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)


func save_game() -> bool:
	var data: Dictionary = {
		"v": SAVE_VERSION, "realm": realm, "stage": stage, "xp": xp, "stones": stones, "coins": coins,
		"hp": hp, "qi": qi, "stamina": stamina,
		"inventory": inventory, "equipped_weapon": equipped_weapon, "equipped_trinket": equipped_trinket,
		"active_quests": active_quests, "done_quests": done_quests, "kills": kills,
		"opened_chests": opened_chests, "gathered": gathered, "crafted": crafted,
		"play_time": play_time, "time_of_day": time_of_day, "settings": settings,
	}
	if player != null and is_instance_valid(player):
		data["pos"] = [player.global_position.x, player.global_position.y]
	var f: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f == null:
		return false
	f.store_string(JSON.stringify(data))
	f.close()
	return true


func load_game() -> bool:
	if not has_save():
		return false
	var f: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return false
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(parsed) != TYPE_DICTIONARY:
		return false
	var d: Dictionary = parsed
	if int(d.get("v", 1)) < SAVE_VERSION:
		return false          # saves from the previous asset generation are not compatible
	realm = clampi(int(d.get("realm", 0)), 0, maxi(0, GameData.realms.size() - 1))
	stage = clampi(int(d.get("stage", 1)), 1, MAX_STAGE)
	xp = float(d.get("xp", 0.0))
	stones = int(d.get("stones", 0))
	coins = int(d.get("coins", 0))
	inventory = _int_dict(d.get("inventory", {}))
	equipped_weapon = String(d.get("equipped_weapon", "sword"))
	equipped_trinket = String(d.get("equipped_trinket", ""))
	active_quests = _int_dict(d.get("active_quests", {}))
	done_quests = d.get("done_quests", [])
	kills = _int_dict(d.get("kills", {}))
	opened_chests = d.get("opened_chests", [])
	gathered = int(d.get("gathered", 0))
	crafted = int(d.get("crafted", 0))
	play_time = float(d.get("play_time", 0.0))
	time_of_day = float(d.get("time_of_day", 0.3))
	buffs = {}
	hot_t = 0.0
	bt_notified = can_breakthrough()
	hp = clampf(float(d.get("hp", max_hp())), 1.0, max_hp())
	qi = clampf(float(d.get("qi", max_qi())), 0.0, max_qi())
	stamina = clampf(float(d.get("stamina", max_stamina())), 0.0, max_stamina())
	var s: Variant = d.get("settings", {})
	if typeof(s) == TYPE_DICTIONARY:
		for k in s.keys():
			settings[k] = s[k]
	var p: Variant = d.get("pos", null)
	if typeof(p) == TYPE_ARRAY and p.size() >= 2:
		saved_pos = Vector2(float(p[0]), float(p[1]))
		has_saved_pos = true
	else:
		has_saved_pos = false
	stats_changed.emit()
	inventory_changed.emit()
	quests_changed.emit()
	equipment_changed.emit()
	return true


func _int_dict(v: Variant) -> Dictionary:
	var out: Dictionary = {}
	if typeof(v) == TYPE_DICTIONARY:
		for k in v.keys():
			out[String(k)] = int(v[k])
	return out


func save_settings() -> void:
	var f: FileAccess = FileAccess.open("user://settings.json", FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(settings))
		f.close()


func load_settings_only() -> void:
	if not FileAccess.file_exists("user://settings.json"):
		return
	var f: FileAccess = FileAccess.open("user://settings.json", FileAccess.READ)
	if f == null:
		return
	var parsed: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	if typeof(parsed) == TYPE_DICTIONARY:
		for k in parsed.keys():
			settings[k] = parsed[k]


func vibrate(ms: int) -> void:
	if bool(settings.get("vibration", true)):
		Input.vibrate_handheld(ms)
