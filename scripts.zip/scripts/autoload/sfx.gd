extends Node
## Sfx - procedurally synthesised sound effects (no audio files needed).
## Sfx.play("hit"), Sfx.play("coin", 0.8, 1.1)  -> name, volume 0..1, pitch multiplier.

const RATE: int = 16000
const VOICES: int = 12

var _bank: Dictionary = {}
var _voices: Array = []
var _next: int = 0
var _last: Dictionary = {}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	for i in range(VOICES):
		var p: AudioStreamPlayer = AudioStreamPlayer.new()
		add_child(p)
		_voices.append(p)
	_build()


func play(sound: String, vol: float = 1.0, pitch: float = 1.0) -> void:
	if not _bank.has(sound):
		return
	var master: float = float(GameState.settings.get("sfx", 0.8))
	if master <= 0.01:
		return
	var now: int = Time.get_ticks_msec()
	if _last.has(sound) and now - int(_last[sound]) < 35:
		return
	_last[sound] = now
	var p: AudioStreamPlayer = _voices[_next]
	_next = (_next + 1) % VOICES
	p.stream = _bank[sound]
	p.volume_db = linear_to_db(clampf(vol * master, 0.001, 2.0))
	p.pitch_scale = pitch * randf_range(0.96, 1.04)
	p.play()


# ------------------------------------------------------------------ synthesis
func _wave(dur: float, f0: float, f1: float, vol: float, kind: int, noise: float, decay: float, lp: float = 1.0) -> PackedFloat32Array:
	## kind: 0 sine, 1 square, 2 saw, 3 triangle. noise: 0..1 mix. lp: low-pass amount (1 = none).
	var n: int = maxi(1, int(dur * float(RATE)))
	var arr: PackedFloat32Array = PackedFloat32Array()
	arr.resize(n)
	var phase: float = 0.0
	var filt: float = 0.0
	var env: float = 1.0
	var fac: float = exp(-decay * 2.5 / float(n))     # exponential decay: no pow() per sample
	for i in range(n):
		var t: float = float(i) / float(n)
		var f: float = f0 + (f1 - f0) * t
		phase += TAU * f / float(RATE)
		var s: float = 0.0
		match kind:
			0:
				s = sin(phase)
			1:
				s = 1.0 if sin(phase) >= 0.0 else -1.0
			2:
				s = fposmod(phase / TAU, 1.0) * 2.0 - 1.0
			_:
				s = absf(fposmod(phase / TAU, 1.0) * 4.0 - 2.0) - 1.0
		var r: float = randf() * 2.0 - 1.0
		var v: float = s * (1.0 - noise) + r * noise
		filt += (v - filt) * lp
		env *= fac
		var amp: float = env
		if i < 80:
			amp *= float(i) / 80.0
		arr[i] = filt * amp * vol
	return arr


func _mix(parts: Array) -> PackedFloat32Array:
	## parts: [[PackedFloat32Array, offset_seconds], ...]
	var total: int = 1
	for p in parts:
		var chunk: PackedFloat32Array = p[0]
		total = maxi(total, int(float(p[1]) * float(RATE)) + chunk.size())
	var out: PackedFloat32Array = PackedFloat32Array()
	out.resize(total)
	for p in parts:
		var src: PackedFloat32Array = p[0]
		var off: int = int(float(p[1]) * float(RATE))
		for i in range(src.size()):
			out[off + i] += src[i]
	return out


func _reg(sound: String, samples: PackedFloat32Array) -> void:
	var data: PackedByteArray = PackedByteArray()
	data.resize(samples.size() * 2)
	for i in range(samples.size()):
		var v: int = int(clampf(samples[i], -1.0, 1.0) * 30000.0)
		data.encode_s16(i * 2, v)
	var s: AudioStreamWAV = AudioStreamWAV.new()
	s.format = AudioStreamWAV.FORMAT_16_BITS
	s.mix_rate = RATE
	s.stereo = false
	s.data = data
	_bank[sound] = s


func _notes(freqs: Array, step: float, dur: float, vol: float, kind: int = 0) -> PackedFloat32Array:
	var parts: Array = []
	for i in range(freqs.size()):
		parts.append([_wave(dur, float(freqs[i]), float(freqs[i]), vol, kind, 0.0, 2.2), float(i) * step])
	return _mix(parts)


func _build() -> void:
	_reg("swing", _wave(0.16, 900.0, 260.0, 0.38, 0, 0.92, 1.4, 0.35))
	_reg("hit", _mix([[_wave(0.12, 190.0, 70.0, 0.6, 1, 0.5, 2.6), 0.0], [_wave(0.08, 1200.0, 600.0, 0.18, 0, 0.8, 3.0, 0.5), 0.0]]))
	_reg("crit", _mix([[_wave(0.14, 220.0, 60.0, 0.65, 1, 0.5, 2.4), 0.0], [_wave(0.22, 880.0, 1500.0, 0.3, 3, 0.0, 2.0), 0.0]]))
	_reg("hurt", _wave(0.22, 240.0, 80.0, 0.55, 2, 0.3, 2.0, 0.6))
	_reg("dash", _wave(0.2, 400.0, 1400.0, 0.28, 0, 0.85, 1.3, 0.4))
	_reg("fire", _wave(0.4, 180.0, 520.0, 0.42, 2, 0.75, 1.1, 0.3))
	_reg("water", _mix([[_wave(0.3, 520.0, 260.0, 0.3, 0, 0.35, 1.5), 0.0], [_wave(0.25, 300.0, 700.0, 0.2, 3, 0.3, 1.8), 0.05]]))
	_reg("thunder", _mix([[_wave(0.5, 140.0, 45.0, 0.7, 1, 0.8, 1.7, 0.5), 0.0], [_wave(0.15, 2200.0, 400.0, 0.4, 2, 0.9, 3.0), 0.0]]))
	_reg("bell", _mix([[_wave(0.9, 523.0, 523.0, 0.4, 0, 0.0, 1.6), 0.0], [_wave(0.8, 1060.0, 1060.0, 0.22, 0, 0.0, 1.8), 0.0], [_wave(0.6, 1580.0, 1580.0, 0.14, 0, 0.0, 2.0), 0.0]]))
	_reg("swords", _mix([[_wave(0.25, 1400.0, 2600.0, 0.22, 3, 0.25, 1.6), 0.0], [_wave(0.25, 1700.0, 3000.0, 0.2, 3, 0.25, 1.6), 0.07], [_wave(0.25, 1200.0, 2400.0, 0.2, 3, 0.25, 1.6), 0.14]]))
	_reg("palm", _mix([[_wave(0.55, 100.0, 36.0, 0.85, 0, 0.45, 1.5, 0.6), 0.0], [_wave(0.5, 300.0, 120.0, 0.3, 2, 0.5, 2.0, 0.4), 0.0]]))
	_reg("boom", _wave(0.55, 80.0, 28.0, 0.9, 0, 0.5, 1.6, 0.5))
	_reg("coin", _notes([1318.0, 1760.0], 0.07, 0.18, 0.3, 3))
	_reg("pickup", _wave(0.11, 700.0, 1150.0, 0.3, 0, 0.0, 2.0))
	_reg("chop", _mix([[_wave(0.11, 170.0, 80.0, 0.7, 1, 0.65, 3.2), 0.0], [_wave(0.07, 900.0, 400.0, 0.2, 2, 0.8, 4.0), 0.0]]))
	_reg("mine", _mix([[_wave(0.09, 1500.0, 900.0, 0.45, 1, 0.4, 4.0), 0.0], [_wave(0.12, 210.0, 90.0, 0.45, 1, 0.6, 3.0), 0.0]]))
	_reg("pick", _wave(0.12, 520.0, 780.0, 0.3, 3, 0.25, 2.0))
	_reg("eat", _mix([[_wave(0.1, 320.0, 200.0, 0.3, 0, 0.8, 2.0), 0.0], [_wave(0.1, 300.0, 180.0, 0.3, 0, 0.8, 2.0), 0.14]]))
	_reg("equip", _wave(0.12, 600.0, 950.0, 0.3, 1, 0.15, 2.4))
	_reg("craft", _mix([[_wave(0.18, 1100.0, 1000.0, 0.4, 3, 0.1, 3.0), 0.0], [_wave(0.18, 1250.0, 1150.0, 0.4, 3, 0.1, 3.0), 0.16], [_wave(0.3, 1500.0, 1400.0, 0.4, 3, 0.1, 2.4), 0.32]]))
	_reg("quest", _notes([523.0, 659.0, 784.0, 1046.0], 0.11, 0.3, 0.3, 3))
	_reg("levelup", _notes([392.0, 523.0, 659.0, 784.0, 1046.0, 1318.0], 0.09, 0.4, 0.3, 3))
	_reg("chest", _mix([[_wave(0.3, 110.0, 220.0, 0.4, 2, 0.35, 1.2, 0.4), 0.0], [_notes([1046.0, 1318.0, 1568.0], 0.08, 0.2, 0.25, 3), 0.3]]))
	_reg("bow", _mix([[_wave(0.2, 340.0, 150.0, 0.5, 0, 0.0, 3.0), 0.0], [_wave(0.12, 1000.0, 300.0, 0.25, 0, 0.9, 3.0, 0.4), 0.0]]))
	_reg("roar", _wave(0.7, 95.0, 55.0, 0.75, 2, 0.45, 0.9, 0.5))
	_reg("click", _wave(0.05, 900.0, 650.0, 0.25, 1, 0.0, 3.0))
	_reg("whoosh", _wave(0.5, 200.0, 800.0, 0.3, 0, 0.9, 1.0, 0.25))
	_reg("meditate", _notes([261.0, 392.0], 0.25, 0.8, 0.15, 0))
