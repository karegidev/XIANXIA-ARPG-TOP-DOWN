extends Control
## MenuUI - pause menu: Status, Gear, Bag, Skills, Quests, Codex, Map, Settings, System. Built entirely in code.

const MapViewScript: GDScript = preload("res://scripts/ui/map_view.gd")

signal closed
signal title_requested
signal load_requested

const TABS: Array = ["Status", "Guide", "Gear", "Bag", "Skills", "Quests", "Codex", "Map", "Settings", "System"]
const TYPE_ORDER: Array = ["consumable", "material", "tool", "weapon", "trinket", "junk"]
const TYPE_NAMES: Dictionary = {"consumable": "Consumables", "material": "Materials", "tool": "Tools", "weapon": "Weapons", "trinket": "Trinkets", "junk": "Odds and Ends"}
const RARITY_COLORS: Array = [Color(0.92, 0.94, 1.0), Color(0.55, 1.0, 0.6), Color(0.55, 0.75, 1.0), Color(0.88, 0.6, 1.0)]

var tab: int = 0
var guide_topic: int = 0
var content: VBoxContainer = null
var tab_buttons: Array = []
var panel: PanelContainer = null
var open_flag: bool = false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	visible = false
	_apply_viewport_layout()
	get_viewport().size_changed.connect(_apply_viewport_layout)
	var dim: ColorRect = ColorRect.new()
	dim.color = Color(0, 0, 0, 0.72)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(dim)
	panel = PanelContainer.new()
	panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	panel.anchor_left = 0.06
	panel.anchor_right = 0.94
	panel.anchor_top = 0.05
	panel.anchor_bottom = 0.95
	panel.offset_left = 0.0
	panel.offset_right = 0.0
	panel.offset_top = 0.0
	panel.offset_bottom = 0.0
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	var sb: StyleBoxFlat = StyleBoxFlat.new()
	sb.bg_color = Color(0.07, 0.11, 0.16, 0.97)
	sb.border_color = Color(0.85, 0.72, 0.4, 1)
	sb.set_border_width_all(3)
	sb.set_corner_radius_all(14)
	sb.set_content_margin_all(14)
	panel.add_theme_stylebox_override("panel", sb)
	add_child(panel)
	var root: VBoxContainer = VBoxContainer.new()
	root.add_theme_constant_override("separation", 8)
	panel.add_child(root)
	var head: HBoxContainer = HBoxContainer.new()
	root.add_child(head)
	var title: Label = _lbl("Azure Ascension", 30, Color(1, 0.9, 0.6))
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(title)
	head.add_child(_btn("Resume", close, 56, 26))
	var tabs: HFlowContainer = HFlowContainer.new()
	tabs.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tabs.add_theme_constant_override("h_separation", 6)
	tabs.add_theme_constant_override("v_separation", 6)
	root.add_child(tabs)
	for i in range(TABS.size()):
		var b: Button = _btn(String(TABS[i]), _set_tab.bind(i), 50, 21)
		b.toggle_mode = true
		b.custom_minimum_size = Vector2(120, 50)
		tabs.add_child(b)
		tab_buttons.append(b)
	var scroll: ScrollContainer = ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	root.add_child(scroll)
	content = VBoxContainer.new()
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_theme_constant_override("separation", 10)
	scroll.add_child(content)


func _apply_viewport_layout() -> void:
	if not is_inside_tree():
		return
	var viewport_size: Vector2 = get_viewport().get_visible_rect().size
	if viewport_size.x <= 0.0 or viewport_size.y <= 0.0:
		return
	# A CanvasLayer's Control child may not receive a useful parent Control size.
	# Explicit sizing prevents the panel/title from collapsing into a narrow strip.
	set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	position = Vector2.ZERO
	size = viewport_size
	if panel != null and is_instance_valid(panel):
		panel.anchor_left = 0.06
		panel.anchor_right = 0.94
		panel.anchor_top = 0.05
		panel.anchor_bottom = 0.95
		panel.offset_left = 0.0
		panel.offset_right = 0.0
		panel.offset_top = 0.0
		panel.offset_bottom = 0.0


func open_menu() -> void:
	if open_flag:
		return
	open_flag = true
	visible = true
	Sfx.play("click")
	_set_tab(tab)


func close() -> void:
	if not open_flag:
		return
	open_flag = false
	visible = false
	GameState.save_settings()
	closed.emit()


func _set_tab(i: int) -> void:
	if i < 0 or i >= TABS.size():
		push_warning("Menu tab index out of range: %d" % i)
		return
	tab = i
	for k in range(tab_buttons.size()):
		tab_buttons[k].button_pressed = (k == i)
	_rebuild()


# ------------------------------------------------------------------ helpers
func _lbl(text: String, label_font_size: int = 22, col: Color = Color(0.92, 0.94, 1.0), should_wrap: bool = true) -> Label:
	var l: Label = Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", label_font_size)
	l.add_theme_color_override("font_color", col)
	if should_wrap:
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l


func _btn(text: String, cb: Callable, min_h: float = 64.0, fs: int = 24) -> Button:
	var b: Button = Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, min_h)
	b.add_theme_font_size_override("font_size", fs)
	b.focus_mode = Control.FOCUS_ALL
	b.mouse_filter = Control.MOUSE_FILTER_STOP
	b.pressed.connect(cb)
	return b


func _icon_rect(tex: Texture2D, w: float, h: float) -> TextureRect:
	var r: TextureRect = TextureRect.new()
	r.texture = tex
	r.custom_minimum_size = Vector2(w, h)
	r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	r.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	return r


func _clear() -> void:
	# Detach old controls immediately so they cannot keep intercepting touches
	# while the next tab is being rebuilt.
	for c in content.get_children():
		content.remove_child(c)
		c.queue_free()


func _card() -> VBoxContainer:
	var pc: PanelContainer = PanelContainer.new()
	var sb: StyleBoxFlat = StyleBoxFlat.new()
	sb.bg_color = Color(0.12, 0.17, 0.24, 1)
	sb.set_corner_radius_all(10)
	sb.set_content_margin_all(12)
	pc.add_theme_stylebox_override("panel", sb)
	content.add_child(pc)
	var v: VBoxContainer = VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	pc.add_child(v)
	return v


func _icon_card(tex: Texture2D, title: String, title_col: Color, lines: Array, icon_w: float = 72.0, icon_h: float = 72.0) -> VBoxContainer:
	## card with an icon on the left and text on the right; returns the right-hand VBox so callers can add buttons
	var pc: PanelContainer = PanelContainer.new()
	var sb: StyleBoxFlat = StyleBoxFlat.new()
	sb.bg_color = Color(0.12, 0.17, 0.24, 1)
	sb.set_corner_radius_all(10)
	sb.set_content_margin_all(10)
	pc.add_theme_stylebox_override("panel", sb)
	content.add_child(pc)
	var h: HBoxContainer = HBoxContainer.new()
	h.add_theme_constant_override("separation", 12)
	pc.add_child(h)
	h.add_child(_icon_rect(tex, icon_w, icon_h))
	var v: VBoxContainer = VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 4)
	h.add_child(v)
	v.add_child(_lbl(title, 24, title_col))
	for ln in lines:
		v.add_child(_lbl(String(ln), 19, Color(0.82, 0.86, 0.92)))
	return v


func _heading(text: String) -> void:
	content.add_child(_lbl(text, 26, Color(1, 0.9, 0.6)))


func _rebuild() -> void:
	_clear()
	match String(TABS[tab]):
		"Status":
			_tab_status()
		"Guide":
			_tab_guide()
		"Gear":
			_tab_gear()
		"Bag":
			_tab_bag()
		"Skills":
			_tab_skills()
		"Quests":
			_tab_quests()
		"Codex":
			_tab_codex()
		"Map":
			_tab_map()
		"Settings":
			_tab_settings()
		"System":
			_tab_system()


# ------------------------------------------------------------------ Status
func _tab_status() -> void:
	var c: VBoxContainer = _card()
	c.add_child(_lbl("%s  -  Stage %d / %d" % [GameState.realm_name(), GameState.stage, GameState.MAX_STAGE], 28, Color(1, 0.9, 0.6)))
	var pb: ProgressBar = ProgressBar.new()
	pb.min_value = 0.0
	pb.max_value = GameState.xp_needed()
	pb.value = GameState.xp
	pb.custom_minimum_size = Vector2(0, 28)
	pb.show_percentage = false
	c.add_child(pb)
	c.add_child(_lbl("Cultivation: %d / %d" % [int(GameState.xp), int(GameState.xp_needed())], 20))
	var s: VBoxContainer = _card()
	s.add_child(_lbl("Max HP: %d     Max Qi: %d     Stamina: %d" % [int(GameState.max_hp()), int(GameState.max_qi()), int(GameState.max_stamina())], 22))
	s.add_child(_lbl("Attack: %d     Speed: %.1f m/s     Defense: %d%%     Qi regen: %.1f/s" % [int(GameState.attack_power()), GameState.move_speed_m(), int(GameState.damage_reduction() * 100.0), GameState.qi_regen()], 22))
	s.add_child(_lbl("Purse: %s     Spirit Stones: %d" % [GameState.format_coins(GameState.coins), GameState.stones], 22, Color(0.65, 0.92, 1.0)))
	var tk: int = 0
	for k in GameState.kills.keys():
		tk += int(GameState.kills[k])
	s.add_child(_lbl("Foes slain: %d     Resources gathered: %d     Items crafted: %d" % [tk, GameState.gathered, GameState.crafted], 20))
	s.add_child(_lbl("Quests done: %d     Chests opened: %d     Play time: %d min" % [GameState.done_quests.size(), GameState.opened_chests.size(), int(GameState.play_time / 60.0)], 20))
	var b: VBoxContainer = _card()
	if GameState.realm >= GameData.realms.size() - 1:
		b.add_child(_lbl("You stand at the peak of the Path. No higher realm exists... yet.", 22, Color(1, 0.9, 0.6)))
	else:
		var nxt: Dictionary = GameData.realm_def(GameState.realm + 1)
		b.add_child(_lbl("Next realm: %s  (cost %d spirit stones)" % [String(nxt.get("name", "?")), GameState.breakthrough_cost()], 22))
		if GameState.can_breakthrough():
			b.add_child(_btn("BREAKTHROUGH!", _do_breakthrough, 72, 30))
		else:
			b.add_child(_lbl("Reach stage %d with full cultivation to attempt a breakthrough." % GameState.MAX_STAGE, 20, Color(0.8, 0.8, 0.85)))
	var t: VBoxContainer = _card()
	t.add_child(_lbl("How do I break through?", 24, Color(1, 0.9, 0.6)))
	t.add_child(_lbl("1) Reach stage 9 (gain Qi from monsters, quests, meditation, pills).  2) Fill the gold cultivation bar.  3) Have enough spirit stones.  4) Tap BREAKTHROUGH above.", 20, Color(0.85, 0.9, 0.97)))
	t.add_child(_btn("Open the full Guide", _open_guide.bind("cultivation"), 56, 22))


func _do_breakthrough() -> void:
	if GameState.try_breakthrough():
		_rebuild()


# ------------------------------------------------------------------ Guide
func _open_guide(topic_id: String) -> void:
	for i in range(GameData.guide.size()):
		if String(GameData.guide[i].get("id", "")) == topic_id:
			guide_topic = i
	_set_tab(TABS.find("Guide"))


func _pick_topic(i: int) -> void:
	guide_topic = i
	_rebuild()


func _tab_guide() -> void:
	if GameData.guide.is_empty():
		_card().add_child(_lbl("No guide data found.", 22))
		return
	guide_topic = clampi(guide_topic, 0, GameData.guide.size() - 1)
	var flow: HFlowContainer = HFlowContainer.new()
	flow.add_theme_constant_override("h_separation", 6)
	flow.add_theme_constant_override("v_separation", 6)
	content.add_child(flow)
	for i in range(GameData.guide.size()):
		var tb: Button = Button.new()
		tb.text = String(GameData.guide[i].get("title", "?"))
		tb.toggle_mode = true
		tb.button_pressed = (i == guide_topic)
		tb.custom_minimum_size = Vector2(0, 46)
		tb.add_theme_font_size_override("font_size", 18)
		tb.pressed.connect(_pick_topic.bind(i))
		flow.add_child(tb)
	var topic: Dictionary = GameData.guide[guide_topic]
	var body: Array = topic.get("body", [])
	var v: VBoxContainer = _icon_card(GameData.icon(String(topic.get("icon", ""))), String(topic.get("title", "")), Color(1, 0.9, 0.6), [], 64.0, 64.0)
	for para in body:
		v.add_child(_lbl(String(para), 20, Color(0.88, 0.92, 0.98)))
	match String(topic.get("dynamic", "")):
		"breakthrough":
			_guide_breakthrough()
		"recipes":
			_guide_recipes()
		"weapons":
			_guide_weapons()


func _guide_breakthrough() -> void:
	var c: VBoxContainer = _card()
	c.add_child(_lbl("Your progress", 24, Color(0.7, 0.95, 1.0)))
	c.add_child(_lbl("%s  -  Stage %d / %d     Cultivation %d / %d     Spirit stones: %d" % [GameState.realm_name(), GameState.stage, GameState.MAX_STAGE, int(GameState.xp), int(GameState.xp_needed()), GameState.stones], 20))
	var cost: int = GameState.breakthrough_cost()
	var msg: String = ""
	var good: bool = false
	if GameState.realm >= GameData.realms.size() - 1:
		msg = "You are at the peak realm. Nothing higher exists... yet."
	elif GameState.stage < GameState.MAX_STAGE:
		msg = "Next: reach stage %d (you are at stage %d)." % [GameState.MAX_STAGE, GameState.stage]
	elif not GameState.can_breakthrough():
		msg = "Stage %d reached! Now fill the gold cultivation bar (%d / %d)." % [GameState.MAX_STAGE, int(GameState.xp), int(GameState.xp_needed())]
	elif GameState.stones < cost:
		msg = "Cultivation complete! You need %d more spirit stones (have %d, need %d)." % [cost - GameState.stones, GameState.stones, cost]
	else:
		msg = "Everything is ready! Tap the button below."
		good = true
	c.add_child(_lbl(msg, 22, Color(0.6, 1, 0.65) if good else Color(1, 0.9, 0.6)))
	if good:
		c.add_child(_btn("BREAKTHROUGH!", _do_breakthrough, 70, 28))
	var t: VBoxContainer = _card()
	t.add_child(_lbl("Breakthrough costs", 24, Color(0.7, 0.95, 1.0)))
	for i in range(1, GameData.realms.size()):
		var rd: Dictionary = GameData.realms[i]
		t.add_child(_lbl("%s  -  %d spirit stones" % [String(rd.get("name", "?")), int(rd.get("break_cost", 0))], 20))


func _guide_recipes() -> void:
	for st in ["smelter", "anvil", "table", "cooking", "alchemy"]:
		var sd: Dictionary = GameData.stations.get(st, {})
		if sd.is_empty():
			continue
		var c: VBoxContainer = _card()
		c.add_child(_lbl(String(sd.get("name", st)), 24, Color(1, 0.9, 0.6)))
		for r in GameData.recipes_for(st):
			var parts: Array = []
			var inputs: Dictionary = r.get("inputs", {})
			for k in inputs.keys():
				parts.append("%s x%d" % [GameData.item_name(String(k)), int(inputs[k])])
			if int(r.get("coins", 0)) > 0:
				parts.append(GameState.format_coins(int(r["coins"])))
			if int(r.get("stones", 0)) > 0:
				parts.append("%d spirit stones" % int(r["stones"]))
			var outs: Dictionary = r.get("outputs", {})
			if outs.is_empty():
				push_warning("Skipping recipe without outputs in Guide: %s" % String(r.get("id", "unknown")))
				continue
			var out_id: String = String(outs.keys()[0])
			c.add_child(_lbl("%s x%d  =  %s" % [GameData.item_name(out_id), int(outs[out_id]), ", ".join(parts)], 19, Color(0.85, 0.9, 0.97)))


func _guide_weapons() -> void:
	var c: VBoxContainer = _card()
	c.add_child(_lbl("Weapon comparison", 24, Color(1, 0.9, 0.6)))
	var ids: Array = GameData.weapons.keys()
	ids.sort()
	for id in ids:
		var w: Dictionary = GameData.weapons[id]
		c.add_child(_lbl("%s (%s): damage x%.2f, reach %.1f m, crit %d%%" % [GameData.item_name(String(id)), String(w.get("style", "")), float(w.get("dmg", 1.0)), float(w.get("reach", 2.5)), int(float(w.get("crit", 0.15)) * 100.0)], 19, Color(0.85, 0.9, 0.97)))


# ------------------------------------------------------------------ Gear
func _tab_gear() -> void:
	var wd: Dictionary = GameState.weapon_def()
	var wi: Dictionary = GameData.items.get(GameState.equipped_weapon, {})
	var style_names: Dictionary = {"slash": "Slashing blade", "thrust": "Thrusting spear", "shoot": "Ranged bow"}
	var wlines: Array = [
		"%s  -  damage x%.2f   reach %.1f m   crit %d%%" % [String(style_names.get(String(wd.get("style", "slash")), "Weapon")), float(wd.get("dmg", 1.0)), float(wd.get("reach", 2.5)), int(float(wd.get("crit", 0.15)) * 100.0)],
		"Effective hit: %d damage per swing" % int(GameState.attack_power() * float(wd.get("dmg", 1.0))),
	]
	_heading("Equipped")
	_icon_card(GameData.item_icon(GameState.equipped_weapon), String(wi.get("name", "Weapon")), RARITY_COLORS[clampi(int(wi.get("rarity", 0)), 0, 3)], wlines)
	var td: Dictionary = GameState.trinket_def()
	if td.is_empty():
		var tc: VBoxContainer = _card()
		tc.add_child(_lbl("Trinket slot: empty. A Spirit Gourd grants Qi regeneration and max Qi.", 20, Color(0.7, 0.75, 0.85)))
	else:
		var tv: VBoxContainer = _icon_card(GameData.item_icon(GameState.equipped_trinket), String(td.get("name", "Trinket")), RARITY_COLORS[clampi(int(td.get("rarity", 0)), 0, 3)], [String(td.get("desc", ""))])
		tv.add_child(_btn("Unequip", _unequip_trinket, 52, 20))
	_heading("Owned weapons and trinkets")
	var any: bool = false
	for id in GameState.inventory.keys():
		var d: Dictionary = GameData.items.get(id, {})
		var typ: String = String(d.get("type", ""))
		if typ != "weapon" and typ != "trinket":
			continue
		any = true
		var eq: bool = GameState.is_equipped(String(id))
		var lines: Array = [String(d.get("desc", ""))]
		if typ == "weapon":
			var w2: Dictionary = GameData.weapons.get(String(d.get("weapon", id)), {})
			lines.append("Damage x%.2f   Reach %.1f m   Crit %d%%" % [float(w2.get("dmg", 1.0)), float(w2.get("reach", 2.5)), int(float(w2.get("crit", 0.15)) * 100.0)])
		var v: VBoxContainer = _icon_card(GameData.item_icon(String(id)), "%s%s" % [String(d.get("name", id)), "  (equipped)" if eq else ""], RARITY_COLORS[clampi(int(d.get("rarity", 0)), 0, 3)], lines, 64.0, 64.0)
		if not eq:
			v.add_child(_btn("Equip", _equip.bind(String(id)), 52, 20))
	if not any:
		_card().add_child(_lbl("Nothing else yet. Forge weapons at the anvil, or buy them from merchants.", 20))


func _equip(id: String) -> void:
	GameState.equip_item(id)
	_rebuild()


func _unequip_trinket() -> void:
	GameState.unequip_trinket()
	_rebuild()


# ------------------------------------------------------------------ Bag
func _tab_bag() -> void:
	var c: VBoxContainer = _card()
	c.add_child(_lbl("Purse: %s      Spirit Stones: %d" % [GameState.format_coins(GameState.coins), GameState.stones], 26, Color(1, 0.92, 0.6)))
	if GameState.inventory.is_empty():
		c.add_child(_lbl("Your bag is empty.", 22))
		return
	for typ in TYPE_ORDER:
		var ids: Array = []
		for id in GameState.inventory.keys():
			if String(GameData.items.get(id, {}).get("type", "")) == typ:
				ids.append(String(id))
		if ids.is_empty():
			continue
		ids.sort()
		_heading(String(TYPE_NAMES.get(typ, typ)))
		for id in ids:
			var d: Dictionary = GameData.items.get(id, {})
			var lines: Array = [String(d.get("desc", ""))]
			if int(d.get("sell", 0)) > 0:
				lines.append("Sells for %s" % GameState.format_coins(int(d["sell"])))
			var v: VBoxContainer = _icon_card(GameData.item_icon(id), "%s  x%d" % [String(d.get("name", id)), GameState.item_count(id)], RARITY_COLORS[clampi(int(d.get("rarity", 0)), 0, 3)], lines, 64.0, 64.0)
			if typ == "consumable":
				v.add_child(_btn("Use", _use_item.bind(id), 50, 20))
			elif typ == "weapon" or typ == "trinket":
				if not GameState.is_equipped(id):
					v.add_child(_btn("Equip", _equip.bind(id), 50, 20))


func _use_item(id: String) -> void:
	GameState.use_item(id)
	_rebuild()


# ------------------------------------------------------------------ Skills
func _tab_skills() -> void:
	var c: VBoxContainer = _card()
	c.add_child(_lbl("Hold ATTACK to chain a 3-hit combo (the 3rd hit is a heavy finisher; bows loose three arrows). DASH grants brief invulnerability - dash just as a blow lands for a PERFECT DODGE. Tap FLY (Foundation realm) to ride your flying sword across rivers.", 20))
	for i in range(GameData.skill_order.size()):
		var id: String = String(GameData.skill_order[i])
		var d: Dictionary = GameData.skills.get(id, {})
		var unlocked: bool = GameState.realm >= int(d.get("realm", 0))
		var col: Color = Color(1, 0.95, 0.75) if unlocked else Color(0.6, 0.6, 0.65)
		var lines: Array = ["Qi %d    Cooldown %.1fs    Damage x%.1f" % [int(d.get("qi", 0)), float(d.get("cd", 0)), float(d.get("dmg", 0))], String(d.get("desc", ""))]
		if not unlocked:
			lines.append("Unlocks at: " + String(GameData.realm_def(int(d.get("realm", 0))).get("name", "?")))
		_icon_card(GameData.icon(String(d.get("icon", ""))), "%d. %s" % [i + 1, String(d.get("name", id))], col, lines)


# ------------------------------------------------------------------ Quests
func _tab_quests() -> void:
	var any: bool = false
	for qid in GameState.active_quests.keys():
		any = true
		var q: Dictionary = GameData.quests.get(qid, {})
		var prog: int = GameState.quest_progress(String(qid))
		var need: int = int(q.get("count", 1))
		var row: VBoxContainer = _card()
		row.add_child(_lbl(String(q.get("name", qid)), 24, Color(1, 0.95, 0.75)))
		row.add_child(_lbl(String(q.get("desc", "")), 19))
		var done: bool = prog >= need
		row.add_child(_lbl("Progress: %d / %d" % [mini(prog, need), need], 20, Color(0.6, 1, 0.65) if done else Color(1, 0.9, 0.6)))
		var giver: String = String(GameData.npcs.get(String(q.get("giver", "")), {}).get("name", "?"))
		row.add_child(_lbl(("Return to " if done else "Quest giver: ") + giver, 18, Color(0.75, 0.85, 1.0)))
	if not any:
		var c: VBoxContainer = _card()
		c.add_child(_lbl("No active quests. Speak to elders, smiths and merchants (look for the golden !).", 22))
	var avail: Array = []
	for qid in GameData.quests.keys():
		if GameState.quest_available(String(qid)):
			avail.append(String(qid))
	if not avail.is_empty():
		var h: VBoxContainer = _card()
		h.add_child(_lbl("Available (find the giver):", 22, Color(1, 0.9, 0.6)))
		for qid in avail:
			var q2: Dictionary = GameData.quests[qid]
			var g: String = String(GameData.npcs.get(String(q2.get("giver", "")), {}).get("name", "?"))
			h.add_child(_lbl("- %s  (%s)" % [String(q2.get("name", qid)), g], 19))
	var d2: VBoxContainer = _card()
	d2.add_child(_lbl("Completed: %d / %d" % [GameState.done_quests.size(), GameData.quests.size()], 20, Color(0.6, 1, 0.65)))


# ------------------------------------------------------------------ Codex (bestiary)
func _tab_codex() -> void:
	var c: VBoxContainer = _card()
	c.add_child(_lbl("Bestiary - defeat a creature to record it. Elite variants glow gold and drop twice the loot.", 20))
	var ids: Array = GameData.enemies.keys()
	ids.sort()
	for id in ids:
		var d: Dictionary = GameData.enemies[id]
		var kills: int = int(GameState.kills.get(id, 0))
		var tex: Texture2D = GameData.tex(String(d.get("sprite", "")))
		var pc: PanelContainer = PanelContainer.new()
		var sb: StyleBoxFlat = StyleBoxFlat.new()
		sb.bg_color = Color(0.12, 0.17, 0.24, 1)
		sb.set_corner_radius_all(10)
		sb.set_content_margin_all(10)
		pc.add_theme_stylebox_override("panel", sb)
		content.add_child(pc)
		var h: HBoxContainer = HBoxContainer.new()
		h.add_theme_constant_override("separation", 12)
		pc.add_child(h)
		var pic: TextureRect = _icon_rect(tex, 150.0, 120.0)
		if kills <= 0:
			pic.modulate = Color(0, 0, 0, 0.85)
		h.add_child(pic)
		var v: VBoxContainer = VBoxContainer.new()
		v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		h.add_child(v)
		if kills <= 0:
			v.add_child(_lbl("???", 24, Color(0.6, 0.6, 0.7)))
			v.add_child(_lbl("Not yet encountered.", 19, Color(0.6, 0.6, 0.7)))
		else:
			var tag: String = "  [BOSS]" if bool(d.get("boss", false)) else ""
			v.add_child(_lbl(String(d.get("name", id)) + tag, 24, Color(1, 0.85, 0.6) if bool(d.get("boss", false)) else Color(1, 0.95, 0.75)))
			v.add_child(_lbl("HP %d    Damage %d    Defeated: %d" % [int(d.get("hp", 0)), int(d.get("dmg", 0)), kills], 19, Color(0.8, 0.9, 1.0)))
			v.add_child(_lbl(String(d.get("bio", "")), 19, Color(0.82, 0.86, 0.92)))


# ------------------------------------------------------------------ Map
func _tab_map() -> void:
	var mv = MapViewScript.new()
	mv.custom_minimum_size = Vector2(0, 520)
	mv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	content.add_child(mv)
	content.add_child(_lbl("Points of interest are marked. Spirit trees glow near the Heart Tree and in the wilds. Beast bosses lair in the far corners.", 19, Color(0.8, 0.85, 0.9)))


# ------------------------------------------------------------------ Settings
func _tab_settings() -> void:
	var c: VBoxContainer = _card()
	c.add_child(_lbl("Controls, Audio & Display", 26, Color(1, 0.9, 0.6)))
	_slider(c, "Control size", "ctrl_scale", 0.7, 1.4, 0.05)
	_slider(c, "Control opacity", "ctrl_opacity", 0.3, 1.0, 0.05)
	_slider(c, "Sound effects volume", "sfx", 0.0, 1.0, 0.05)
	_slider(c, "Camera zoom", "cam_zoom", 0.7, 1.7, 0.05)
	_slider(c, "Screen shake", "shake", 0.0, 1.0, 0.1)
	_toggle(c, "Left-handed layout", "left_handed")
	_toggle(c, "Auto-aim nearest enemy", "auto_aim")
	_toggle(c, "Vibration", "vibration")
	_toggle(c, "Damage numbers", "damage_numbers")
	_toggle(c, "Show FPS", "show_fps")


func _slider(parent: VBoxContainer, label: String, key: String, mn: float, mx: float, step: float) -> void:
	parent.add_child(_lbl("%s: %.2f" % [label, float(GameState.settings.get(key, 1.0))], 20))
	var s: HSlider = HSlider.new()
	s.min_value = mn
	s.max_value = mx
	s.step = step
	s.value = float(GameState.settings.get(key, 1.0))
	s.custom_minimum_size = Vector2(0, 44)
	s.value_changed.connect(_on_slider.bind(key))
	parent.add_child(s)


func _on_slider(v: float, key: String) -> void:
	GameState.settings[key] = v
	if key == "cam_zoom" and GameState.player != null and is_instance_valid(GameState.player):
		GameState.player.set_zoom(v)
	if key == "sfx":
		Sfx.play("coin")


func _toggle(parent: VBoxContainer, label: String, key: String) -> void:
	var cb: CheckButton = CheckButton.new()
	cb.text = label
	cb.add_theme_font_size_override("font_size", 22)
	cb.custom_minimum_size = Vector2(0, 56)
	cb.button_pressed = bool(GameState.settings.get(key, false))
	cb.toggled.connect(_on_toggle.bind(key))
	parent.add_child(cb)


func _on_toggle(v: bool, key: String) -> void:
	GameState.settings[key] = v


# ------------------------------------------------------------------ System
func _tab_system() -> void:
	var c: VBoxContainer = _card()
	c.add_child(_lbl("Progress is also auto-saved every few minutes.", 20))
	c.add_child(_btn("Save Game", _do_save, 68, 26))
	if GameState.has_save():
		c.add_child(_btn("Load Last Save", _do_load, 68, 26))
	c.add_child(_btn("Return to Title", _do_title, 68, 26))


func _do_save() -> void:
	if GameState.save_game():
		GameState.say("Game saved.", Color(0.7, 1, 0.7))
	else:
		GameState.say("Save failed!", Color(1, 0.5, 0.5))
	close()


func _do_load() -> void:
	close()
	load_requested.emit()


func _do_title() -> void:
	close()
	title_requested.emit()
