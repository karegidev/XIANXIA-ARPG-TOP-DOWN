extends Control
## TitleUI - title screen with New Game / Continue / Quit.

signal new_game
signal continue_game


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_STOP
	var bg: ColorRect = ColorRect.new()
	bg.color = Color(0.04, 0.08, 0.13, 1)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var hall: TextureRect = _pic("hall_town", 0.0)
	hall.modulate = Color(1, 1, 1, 0.22)
	hall.anchor_left = 0.2
	hall.anchor_right = 0.8
	hall.anchor_top = 0.05
	hall.anchor_bottom = 0.75
	add_child(hall)
	var left: TextureRect = _pic("player_base", 0.0)
	left.anchor_left = 0.03
	left.anchor_right = 0.25
	left.anchor_top = 0.3
	left.anchor_bottom = 0.98
	add_child(left)
	var right: TextureRect = _pic("player_god", 0.0)
	right.anchor_left = 0.75
	right.anchor_right = 0.97
	right.anchor_top = 0.22
	right.anchor_bottom = 0.98
	add_child(right)
	var col: VBoxContainer = VBoxContainer.new()
	col.anchor_left = 0.3
	col.anchor_right = 0.7
	col.anchor_top = 0.14
	col.anchor_bottom = 0.95
	col.add_theme_constant_override("separation", 14)
	add_child(col)
	var t: Label = Label.new()
	t.text = "AZURE ASCENSION"
	t.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	t.add_theme_font_size_override("font_size", 64)
	t.add_theme_color_override("font_color", Color(1, 0.9, 0.6))
	t.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.9))
	t.add_theme_constant_override("outline_size", 10)
	col.add_child(t)
	var sub: Label = Label.new()
	sub.text = "A Xianxia Action RPG"
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.add_theme_font_size_override("font_size", 26)
	sub.add_theme_color_override("font_color", Color(0.7, 0.88, 1.0))
	col.add_child(sub)
	var sp: Control = Control.new()
	sp.custom_minimum_size = Vector2(0, 60)
	col.add_child(sp)
	if GameState.has_save():
		col.add_child(_button("Continue", _on_continue))
	col.add_child(_button("New Game", _on_new))
	var hint: Label = Label.new()
	hint.text = "Touch controls: left stick to move, right buttons to fight."
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.add_theme_font_size_override("font_size", 20)
	hint.add_theme_color_override("font_color", Color(0.8, 0.85, 0.9, 0.85))
	col.add_child(hint)


func _pic(id: String, _a: float) -> TextureRect:
	var r: TextureRect = TextureRect.new()
	r.texture = GameData.tex(id)
	r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	r.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return r


func _button(text: String, cb: Callable) -> Button:
	var b: Button = Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 84)
	b.add_theme_font_size_override("font_size", 34)
	b.pressed.connect(cb)
	return b


func _on_new() -> void:
	new_game.emit()


func _on_continue() -> void:
	continue_game.emit()
