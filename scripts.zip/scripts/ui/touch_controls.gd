extends Control
## TouchControls - the ONLY input method: floating analog stick (left) + action buttons (right).
## Multi-touch via InputEventScreenTouch/Drag. (Mouse is emulated as touch in the editor for testing.)

signal attack_down
signal attack_up
signal dash_pressed
signal skill_pressed(index: int)
signal interact_pressed
signal menu_pressed
signal heal_pressed
signal qi_pressed
signal fly_pressed

var enabled: bool = true
var move_vec: Vector2 = Vector2.ZERO
var interact_visible: bool = false
var interact_label: String = "TALK"

var _fingers: Dictionary = {}      # touch index -> role
var _pressed: Dictionary = {}      # role -> true while held
var _stick_active: bool = false
var _stick_origin: Vector2 = Vector2.ZERO
var _stick_pos: Vector2 = Vector2.ZERO
var _stick_finger: int = -1
var _btn: Dictionary = {}          # role -> {c: Vector2, r: float}
var _size: Vector2 = Vector2(1280, 720)
var _s: float = 1.0
var _op: float = 0.75
var _left: bool = false


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)
	_layout()


func is_held(role: String) -> bool:
	return bool(_pressed.get(role, false))


func set_enabled(v: bool) -> void:
	if enabled == v and visible == v:
		return
	enabled = v
	visible = v
	if not v:
		_release_all()


func _release_all() -> void:
	if _pressed.has("attack"):
		attack_up.emit()
	_fingers.clear()
	_pressed.clear()
	_stick_active = false
	_stick_finger = -1
	move_vec = Vector2.ZERO


func _mx(x: float) -> float:
	return _size.x - x if _left else x


func _layout() -> void:
	_size = get_viewport_rect().size
	_s = float(GameState.settings.get("ctrl_scale", 1.0))
	_op = float(GameState.settings.get("ctrl_opacity", 0.75))
	_left = bool(GameState.settings.get("left_handed", false))
	var s: float = _s
	var a: Vector2 = Vector2(_mx(_size.x - 150.0 * s), _size.y - 140.0 * s)
	var dirx: float = -1.0 if not _left else 1.0     # direction pointing towards the screen centre
	_btn["attack"] = {"c": a, "r": 82.0 * s}
	_btn["dash"] = {"c": a + Vector2(dirx * 150.0 * s, 75.0 * s), "r": 52.0 * s}
	_btn["fly"] = {"c": a + Vector2(dirx * 265.0 * s, 95.0 * s), "r": 40.0 * s}
	for i in range(6):
		var ang: float = deg_to_rad(8.0 + 20.5 * float(i))
		var off: Vector2 = Vector2(dirx * cos(ang) * 225.0 * s, -sin(ang) * 225.0 * s)
		_btn["skill%d" % i] = {"c": a + off, "r": 38.0 * s}
	_btn["heal"] = {"c": a + Vector2(dirx * 335.0 * s, 10.0 * s), "r": 36.0 * s}
	_btn["qi"] = {"c": a + Vector2(dirx * 330.0 * s, -85.0 * s), "r": 36.0 * s}
	_btn["interact"] = {"c": a + Vector2(dirx * 250.0 * s, -265.0 * s), "r": 54.0 * s}
	_btn["menu"] = {"c": Vector2(_mx(_size.x - 330.0), 54.0), "r": 40.0 * minf(s, 1.2)}


func _stick_zone_ok(p: Vector2) -> bool:
	var w: float = _size.x * 0.45
	var in_x: bool = p.x <= w if not _left else p.x >= _size.x - w
	return in_x and p.y > _size.y * 0.22


func _stick_radius() -> float:
	return 105.0 * _s


func _input(event: InputEvent) -> void:
	if not enabled or not is_visible_in_tree():
		return
	if event is InputEventScreenTouch:
		if event.pressed:
			_press(event.index, event.position)
		else:
			_release(event.index)
		# This control owns the gameplay touch zones. Mark handled only while the
		# gameplay overlay is active, so touches cannot leak into UI underneath.
		get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag:
		_drag(event.index, event.position)
		if _fingers.has(event.index):
			get_viewport().set_input_as_handled()


func _press(idx: int, pos: Vector2) -> void:
	_layout()
	for role in _btn.keys():
		if role == "interact" and not interact_visible:
			continue
		var b: Dictionary = _btn[role]
		if pos.distance_to(b["c"]) <= float(b["r"]) * 1.15:
			_fingers[idx] = role
			_pressed[role] = true
			_fire(role)
			return
	if not _stick_active and _stick_zone_ok(pos):
		var R: float = _stick_radius()
		var o: Vector2 = pos
		if not _left:
			o.x = clampf(o.x, R + 12.0, _size.x * 0.45)
		else:
			o.x = clampf(o.x, _size.x * 0.55, _size.x - R - 12.0)
		o.y = clampf(o.y, _size.y * 0.30, _size.y - R - 12.0)
		_stick_origin = o
		_stick_pos = pos
		_stick_active = true
		_stick_finger = idx
		_fingers[idx] = "stick"
		_update_stick()


func _fire(role: String) -> void:
	match role:
		"attack":
			attack_down.emit()
		"dash":
			dash_pressed.emit()
		"interact":
			interact_pressed.emit()
		"menu":
			menu_pressed.emit()
		"heal":
			heal_pressed.emit()
		"qi":
			qi_pressed.emit()
		"fly":
			fly_pressed.emit()
		_:
			if role.begins_with("skill"):
				skill_pressed.emit(int(role.substr(5)))


func _drag(idx: int, pos: Vector2) -> void:
	if idx == _stick_finger and _stick_active:
		_stick_pos = pos
		_update_stick()


func _release(idx: int) -> void:
	if not _fingers.has(idx):
		return
	var role: String = String(_fingers[idx])
	_fingers.erase(idx)
	_pressed.erase(role)
	if role == "stick":
		_stick_active = false
		_stick_finger = -1
		move_vec = Vector2.ZERO
	elif role == "attack":
		attack_up.emit()


func _update_stick() -> void:
	var R: float = _stick_radius()
	var v: Vector2 = _stick_pos - _stick_origin
	var l: float = v.length()
	if l > R:
		v = v / l * R
		# drag the base along so the thumb never "runs out" of the stick
		_stick_origin += (_stick_pos - _stick_origin) - v
		l = R
	var n: float = l / R
	if n < 0.12:
		move_vec = Vector2.ZERO
	else:
		move_vec = v.normalized() * clampf((n - 0.12) / 0.88, 0.0, 1.0)
		if n > 0.6:
			move_vec = v.normalized()


func _process(_delta: float) -> void:
	if enabled:
		queue_redraw()


# ------------------------------------------------------------------ drawing
func _draw() -> void:
	if not enabled:
		return
	_layout()
	var op: float = _op
	var R: float = _stick_radius()
	var base_c: Vector2 = _stick_origin
	var knob: Vector2 = _stick_pos
	if not _stick_active:
		base_c = Vector2(_mx(R + 70.0 * _s), _size.y - R - 55.0 * _s)
		knob = base_c
	else:
		var d: Vector2 = knob - base_c
		if d.length() > R:
			knob = base_c + d.normalized() * R
	draw_circle(base_c, R, Color(1, 1, 1, 0.07 * op * 1.6))
	draw_arc(base_c, R, 0.0, TAU, 48, Color(1, 1, 1, 0.45 * op), 3.0, true)
	draw_arc(base_c, R * 0.5, 0.0, TAU, 32, Color(1, 1, 1, 0.18 * op), 2.0, true)
	draw_circle(knob, R * 0.42, Color(0.75, 0.9, 1.0, 0.55 * op if _stick_active else 0.28 * op))
	draw_arc(knob, R * 0.42, 0.0, TAU, 32, Color(1, 1, 1, 0.7 * op), 2.5, true)
	var p: Node = GameState.player
	var pl_ok: bool = p != null and is_instance_valid(p)
	# attack (shows the equipped weapon)
	var mounted: bool = pl_ok and bool(p.mounted)
	var ab: Dictionary = _btn["attack"]
	_draw_round(ab["c"], ab["r"], Color(1.0, 0.45, 0.35), bool(_pressed.get("attack", false)), op * (0.5 if mounted else 1.0))
	var wt: Texture2D = GameData.item_icon(String(GameData.weapons.get(GameState.equipped_weapon, {}).get("sprite", "")).replace("w_", ""))
	if wt == null:
		wt = GameData.icon(GameState.equipped_weapon)
	if wt != null:
		var wsz: float = float(ab["r"]) * 1.45
		draw_texture_rect(wt, Rect2(ab["c"] - Vector2(wsz, wsz) * 0.5, Vector2(wsz, wsz)), false, Color(1, 1, 1, (0.55 + 0.45 * op) * (0.5 if mounted else 1.0)))
	# dash
	var db: Dictionary = _btn["dash"]
	var st_ok: bool = GameState.stamina >= 24.0
	_draw_round(db["c"], db["r"], Color(0.5, 0.8, 1.0), bool(_pressed.get("dash", false)), op * (1.0 if st_ok else 0.5))
	_text(db["c"], "DASH", int(18.0 * _s), Color(1, 1, 1, 0.5 + 0.5 * op))
	# fly (flying sword mount)
	var fb: Dictionary = _btn["fly"]
	var fly_ok: bool = GameState.mount_unlocked()
	_draw_round(fb["c"], fb["r"], Color(0.6, 0.9, 1.0), bool(_pressed.get("fly", false)) or mounted, op * (1.0 if fly_ok else 0.45))
	var ft: Texture2D = GameData.icon("skill_swords")
	if ft != null:
		var fsz: float = float(fb["r"]) * 1.3
		draw_texture_rect(ft, Rect2(fb["c"] - Vector2(fsz, fsz) * 0.5, Vector2(fsz, fsz)), false, Color(1, 1, 1, 0.9 if fly_ok else 0.35))
	_text(fb["c"] + Vector2(0, float(fb["r"]) * 0.72), "LAND" if mounted else ("FLY" if fly_ok else "R2"), int(15.0 * _s), Color(1, 1, 1, 0.95))
	# skills
	for i in range(6):
		var role: String = "skill%d" % i
		var b: Dictionary = _btn[role]
		var id: String = String(GameData.skill_order[i]) if i < GameData.skill_order.size() else ""
		var sd: Dictionary = GameData.skills.get(id, {})
		var unlocked: bool = pl_ok and p.skill_unlocked(i)
		var qi_ok: bool = GameState.qi >= float(sd.get("qi", 0))
		var cc: Array = sd.get("color", [1, 1, 1])
		var col: Color = Color(float(cc[0]), float(cc[1]), float(cc[2]))
		var a2: float = op * (1.0 if (unlocked and qi_ok) else 0.55)
		_draw_round(b["c"], b["r"], col, bool(_pressed.get(role, false)), a2)
		var tex: Texture2D = GameData.icon(String(sd.get("icon", "")))
		if tex != null:
			var box: float = float(b["r"]) * 1.35
			var tint: Color = Color(1, 1, 1, 0.95)
			if not unlocked:
				tint = Color(0.35, 0.35, 0.4, 0.8)
			elif not qi_ok:
				tint = Color(0.55, 0.65, 0.9, 0.8)
			draw_texture_rect(tex, Rect2(b["c"] - Vector2(box, box) * 0.5, Vector2(box, box)), false, tint)
		if unlocked and pl_ok:
			var ratio: float = p.skill_cd_ratio(i)
			if ratio > 0.0:
				_pie(b["c"], float(b["r"]), ratio, Color(0, 0, 0, 0.62))
		elif not unlocked:
			_text(b["c"] + Vector2(0, float(b["r"]) * 0.05), "R%d" % int(sd.get("realm", 0) + 1), int(20.0 * _s), Color(1, 0.85, 0.5, 0.95))
	# quick items
	var hb: Dictionary = _btn["heal"]
	_draw_round(hb["c"], hb["r"], Color(0.95, 0.35, 0.35), bool(_pressed.get("heal", false)), op)
	_text(hb["c"] + Vector2(0, -6.0 * _s), "HP", int(17.0 * _s), Color(1, 1, 1, 0.95))
	_text(hb["c"] + Vector2(0, 14.0 * _s), "x%d" % GameState.item_count("healing_pill"), int(15.0 * _s), Color(1, 1, 1, 0.85))
	var qb: Dictionary = _btn["qi"]
	_draw_round(qb["c"], qb["r"], Color(0.35, 0.6, 1.0), bool(_pressed.get("qi", false)), op)
	_text(qb["c"] + Vector2(0, -6.0 * _s), "QI", int(17.0 * _s), Color(1, 1, 1, 0.95))
	_text(qb["c"] + Vector2(0, 14.0 * _s), "x%d" % GameState.item_count("qi_pill"), int(15.0 * _s), Color(1, 1, 1, 0.85))
	# interact
	if interact_visible:
		var ib: Dictionary = _btn["interact"]
		var pulse: float = 1.0 + 0.06 * sin(Time.get_ticks_msec() * 0.008)
		_draw_round(ib["c"], float(ib["r"]) * pulse, Color(1.0, 0.9, 0.4), bool(_pressed.get("interact", false)), 1.0)
		_text(ib["c"], interact_label, int(20.0 * _s), Color(0.1, 0.08, 0.02, 1.0))
	# menu
	var mb: Dictionary = _btn["menu"]
	_draw_round(mb["c"], mb["r"], Color(0.85, 0.85, 0.95), bool(_pressed.get("menu", false)), op)
	_text(mb["c"], "MENU", int(15.0 * minf(_s, 1.2)), Color(1, 1, 1, 0.95))


func _draw_round(c: Vector2, r: float, col: Color, pressed: bool, op: float) -> void:
	var fill: float = 0.34 if not pressed else 0.62
	draw_circle(c, r, Color(col.r * 0.25, col.g * 0.25, col.b * 0.25, fill * op + 0.1 * op))
	draw_arc(c, r, 0.0, TAU, 40, Color(col.r, col.g, col.b, clampf(0.9 * op + 0.1, 0.0, 1.0)), 3.5 if not pressed else 5.0, true)


func _pie(c: Vector2, r: float, ratio: float, col: Color) -> void:
	var pts: PackedVector2Array = PackedVector2Array([c])
	var steps: int = maxi(3, int(ratio * 36.0))
	var start: float = -PI * 0.5
	for i in range(steps + 1):
		var a: float = start + TAU * ratio * float(i) / float(steps)
		pts.append(c + Vector2(cos(a), sin(a)) * r * 0.96)
	draw_colored_polygon(pts, col)


func _text(c: Vector2, txt: String, fs: int, col: Color) -> void:
	var f: Font = ThemeDB.fallback_font
	var w: float = 200.0
	draw_string_outline(f, Vector2(c.x - w * 0.5, c.y + float(fs) * 0.35), txt, HORIZONTAL_ALIGNMENT_CENTER, w, fs, 4, Color(0, 0, 0, 0.8))
	draw_string(f, Vector2(c.x - w * 0.5, c.y + float(fs) * 0.35), txt, HORIZONTAL_ALIGNMENT_CENTER, w, fs, col)
