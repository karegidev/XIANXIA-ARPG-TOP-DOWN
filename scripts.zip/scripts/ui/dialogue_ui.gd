extends Control
## DialogueUI - NPC conversation, quests, merchant shop (buy + sell) and crafting stations. Built in code.

signal finished

var npc = null
var station = null
var panel: PanelContainer = null
var title_lbl: Label = null
var title_icon: TextureRect = null
var text_lbl: Label = null
var options: VBoxContainer = null
var line_i: int = 0
var open_flag: bool = false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	visible = false
	_apply_viewport_layout()
	get_viewport().size_changed.connect(_apply_viewport_layout)
	panel = PanelContainer.new()
	panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	panel.anchor_left = 0.08
	panel.anchor_right = 0.92
	panel.anchor_top = 0.12
	panel.anchor_bottom = 0.92
	panel.offset_left = 0.0
	panel.offset_right = 0.0
	panel.offset_top = 0.0
	panel.offset_bottom = 0.0
	panel.mouse_filter = Control.MOUSE_FILTER_STOP
	var sb: StyleBoxFlat = StyleBoxFlat.new()
	sb.bg_color = Color(0.06, 0.09, 0.14, 0.97)
	sb.border_color = Color(0.85, 0.72, 0.4, 1)
	sb.set_border_width_all(3)
	sb.set_corner_radius_all(14)
	sb.set_content_margin_all(16)
	panel.add_theme_stylebox_override("panel", sb)
	add_child(panel)
	var scroll: ScrollContainer = ScrollContainer.new()
	scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	panel.add_child(scroll)
	var v: VBoxContainer = VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", 8)
	scroll.add_child(v)
	var head: HBoxContainer = HBoxContainer.new()
	head.add_theme_constant_override("separation", 10)
	v.add_child(head)
	title_icon = _icon_rect(null, 64)
	head.add_child(title_icon)
	title_lbl = _lbl("", 30, Color(1, 0.9, 0.6))
	head.add_child(title_lbl)
	text_lbl = _lbl("", 23, Color(0.93, 0.95, 1.0))
	v.add_child(text_lbl)
	options = VBoxContainer.new()
	options.add_theme_constant_override("separation", 8)
	v.add_child(options)


func _apply_viewport_layout() -> void:
	if not is_inside_tree():
		return
	var viewport_size: Vector2 = get_viewport().get_visible_rect().size
	if viewport_size.x <= 0.0 or viewport_size.y <= 0.0:
		return
	set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	position = Vector2.ZERO
	size = viewport_size
	if panel != null and is_instance_valid(panel):
		panel.anchor_left = 0.08
		panel.anchor_right = 0.92
		panel.anchor_top = 0.12
		panel.anchor_bottom = 0.92
		panel.offset_left = 0.0
		panel.offset_right = 0.0
		panel.offset_top = 0.0
		panel.offset_bottom = 0.0


# ------------------------------------------------------------------ widgets
func _lbl(text: String, label_font_size: int, col: Color) -> Label:
	var l: Label = Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", label_font_size)
	l.add_theme_color_override("font_color", col)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return l


func _icon_rect(tex: Texture2D, icon_extent: float) -> TextureRect:
	var r: TextureRect = TextureRect.new()
	r.texture = tex
	r.custom_minimum_size = Vector2(icon_extent, icon_extent)
	r.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	r.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	return r


func _btn(text: String, cb: Callable) -> Button:
	var b: Button = Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(0, 62)
	b.add_theme_font_size_override("font_size", 23)
	b.focus_mode = Control.FOCUS_ALL
	b.mouse_filter = Control.MOUSE_FILTER_STOP
	b.pressed.connect(cb)
	options.add_child(b)
	return b


func _row(icon_tex: Texture2D, title: String, sub_bbcode: String, btn_text: String, cb: Callable, enabled: bool = true, second_text: String = "", second_cb: Callable = Callable()) -> void:
	var pc: PanelContainer = PanelContainer.new()
	var sb: StyleBoxFlat = StyleBoxFlat.new()
	sb.bg_color = Color(0.12, 0.17, 0.24, 1)
	sb.set_corner_radius_all(10)
	sb.set_content_margin_all(8)
	pc.add_theme_stylebox_override("panel", sb)
	options.add_child(pc)
	var h: HBoxContainer = HBoxContainer.new()
	h.add_theme_constant_override("separation", 10)
	pc.add_child(h)
	h.add_child(_icon_rect(icon_tex, 60))
	var v: VBoxContainer = VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(v)
	v.add_child(_lbl(title, 22, Color(1, 0.95, 0.75)))
	var rt: RichTextLabel = RichTextLabel.new()
	rt.bbcode_enabled = true
	# Avoid fit_content + nested containers: this combination has triggered
	# layout stalls in Godot 4.7. Give the text a stable minimum height instead.
	rt.fit_content = false
	rt.scroll_active = false
	var estimated_lines: int = clampi(int(ceil(float(sub_bbcode.length()) / 48.0)), 2, 6)
	rt.custom_minimum_size = Vector2(0, float(estimated_lines * 22))
	rt.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	rt.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	rt.text = sub_bbcode
	rt.add_theme_font_size_override("normal_font_size", 18)
	v.add_child(rt)
	var b: Button = Button.new()
	b.text = btn_text
	b.custom_minimum_size = Vector2(150, 64)
	b.add_theme_font_size_override("font_size", 21)
	b.disabled = not enabled
	b.pressed.connect(cb)
	h.add_child(b)
	if second_text != "":
		var b2: Button = Button.new()
		b2.text = second_text
		b2.custom_minimum_size = Vector2(120, 64)
		b2.add_theme_font_size_override("font_size", 21)
		b2.pressed.connect(second_cb)
		h.add_child(b2)


func _clear_opts() -> void:
	# Remove immediately from hit testing; free safely at frame end.
	for c in options.get_children():
		options.remove_child(c)
		c.queue_free()


func _set_head(title: String, icon_tex: Texture2D) -> void:
	title_lbl.text = title
	title_icon.texture = icon_tex
	title_icon.visible = icon_tex != null


# ------------------------------------------------------------------ open / close
func open_npc(n) -> void:
	if n == null or not is_instance_valid(n) or not (n is Node) or not n.has_method("get"):
		push_warning("Cannot open NPC dialogue: invalid NPC reference")
		return
	var npc_def = n.get("def")
	if not (npc_def is Dictionary):
		push_warning("Cannot open NPC dialogue: NPC has no definition dictionary")
		return
	npc = n
	station = null
	open_flag = true
	visible = true
	mouse_filter = Control.MOUSE_FILTER_STOP
	var npc_lines: Array = n.def.get("lines", ["..."])
	line_i = randi_range(0, npc_lines.size() - 1) if not npc_lines.is_empty() else 0
	Sfx.play("click")
	_main_page()


func open_station(st) -> void:
	if st == null or not is_instance_valid(st) or not (st is Node):
		push_warning("Cannot open station dialogue: invalid station reference")
		return
	var station_def = st.get("def")
	if not (station_def is Dictionary):
		push_warning("Cannot open station dialogue: station has no definition dictionary")
		return
	station = st
	npc = null
	open_flag = true
	visible = true
	mouse_filter = Control.MOUSE_FILTER_STOP
	Sfx.play("click")
	_station_page()


func close() -> void:
	if not open_flag:
		return
	open_flag = false
	visible = false
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	npc = null
	station = null
	finished.emit()


# ------------------------------------------------------------------ NPC conversation
func _main_page(extra: String = "") -> void:
	_clear_opts()
	var d: Dictionary = npc.def
	_set_head(String(d.get("name", "?")), null)
	var lines: Array = d.get("lines", ["..."])
	if lines.is_empty():
		lines = ["..."]
	line_i = posmod(line_i, lines.size())
	text_lbl.text = extra if extra != "" else String(lines[line_i])
	for qid in d.get("quests", []):
		var q: String = String(qid)
		var qd: Dictionary = GameData.quests.get(q, {})
		if GameState.quest_ready(q):
			_btn("[Turn in] " + String(qd.get("name", q)), _turn_in.bind(q))
		elif GameState.active_quests.has(q):
			_btn("[In progress %d/%d] %s" % [GameState.quest_progress(q), int(qd.get("count", 1)), String(qd.get("name", q))], _quest_info.bind(q))
		elif GameState.quest_available(q):
			_btn("[New quest] " + String(qd.get("name", q)), _quest_offer.bind(q))
	if d.get("shop", []).size() > 0:
		_btn("Browse wares", _shop_page)
		_btn("Sell items", _sell_page)
	_btn("Chat", _next_line)
	_btn("Farewell", close)


func _next_line() -> void:
	line_i += 1
	_main_page()


func _quest_offer(q: String) -> void:
	_clear_opts()
	var qd: Dictionary = GameData.quests[q]
	_set_head(String(qd.get("name", q)), null)
	var target: String = String(qd.get("target", ""))
	var tname: String = GameData.item_name(target) if String(qd.get("kind", "")) == "collect" else String(GameData.enemies.get(target, {}).get("name", target.replace("_", " ")))
	text_lbl.text = "%s\n\nObjective: %s x%d\nReward: %s" % [String(qd.get("desc", "")), tname, int(qd.get("count", 1)), _reward_text(qd)]
	_btn("Accept quest", _accept.bind(q))
	_btn("Back", _main_page)


func _accept(q: String) -> void:
	GameState.accept_quest(q)
	_main_page("Be careful out there, young cultivator.")


func _quest_info(q: String) -> void:
	var qd: Dictionary = GameData.quests[q]
	_main_page("%s\nProgress: %d / %d" % [String(qd.get("desc", "")), GameState.quest_progress(q), int(qd.get("count", 1))])


func _turn_in(q: String) -> void:
	var qd: Dictionary = GameData.quests[q]
	var done_text: String = String(qd.get("done_text", "Well done."))
	var reward: String = _reward_text(qd)
	GameState.complete_quest(q)
	_main_page(done_text + "\n\nReward: " + reward)


func _reward_text(qd: Dictionary) -> String:
	var r: Dictionary = qd.get("reward", {})
	var parts: Array = []
	if int(r.get("xp", 0)) > 0:
		parts.append("%d Qi" % int(r["xp"]))
	if int(r.get("coins", 0)) > 0:
		parts.append(GameState.format_coins(int(r["coins"])))
	if int(r.get("stones", 0)) > 0:
		parts.append("%d spirit stones" % int(r["stones"]))
	var items: Dictionary = r.get("items", {})
	for k in items.keys():
		parts.append("%s x%d" % [GameData.item_name(String(k)), int(items[k])])
	return ", ".join(parts)


# ------------------------------------------------------------------ shop
func _shop_page() -> void:
	_clear_opts()
	_set_head(String(npc.def.get("name", "?")) + " - Wares", GameData.icon("coin_gold"))
	text_lbl.text = "Your purse: %s    Spirit stones: %d" % [GameState.format_coins(GameState.coins), GameState.stones]
	for id in npc.def.get("shop", []):
		var item_id: String = String(id)
		var d: Dictionary = GameData.items.get(item_id, {})
		var price: int = int(d.get("price", 0))
		var owned: int = GameState.item_count(item_id)
		var sub: String = "%s\\n[color=#9fd8ff]Owned: %d[/color]" % [String(d.get("desc", "")), owned]
		_row(GameData.item_icon(item_id), String(d.get("name", item_id)), sub.replace("\\n", "\n"), "Buy\n" + GameState.format_coins(price), _buy.bind(item_id), GameState.coins >= price)
	_btn("Back", _main_page)


func _buy(id: String) -> void:
	if GameState.buy_item(id):
		GameState.say("Purchased " + GameData.item_name(id), Color(0.8, 1, 0.8))
	_shop_page()


func _sell_page() -> void:
	_clear_opts()
	_set_head(String(npc.def.get("name", "?")) + " - Buying", GameData.icon("coin_silver"))
	text_lbl.text = "Your purse: %s" % GameState.format_coins(GameState.coins)
	var any: bool = false
	for id in GameState.inventory.keys():
		var item_id: String = String(id)
		var d: Dictionary = GameData.items.get(item_id, {})
		var value: int = int(d.get("sell", 0))
		var count: int = GameState.item_count(item_id)
		if value <= 0 or count <= 0:
			continue
		var sellable: int = count - (1 if GameState.is_equipped(item_id) else 0)
		if sellable <= 0:
			continue
		any = true
		var sub: String = "Owned x%d   -   %s each" % [count, GameState.format_coins(value)]
		var all_cb: Callable = _sell_all.bind(item_id)
		_row(GameData.item_icon(item_id), String(d.get("name", item_id)), sub, "Sell 1", _sell_one.bind(item_id), true, "All", all_cb)
	if not any:
		text_lbl.text += "\nYou have nothing the merchant wants."
	_btn("Back", _main_page)


func _sell_one(id: String) -> void:
	GameState.sell_item(id, 1)
	_sell_page()


func _sell_all(id: String) -> void:
	var n: int = GameState.item_count(id) - (1 if GameState.is_equipped(id) else 0)
	if n > 0:
		GameState.sell_item(id, n)
	_sell_page()


# ------------------------------------------------------------------ crafting station
func _station_page() -> void:
	_clear_opts()
	var def: Dictionary = station.def
	_set_head(String(def.get("name", "Station")), GameData.icon(String(def.get("icon", ""))))
	text_lbl.text = "%s\nPurse: %s    Spirit stones: %d" % [String(def.get("blurb", "")), GameState.format_coins(GameState.coins), GameState.stones]
	for r in GameData.recipes_for(station.stype):
		var ok: bool = GameState.can_craft(r)
		var lines: Array = []
		var inputs: Dictionary = r.get("inputs", {})
		for k in inputs.keys():
			var have: int = GameState.item_count(String(k))
			var need: int = int(inputs[k])
			var col: String = "#8fe39a" if have >= need else "#ff8a80"
			lines.append("[color=%s]%s %d/%d[/color]" % [col, GameData.item_name(String(k)), have, need])
		if int(r.get("coins", 0)) > 0:
			var c2: String = "#8fe39a" if GameState.coins >= int(r["coins"]) else "#ff8a80"
			lines.append("[color=%s]%s[/color]" % [c2, GameState.format_coins(int(r["coins"]))])
		if int(r.get("stones", 0)) > 0:
			var c3: String = "#8fe39a" if GameState.stones >= int(r["stones"]) else "#ff8a80"
			lines.append("[color=%s]%d spirit stones[/color]" % [c3, int(r["stones"])])
		var outs: Dictionary = r.get("outputs", {})
		if outs.is_empty():
			push_warning("Skipping recipe without outputs at station: %s" % String(r.get("id", "unknown")))
			continue
		var out_id: String = String(outs.keys()[0])
		var title: String = "%s x%d" % [GameData.item_name(out_id), int(outs[out_id])]
		var tex: Texture2D = GameData.item_icon(out_id)
		_row(tex, title, "Needs: " + ", ".join(lines), "Craft", _craft.bind(String(r.get("id", ""))), ok)
	_btn("Close", close)


func _craft(rid: String) -> void:
	for r in GameData.recipes:
		if String(r.get("id", "")) == rid:
			GameState.craft(r)
			break
	_station_page()
