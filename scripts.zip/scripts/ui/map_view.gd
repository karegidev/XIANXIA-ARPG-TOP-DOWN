extends Control
## MapView - full world map with points of interest and the player marker.

const MINI: int = 3
const TILE: float = 128.0


func _ready() -> void:
	custom_minimum_size = Vector2(300, 300)
	mouse_filter = Control.MOUSE_FILTER_IGNORE


func _draw() -> void:
	var w: Node = GameState.world
	if w == null or w.minimap_tex == null:
		return
	var tex: Texture2D = w.minimap_tex
	var tw: float = float(tex.get_width())
	var th: float = float(tex.get_height())
	var k: float = minf(size.x / tw, size.y / th)
	var dsz: Vector2 = Vector2(tw * k, th * k)
	var origin: Vector2 = (size - dsz) * 0.5
	draw_rect(Rect2(origin - Vector2(4, 4), dsz + Vector2(8, 8)), Color(0.9, 0.8, 0.5, 0.9))
	draw_texture_rect(tex, Rect2(origin, dsz), false)
	var f: Font = ThemeDB.fallback_font
	for poi in w.pois:
		var pp: Array = poi.get("pos", [0, 0])
		var tp: Vector2 = Vector2(float(pp[0]), float(pp[1])) * GameData.ppm / TILE
		var mp: Vector2 = origin + tp * float(MINI) * k
		var c: Array = poi.get("color", [1, 1, 1])
		draw_circle(mp, 8.0, Color(float(c[0]), float(c[1]), float(c[2]), 1.0))
		draw_arc(mp, 8.0, 0.0, TAU, 16, Color(0, 0, 0, 1), 2.0)
		var pname: String = String(poi.get("name", ""))
		draw_string_outline(f, mp + Vector2(-70, -14), pname, HORIZONTAL_ALIGNMENT_CENTER, 140, 16, 5, Color(0, 0, 0, 0.9))
		draw_string(f, mp + Vector2(-70, -14), pname, HORIZONTAL_ALIGNMENT_CENTER, 140, 16, Color(1, 1, 1, 1))
	var p: Node = GameState.player
	if p != null and is_instance_valid(p):
		var pt: Vector2 = p.global_position / TILE
		var pc: Vector2 = origin + pt * float(MINI) * k
		draw_circle(pc, 9.0, Color(1, 1, 1, 1))
		draw_circle(pc, 6.0, Color(0.2, 0.5, 1.0, 1))
