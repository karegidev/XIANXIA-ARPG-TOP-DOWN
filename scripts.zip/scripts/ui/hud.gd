extends Control
## HUD - drawn with a single custom _draw for minimal node count (good for mobile).

var _msgs: Array = []
var _banner: String = ""
var _banner_t: float = 0.0
var _banner_safe: bool = false
var _hp_trail: float = 1.0
var _font: Font = null
var _hud_bottom: float = 180.0
const MINI: int = 3
const TILE: float = 128.0


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_preset(Control.PRESET_FULL_RECT)
	_font = ThemeDB.fallback_font
	GameState.message.connect(_on_message)


func _on_message(text: String, color: Color) -> void:
	_msgs.append({"text": text, "color": color, "t": 5.0})
	while _msgs.size() > 5:
		_msgs.pop_front()


func show_banner(text: String, safe: bool) -> void:
	_banner = text
	_banner_t = 3.2
	_banner_safe = safe


func _process(delta: float) -> void:
	if _banner_t > 0.0:
		_banner_t -= delta
	for m in _msgs:
		m["t"] = float(m["t"]) - delta
	while _msgs.size() > 0 and float(_msgs[0]["t"]) <= 0.0:
		_msgs.pop_front()
	var health_ratio: float = GameState.hp / maxf(GameState.max_hp(), 1.0)
	if _hp_trail > health_ratio:
		_hp_trail = maxf(health_ratio, _hp_trail - delta * 0.5)
	else:
		_hp_trail = health_ratio
	queue_redraw()


func _t(pos: Vector2, text: String, label_font_size: int, col: Color, align: int = HORIZONTAL_ALIGNMENT_LEFT, width: float = -1.0) -> void:
	draw_string_outline(_font, pos, text, align, width, label_font_size, 5, Color(0, 0, 0, 0.85))
	draw_string(_font, pos, text, align, width, label_font_size, col)


func _bar(x: float, y: float, w: float, h: float, ratio: float, col: Color, trail: float = -1.0) -> void:
	draw_rect(Rect2(x - 2.0, y - 2.0, w + 4.0, h + 4.0), Color(0, 0, 0, 0.65))
	draw_rect(Rect2(x, y, w, h), Color(col.r * 0.2, col.g * 0.2, col.b * 0.2, 0.9))
	if trail > ratio:
		draw_rect(Rect2(x, y, w * clampf(trail, 0.0, 1.0), h), Color(1, 1, 1, 0.55))
	draw_rect(Rect2(x, y, w * clampf(ratio, 0.0, 1.0), h), col)
	draw_rect(Rect2(x, y, w * clampf(ratio, 0.0, 1.0), h * 0.4), Color(1, 1, 1, 0.15))


func _draw() -> void:
	var sz: Vector2 = get_viewport_rect().size
	_draw_vitals()
	_draw_quests()
	_draw_minimap(sz)
	_draw_messages(sz)
	_draw_status(sz)
	_draw_boss(sz)
	_draw_banner(sz)
	_draw_combo(sz)
	_draw_overlays(sz)
	if bool(GameState.settings.get("show_fps", false)):
		_t(Vector2(sz.x * 0.5 - 40.0, sz.y - 14.0), "%d FPS" % Engine.get_frames_per_second(), 18, Color(0.8, 1, 0.8, 0.9))


func _draw_vitals() -> void:
	var x: float = 18.0
	var y: float = 12.0
	_t(Vector2(x, y + 22.0), "%s  -  Stage %d" % [GameState.realm_name(), GameState.stage], 22, Color(1.0, 0.92, 0.65))
	var hp_r: float = GameState.hp / maxf(GameState.max_hp(), 1.0)
	_bar(x, y + 34.0, 340.0, 24.0, hp_r, Color(0.88, 0.2, 0.22), _hp_trail)
	_t(Vector2(x + 8.0, y + 54.0), "%d / %d" % [int(ceil(GameState.hp)), int(GameState.max_hp())], 18, Color(1, 1, 1, 0.95))
	_bar(x, y + 66.0, 300.0, 18.0, GameState.qi / maxf(GameState.max_qi(), 1.0), Color(0.3, 0.55, 1.0))
	_t(Vector2(x + 8.0, y + 81.0), "Qi %d" % int(GameState.qi), 15, Color(1, 1, 1, 0.9))
	_bar(x, y + 92.0, 260.0, 10.0, GameState.stamina / maxf(GameState.max_stamina(), 1.0), Color(0.4, 0.85, 0.45))
	var need: float = GameState.xp_needed()
	_bar(x, y + 108.0, 260.0, 8.0, GameState.xp / maxf(need, 1.0), Color(1.0, 0.82, 0.3))
	_icon_label(Vector2(x, y + 126.0), "coin_gold", GameState.format_coins(GameState.coins), Color(1.0, 0.92, 0.6))
	_icon_label(Vector2(x + 210.0, y + 126.0), "spirit_stone", str(GameState.stones), Color(0.65, 0.92, 1.0))
	var by: float = y + 160.0
	if GameState.can_breakthrough():
		var need_st: int = GameState.breakthrough_cost()
		var msg: String = "[Breakthrough ready! MENU > Status]"
		if GameState.stones < need_st:
			msg = "[Breakthrough: need %d spirit stones]" % need_st
		_t(Vector2(x, by + 14.0), msg, 17, Color(1, 0.9, 0.5))
		by += 24.0
	elif GameState.stage >= GameState.MAX_STAGE and GameState.realm < GameData.realms.size() - 1:
		_t(Vector2(x, by + 14.0), "[Peak stage - fill the Qi bar to break through]", 16, Color(0.9, 0.85, 0.6))
		by += 24.0
	var wdef: Dictionary = GameData.items.get(GameState.equipped_weapon, {})
	_icon_label(Vector2(x, by), GameState.equipped_weapon, String(wdef.get("name", GameState.equipped_weapon)), Color(0.9, 0.92, 1.0))
	by += 34.0
	for k in GameState.buffs.keys():
		var b: Dictionary = GameState.buffs[k]
		_icon_label(Vector2(x, by), String(b.get("icon", "bread")), "%s %ds" % [String(b.get("name", "Buff")), int(b.get("t", 0))], Color(0.8, 1.0, 0.8))
		by += 32.0
	_hud_bottom = by


func _icon_label(pos: Vector2, icon_id: String, text: String, col: Color) -> void:
	var tex: Texture2D = GameData.icon(icon_id)
	if tex != null:
		draw_texture_rect(tex, Rect2(pos + Vector2(0, -2), Vector2(28, 28)), false)
	_t(pos + Vector2(34, 20), text, 18, col)


func _draw_quests() -> void:
	var y: float = maxf(_hud_bottom + 14.0, 200.0)
	var n: int = 0
	for qid in GameState.active_quests.keys():
		if n >= 3:
			break
		var q: Dictionary = GameData.quests.get(qid, {})
		var prog: int = GameState.quest_progress(String(qid))
		var need: int = int(q.get("count", 1))
		var quest_complete: bool = prog >= need
		var col: Color = Color(0.6, 1, 0.65) if quest_complete else Color(1, 0.95, 0.75)
		var txt: String = "> %s  %d/%d" % [String(q.get("name", qid)), mini(prog, need), need]
		if quest_complete:
			txt += "  (return to " + String(GameData.npcs.get(String(q.get("giver", "")), {}).get("name", "giver")) + ")"
		_t(Vector2(18.0, y), txt, 17, col)
		y += 22.0
		n += 1


func _draw_status(sz: Vector2) -> void:
	var p: Node = GameState.player
	if p == null or not is_instance_valid(p):
		return
	if p.state == "meditate":
		var tree = p.meditate_node
		var ratio: float = 0.0
		if tree != null and is_instance_valid(tree):
			ratio = tree.charge / maxf(float(tree.def.get("capacity", 60.0)), 1.0)
		_t(Vector2(0, sz.y * 0.28), "Meditating...  +%.1f Qi/s" % p.med_rate, 26, Color(0.7, 0.95, 1.0), HORIZONTAL_ALIGNMENT_CENTER, sz.x)
		_bar(sz.x * 0.5 - 130.0, sz.y * 0.28 + 12.0, 260.0, 10.0, ratio, Color(0.4, 0.8, 1.0))
	elif p.mounted:
		var qr: float = GameState.qi / maxf(GameState.max_qi(), 1.0)
		_t(Vector2(0, sz.y * 0.28), "Flying sword - Qi draining", 22, Color(0.75, 0.92, 1.0), HORIZONTAL_ALIGNMENT_CENTER, sz.x)
		_bar(sz.x * 0.5 - 100.0, sz.y * 0.28 + 12.0, 200.0, 8.0, qr, Color(0.3, 0.55, 1.0))
	if p.focus_t > 0.0:
		_t(Vector2(0, sz.y * 0.34), "FOCUS  +50%% damage  %.1fs" % p.focus_t, 20, Color(1.0, 0.9, 0.4), HORIZONTAL_ALIGNMENT_CENTER, sz.x)


func _draw_minimap(sz: Vector2) -> void:
	var w: Node = GameState.world
	if w == null or w.minimap_tex == null or GameState.player == null or not is_instance_valid(GameState.player):
		return
	var ms: float = 150.0
	var dst: Rect2 = Rect2(sz.x - ms - 16.0, 14.0, ms, ms)
	var minimap_zoom: int = MINI
	var tile: float = TILE
	var pt: Vector2 = GameState.player.global_position / tile
	var half: float = 22.0
	var src_size: float = half * 2.0 * float(minimap_zoom)
	var sx: float = clampf((pt.x - half) * float(minimap_zoom), 0.0, float(w.map_w * minimap_zoom) - src_size)
	var sy: float = clampf((pt.y - half) * float(minimap_zoom), 0.0, float(w.map_h * minimap_zoom) - src_size)
	draw_rect(Rect2(dst.position - Vector2(3, 3), dst.size + Vector2(6, 6)), Color(0, 0, 0, 0.7))
	draw_texture_rect_region(w.minimap_tex, dst, Rect2(sx, sy, src_size, src_size), Color(1, 1, 1, 0.92))
	for poi in w.pois:
		var pp: Array = poi.get("pos", [0, 0])
		var tp: Vector2 = Vector2(float(pp[0]), float(pp[1])) * GameData.ppm / tile
		var mp: Vector2 = dst.position + Vector2((tp.x * float(minimap_zoom) - sx), (tp.y * float(minimap_zoom) - sy)) * (ms / src_size)
		if dst.has_point(mp):
			var c: Array = poi.get("color", [1, 1, 1])
			draw_circle(mp, 5.0, Color(float(c[0]), float(c[1]), float(c[2]), 1.0))
			draw_arc(mp, 5.0, 0.0, TAU, 12, Color(0, 0, 0, 0.9), 1.5)
	for e in get_tree().get_nodes_in_group("enemies"):
		if not is_instance_valid(e):
			continue
		var et: Vector2 = e.global_position / tile
		var ep: Vector2 = dst.position + Vector2(et.x * float(minimap_zoom) - sx, et.y * float(minimap_zoom) - sy) * (ms / src_size)
		if dst.has_point(ep) and e.state != "dead":
			draw_circle(ep, 3.5 if not e.is_boss else 5.5, Color(1, 0.25, 0.25, 0.95))
	var pc: Vector2 = dst.position + Vector2(pt.x * float(minimap_zoom) - sx, pt.y * float(minimap_zoom) - sy) * (ms / src_size)
	draw_circle(pc, 5.0, Color(1, 1, 1, 1))
	draw_circle(pc, 3.0, Color(0.2, 0.5, 1.0, 1))
	_t(Vector2(dst.position.x, dst.end.y + 22.0), w.zone_name, 17, Color(1, 0.95, 0.8), HORIZONTAL_ALIGNMENT_RIGHT, ms)
	var hrs: float = GameState.time_of_day * 24.0
	_t(Vector2(dst.position.x, dst.end.y + 42.0), "%02d:%02d" % [int(hrs) % 24, int((hrs - floor(hrs)) * 60.0)], 15, Color(0.8, 0.9, 1.0, 0.9), HORIZONTAL_ALIGNMENT_RIGHT, ms)


func _draw_messages(sz: Vector2) -> void:
	var y: float = sz.y * 0.5 + 40.0
	for m in _msgs:
		var a: float = clampf(float(m["t"]) / 1.0, 0.0, 1.0)
		var c: Color = m["color"]
		_t(Vector2(18.0, y), String(m["text"]), 19, Color(c.r, c.g, c.b, a))
		y += 24.0


func _draw_boss(sz: Vector2) -> void:
	var w: Node = GameState.world
	if w == null or w.active_boss == null or not is_instance_valid(w.active_boss):
		return
	var b: Node = w.active_boss
	var bw: float = minf(720.0, sz.x * 0.46)
	var x: float = (sz.x - bw) * 0.5
	_t(Vector2(0, 64.0), String(b.def.get("name", "Boss")), 24, Color(1, 0.8, 0.6), HORIZONTAL_ALIGNMENT_CENTER, sz.x)
	_bar(x, 74.0, bw, 18.0, b.hp / maxf(b.max_hp, 1.0), Color(0.85, 0.15, 0.2) if b.phase == 1 else Color(0.95, 0.4, 0.1))


func _draw_banner(sz: Vector2) -> void:
	if _banner_t <= 0.0:
		return
	var a: float = clampf(minf(_banner_t, 3.2 - _banner_t + 0.0) * 2.0, 0.0, 1.0)
	if _banner_t < 1.0:
		a = _banner_t
	var col: Color = Color(0.7, 1.0, 0.8, a) if _banner_safe else Color(1.0, 0.75, 0.55, a)
	_t(Vector2(0, sz.y * 0.2), _banner, 46, col, HORIZONTAL_ALIGNMENT_CENTER, sz.x)
	_t(Vector2(0, sz.y * 0.2 + 30.0), "Safe zone" if _banner_safe else "Danger zone", 20, Color(col.r, col.g, col.b, a * 0.8), HORIZONTAL_ALIGNMENT_CENTER, sz.x)


func _draw_combo(sz: Vector2) -> void:
	var p: Node = GameState.player
	if p == null or not is_instance_valid(p) or int(p.combo_count) < 2:
		return
	var k: float = clampf(float(p.combo_count_timer) / 2.2, 0.0, 1.0)
	_t(Vector2(sz.x - 340.0, 250.0), "%d HITS" % int(p.combo_count), 34, Color(1, 0.85, 0.3, 0.4 + 0.6 * k), HORIZONTAL_ALIGNMENT_RIGHT, 324.0)


func _draw_overlays(sz: Vector2) -> void:
	var p: Node = GameState.player
	var hp_r: float = GameState.hp / maxf(GameState.max_hp(), 1.0)
	if hp_r < 0.3 and hp_r > 0.0:
		var a: float = (0.3 - hp_r) / 0.3 * (0.25 + 0.15 * sin(Time.get_ticks_msec() * 0.008))
		var e: float = 70.0
		draw_rect(Rect2(0, 0, sz.x, e), Color(0.8, 0, 0, a))
		draw_rect(Rect2(0, sz.y - e, sz.x, e), Color(0.8, 0, 0, a))
		draw_rect(Rect2(0, 0, e, sz.y), Color(0.8, 0, 0, a))
		draw_rect(Rect2(sz.x - e, 0, e, sz.y), Color(0.8, 0, 0, a))
	if p != null and is_instance_valid(p) and p.state == "dead":
		draw_rect(Rect2(Vector2.ZERO, sz), Color(0, 0, 0, 0.55))
		_t(Vector2(0, sz.y * 0.45), "YOU HAVE FALLEN", 54, Color(1, 0.4, 0.35), HORIZONTAL_ALIGNMENT_CENTER, sz.x)
		_t(Vector2(0, sz.y * 0.45 + 40.0), "Your Qi scatters... returning to Qingyun Village", 22, Color(1, 1, 1, 0.9), HORIZONTAL_ALIGNMENT_CENTER, sz.x)
